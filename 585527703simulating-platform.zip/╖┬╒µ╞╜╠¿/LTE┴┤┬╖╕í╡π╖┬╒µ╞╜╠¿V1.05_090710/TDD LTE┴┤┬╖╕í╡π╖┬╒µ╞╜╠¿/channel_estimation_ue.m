function Output = channel_estimation_ue(input,Pilot_Sequence_ue,SNR)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�channel_estimation_ue
% ��������������UE�ο��ź��ŵ�����
% ���������
%      input              ���ŵ���������
%      Pilot_Sequence_ue  ��UE�ο��ź�����
% ��������� �����ز��ŵ�����ֵ
% 
% �޸�����          �汾��           �޸���          �޸�����
% ------------------------------------------------------------------------
%                  V1.0              ��ӱ          
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global PublicPara 
global Resource_Grid_ue_dl 
global System_clock

Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Ant_Rx = PublicPara.Num_UEAnt;
Num_RB = PublicPara.NumRB;

tti = System_clock(2);
SubframeType = PublicPara.ConfigFrame(tti);
Num_D_G_U_ofdm = PublicPara.ConfigDGUFrame;
Num_DwPTS_ofdm = Num_D_G_U_ofdm(1);

pilot_loc = 0:3*Num_RB-1;

Y = input;
Resource_Grid_ue_temp = Resource_Grid_ue_dl(1:Num_Ant_Tx:end,:);
symbol = size(Resource_Grid_ue_temp,1);
        
pilotsymbol_4 = Pilot_Sequence_ue(1,pilot_loc + 1);
pilotsymbol_7 = Pilot_Sequence_ue(2,pilot_loc + 1);
pilotsymbol_10 = Pilot_Sequence_ue(3,pilot_loc + 1);
pilotsymbol_13 = Pilot_Sequence_ue(4,pilot_loc + 1);
        
Pilot_Location4 = find(Resource_Grid_ue_temp(4,:)~=0);
L4 = length(Pilot_Location4);
Pilot_Location7 = find(Resource_Grid_ue_temp(7,:)~=0);
L7 = length(Pilot_Location7);

Subcarrier = PublicPara.NumSubCarrierPRB * Num_RB;

Num_Occupied_dl = PublicPara.Num_Occupied_sc-1;
Output = ones(Num_Ant_Rx,1,symbol,Num_Occupied_dl);

h = [];
T_4 = [];
T_7 = [];
T_10 = [];
T_13 = [];
        
for irx = 1:Num_Ant_Rx
    Yi=Y(irx:Num_Ant_Rx:end,:).';
    RxPilotInTime_ue(:,irx,1) = Yi(Pilot_Location4,4,:);
    RxPilotInTime_ue(:,irx,2) = Yi(Pilot_Location4,10,:);
    RxPilotInTime_ue(:,irx,3) = Yi(Pilot_Location7,7,:);
    RxPilotInTime_ue(:,irx,4) = Yi(Pilot_Location7,13,:);
end

if L4 ~= 0
    %%%%%%%%%%%%%%%%%%%%%%%%%
    TargetPilotInFre = pilotsymbol_4.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime_ue(:,:,1),TargetPilotInFre,SNR);
    T_4(Pilot_Location4,:) = PilotChannelEsti(:,:,1,1);                         %  test sy 
    TargetPilotInFre = pilotsymbol_10.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime_ue(:,:,2),TargetPilotInFre,SNR);
    T_10(Pilot_Location4,:) = PilotChannelEsti(:,:,1,1);                        % test  sy
end

if L7 ~= 0
    TargetPilotInFre = pilotsymbol_7.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime_ue(:,:,3),TargetPilotInFre,SNR); %��һ���������ߺ͵�һ�����������ڵ�Ƶ�����ŵ�����
    T_7(Pilot_Location7,:) = PilotChannelEsti(:,:,1,1);                %  test  sy
    TargetPilotInFre = pilotsymbol_13.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime_ue(:,:,4),TargetPilotInFre,SNR);
    T_13(Pilot_Location7,:) = PilotChannelEsti(:,:,1,1);            %  test  sy 
end

for irx = 1:Num_Ant_Rx
    %%%%%%%%  % symbol = 1/8 %%%%%%%%%%%%%%%%
    %����Ϊ�������Բ�ֵ
    if L4 ~= 0
        L = 1;
        % �м䲿������ѭ��
        for rep1 = 1:length(Pilot_Location4)-1              %Ƶ���ֵ
            rep2 = 0:3;
            h(4,L+rep2) = ( T_4(4*rep1+Pilot_Location4(1)) - T_4(4*(rep1-1)+Pilot_Location4(1))) .* rep2/4 + T_4(4*(rep1-1)+Pilot_Location4(1));
            h(10,L+rep2) = ( T_10(4*rep1+Pilot_Location4(1)) - T_10(4*(rep1-1)+Pilot_Location4(1))) .* rep2/4 + T_10(4*(rep1-1)+Pilot_Location4(1));
            L = L+4;      
        end
        % ���ಿ�ַ�����ѭ��
        rep2 = 0:Subcarrier-L;
        h(4,L+rep2) = (T_4(Pilot_Location4(L4)) - T_4(Pilot_Location4(L4-1))) .* rep2/4 + T_4(Pilot_Location4(L4));
        h(10,L+rep2) = (T_10(Pilot_Location4(L4)) - T_10(Pilot_Location4(L4-1))) .* rep2/4 + T_10(Pilot_Location4(L4));
    end
    %%%%%%%%%% %    symbol =5/12 %%%%%%%%%%%%%%%
    if L7 ~= 0
        L = 3;
        % �м䲿������ѭ��
        for rep1 = 1:length(Pilot_Location7)-1
            rep2 = 0:3;
            h(7,L+rep2) = ( T_7(4*rep1+Pilot_Location7(1)) - T_7(4*(rep1-1)+Pilot_Location7(1))) .* rep2/4 + T_7(4*(rep1-1)+Pilot_Location7(1));
            h(13,L+rep2) = (T_13(4*rep1+Pilot_Location7(1)) - T_13(4*(rep1-1)+Pilot_Location7(1))) .* rep2/4 + T_13(4*(rep1-1)+Pilot_Location7(1));
            L = L+4;
        end
        % ���ಿ�ַ�����ѭ��
        rep2 = 0:Subcarrier-L;
        h(7,L+rep2) = (T_7(Pilot_Location7(L7)) - T_7(Pilot_Location7(L7-1))) .* rep2/4 + T_7(Pilot_Location7(L7));
        h(13,L+rep2) = (T_13(Pilot_Location7(L7)) - T_13(Pilot_Location7(L7-1))) .* rep2/4 + T_13(Pilot_Location7(L7));
        rep2=1:2;
        h(7,rep2) = T_7(Pilot_Location7(1)) - (T_7(Pilot_Location7(2)) - T_7(Pilot_Location7(1))) .* (3-rep2)/4;
        h(13,rep2) = T_13(Pilot_Location7(1)) - (T_13(Pilot_Location7(2)) - T_13(Pilot_Location7(1))) .* (3-rep2)/4;
    end
    for i =1:3                                                 %ʱ���ֵ
        h(i,:) = h(4,:) - (h(7,:) - h(4,:)) .* (4-i)/4;
    end

    for i = 5:6
        h(i,:) = (h(7,:) - h(4,:)) .* (i-4)/3 + h(4,:);
    end

    for i = 8:9
        h(i,:) = (h(10,:) - h(7,:)) .* (i-7)/3 + h(7,:);
    end

    for i = 11:14
        h(i,:) = (h(13,:) - h(10,:)) .* (i-10)/3 + h(10,:);
    end

    if strcmp(SubframeType,'S')
        
    end
    Output_temp(irx,1,:,:) = h(:,:,irx);
    Output(irx,1,:,1:Subcarrier) = squeeze(Output_temp(irx,1,:,:));
end
% Output(:,1,:,(PublicPara.Num_Occupied_sc-Subcarrier)/2+1:(PublicPara.Num_Occupied_sc-Subcarrier)/2+Subcarrier) = Output_temp; 
