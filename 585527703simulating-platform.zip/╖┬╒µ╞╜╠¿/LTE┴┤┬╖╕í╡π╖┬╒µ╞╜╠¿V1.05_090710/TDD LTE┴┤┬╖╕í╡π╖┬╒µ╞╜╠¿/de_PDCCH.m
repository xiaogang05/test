function info_PDCCH_rx = de_PDCCH(ofdm_control_rx,H_Est_ALL,tti,info_PCFICH_rx,NSR)
%  ����˵�������DCI��Ϣ  zt 080805

global PublicPara
global DownlinkPara
global MethodPara

nRNTI = PublicPara.RNTI;
Num_RB =  PublicPara.MaxRB; 
config_U_D_index = PublicPara.ConfigFrame;
special_tti = find(config_U_D_index== 'S');
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Ant_Rx = PublicPara.Num_UEAnt;
Cell_ID = PublicPara.NcellID;

control_idxSC_PHICH = DownlinkPara.control_idxSC_PHICH;
control_idxSC_PHICH_Len = DownlinkPara.control_idxSC_PHICH_Len;

Ant_select_flag = 0;
UE_Ant = 1;
Num_Control_OFDM = info_PCFICH_rx;

if Num_RB <= 10
    if sum(tti == special_tti)
        Num_Control_OFDM = 2;
    else
        Num_Control_OFDM = Num_Control_OFDM+1;
    end
else
    if sum(tti == special_tti) && (Num_Control_OFDM > 1)
        Num_Control_OFDM = 2;
    end        
end

M_quad = floor(sum(control_idxSC_PHICH_Len(1:Num_Control_OFDM))/4);
if M_quad>32
    C = 32;
    R = ceil(M_quad/C);
    N_D_REQ = R*C-M_quad;
    REQ_metrix = [ones(1,N_D_REQ)*inf 1:M_quad];
    Interleaving1 = Interleaving(M_quad,0);
    REQ_interleaved = REQ_metrix(Interleaving1+1);
    REQ_interleaved((REQ_interleaved == inf)) = [];
else
    Permute_Col=[1,17,9,25,5,21,13,29,3,19,11,27,7,23,15,31,0,16,8,24,4,20,12,28,2,18,10,26,6,22,14,30];
    Permute_Col((Permute_Col>M_quad-1)) = [];
    REQ_metrix = 1:M_quad;
    REQ_interleaved = REQ_metrix(Permute_Col+1);
end
REQ_shifted = [];
for i = 0:M_quad-1
    REQ_shifted(i+1) = REQ_interleaved(mod(i+Cell_ID,M_quad)+1);
end
control_idxSC_1 = control_idxSC_PHICH(1:control_idxSC_PHICH_Len(1));
k_RE_group_1 = control_idxSC_1(1:4:end);
control_idxSC_2 = control_idxSC_PHICH(control_idxSC_PHICH_Len(1)+1:sum(control_idxSC_PHICH_Len(1:2)));
k_RE_group_2 = control_idxSC_2(1:4:end);
control_idxSC_3 = control_idxSC_PHICH(sum(control_idxSC_PHICH_Len(1:2))+1:sum(control_idxSC_PHICH_Len(1:3)));
k_RE_group_3 = control_idxSC_3(1:4:end);
control_idxSC_4 = control_idxSC_PHICH(sum(control_idxSC_PHICH_Len(1:3))+1:end);
k_RE_group_4 = control_idxSC_4(1:4:end);
if Num_Control_OFDM == 1
    k_low = k_RE_group_1(1);
    k_high = k_RE_group_1(end);
elseif Num_Control_OFDM == 2
    k_low = min(k_RE_group_1(1),k_RE_group_2(1));
    k_high = max(k_RE_group_1(end),k_RE_group_2(end));
elseif Num_Control_OFDM == 3
    k_low = min([k_RE_group_1(1) k_RE_group_2(1) k_RE_group_3(1)]);
    k_high = max([k_RE_group_1(end),k_RE_group_2(end),k_RE_group_3(end)]);
else
    k_low = min([k_RE_group_1(1) k_RE_group_2(1) k_RE_group_3(1) k_RE_group_4(1)]);
    k_high = max([k_RE_group_1(end),k_RE_group_2(end),k_RE_group_3(end),k_RE_group_3(end)]);
end

channel_PDCCH = [];
flag = 0;
m = 0;
for k = k_low:k_high
    for l = 1:Num_Control_OFDM        
        if l == 1
            if ~isempty(k_RE_group_1) && k_RE_group_1(1) == k
                start_loc = find(control_idxSC_1 == k);
                k0 = control_idxSC_1(start_loc:start_loc+3);
                REQ = ofdm_control_rx(1:Num_Ant_Rx,k0);                
                m = m+1;
                flag = 1;
                k_RE_group_1(1) = [];
            end
        elseif l == 2
            if ~isempty(k_RE_group_2) && k_RE_group_2(1) == k
                start_loc = find(control_idxSC_2 == k);
                k0 = control_idxSC_2(start_loc:start_loc+3);
                REQ = ofdm_control_rx(Num_Ant_Rx+1:2*Num_Ant_Rx,k0);
                m = m+1;
                flag = 1;
                k_RE_group_2(1) = [];
            end
        elseif l == 3
            if ~isempty(k_RE_group_3) && k_RE_group_3(1) == k
                start_loc = find(control_idxSC_3 == k);
                k0 = control_idxSC_3(start_loc:start_loc+3);
                REQ = ofdm_control_rx(2*Num_Ant_Rx+1:3*Num_Ant_Rx,k0);                
                m = m+1;
                flag = 1;
                k_RE_group_3(1) = [];
            end
        else
            if ~isempty(k_RE_group_4) && k_RE_group_4(1) == k
                start_loc = find(control_idxSC_4 == k);
                k0 = control_idxSC_4(start_loc:start_loc+3);
                REQ = ofdm_control_rx(3*Num_Ant_Rx+1:4*Num_Ant_Rx,k0);                
                m = m+1;
                flag = 1;
                k_RE_group_4(1) = [];
            end
        end
        if flag == 1
            data_PDCCH(:,(REQ_shifted(m)-1)*4+1:REQ_shifted(m)*4) = REQ;
            for kk = 1:4
                channel_PDCCH(1:Num_Ant_Rx,:,(REQ_shifted(m)-1)*4+kk) = squeeze(H_Est_ALL(1:Num_Ant_Rx,:,l,k0(kk)));
            end
            flag = 0;
        end
    end
end

if Num_Ant_Tx == 1
    channel_PDCCH_1T = reshape(channel_PDCCH,Num_Ant_Rx,length(channel_PDCCH));
    output_de_Layer_mapper_PDCCH = DeMod_tx1(data_PDCCH,channel_PDCCH_1T,NSR,MethodPara.DeMIMO);
else
    output_de_Layer_mapper_PDCCH = sfbc_decode(channel_PDCCH,data_PDCCH);
    output_de_Layer_mapper_PDCCH = reshape(output_de_Layer_mapper_PDCCH,1,[]);
end

% y1 = real(output_de_Layer_mapper_PDCCH);
% y0 = imag(output_de_Layer_mapper_PDCCH);
% output_soft_bits = [y1; y0];
% de_modulation_PDCCH = reshape(output_soft_bits,1,2*length(y1));
de_modulation_PDCCH = -DeModulator(output_de_Layer_mapper_PDCCH);

Cint = (tti-1)*2^9 + Cell_ID;
c_PDCCH = Scrambling_gen(length(de_modulation_PDCCH),Cint);
Data_DCI_temp = bit_descramble(de_modulation_PDCCH,c_PDCCH);
% Data_DCI(Data_DCI_temp>0) = 0;
% Data_DCI(Data_DCI_temp<0) = 1;
Data_DCI = Data_DCI_temp;

N_CCE_tti = floor(sum(control_idxSC_PHICH_Len(1:Num_Control_OFDM))*2/72);
% Y_tti = [nRNTI zeros(1,tti)];
% A = 39827;
% D = 65537;
% for i = 1:tti
%     Y_tti(i+1) = mod(A * Y_tti(i),D);
% end
% L = [1 2 4 8];
% ML = [6 6 2 2];
% Z_tti = [];
% for i = 1:4
%     Z_tti(i) = L(i) * mod(Y_tti(tti+1),floor(N_CCE_tti/L(i)));
% end
Z_tti = [0 0 0 0];  % for test
CCE_num = 2;
% E_option = [72 144 288 576];
% E_temp = E_option((E_option >= DownlinkPara.Length_DCI_coded));
% E = E_temp(1);
% CCE_num = E/72;

DataRateMatch = Data_DCI((Z_tti(log2(CCE_num)+1))*72+1:Z_tti(log2(CCE_num)+1)*72+CCE_num*72);
DeRateMatchData = CB_DeRateMatching(DataRateMatch ,DownlinkPara.Length_DCI_coded,0,0,0,0);
DecodeData = cc_decode(DeRateMatchData,0).';
if Ant_select_flag == 1
    if UE_Ant == 0
        mask = zeros(1,16);
    else
        mask = [zeros(1,15) 1];
    end
    DecodeData(length(DecodeData)-16+1:end) = mod(DecodeData(length(DecodeData)-16+1:end)+mask,2);
end
x = de2bi(nRNTI,16);
DecodeData(length(DecodeData)-16+1:end) = mod(DecodeData(length(DecodeData)-16+1:end)+x,2);
[info_PDCCH_rx,CheckCRC] = CrcDecoder(DecodeData,16,0);
% if CheckCRC == 0
%     %             disp('ok');
%     info_PDCCH_rx = info_PDCCH_rx_temp;
%     return;
% end
% for test  zt080923


% for i = 1:4
%     CCE_num = L(i);
%     for k = 1:ML(i)
%         if Z_tti(log2(CCE_num)+1)*72+k*CCE_num*72 > length(Data_DCI)
%             break;
%         end
%         DataRateMatch = Data_DCI((Z_tti(log2(CCE_num)+1)+(k-1)*CCE_num)*72+1:Z_tti(log2(CCE_num)+1)*72+k*CCE_num*72);
%         DeRateMatchData = de_rate_match_tailbit(DataRateMatch,Length_DCI_coded(end));
%         DecodeData = cc_decode(DeRateMatchData,0).';
%         if Ant_select_flag == 1
%             if UE_Ant == 0
%                 mask = zeros(1,16);
%             else
%                 mask = [zeros(1,15) 1];
%             end
%             DecodeData(length(DecodeData)-16+1:end) = mod(DecodeData(length(DecodeData)-16+1:end)+mask,2);
%         end
%         x = de2bi(nRNTI,16);
%         DecodeData(length(DecodeData)-16+1:end) = mod(DecodeData(length(DecodeData)-16+1:end)+x,2);
%         [info_PDCCH_rx_temp,CheckCRC] = crc_decode(DecodeData,16);
%         if CheckCRC == 0
% %             disp('ok');
%             info_PDCCH_rx = info_PDCCH_rx_temp;
%             return;
%         end
%     end
% end            