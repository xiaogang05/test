function info_PHICH_rx = de_PHICH(ofdm_control_rx,H_Est_ALL,tti,NSR)
%  ����˵�������HI��Ϣ  zt 080804
global PublicPara
global DownlinkPara
global MethodPara

Num_RB = PublicPara.MaxRB;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Ant_Rx = PublicPara.Num_UEAnt;
Cell_ID = PublicPara.NcellID;
Num_PHICH_OFDM = DownlinkPara.LengthPHICH;
HI_group = DownlinkPara.HIgroup;
control_idxSC_PCFICH = DownlinkPara.control_idxSC_PCFICH;
control_idxSC_PCFICH_Len = DownlinkPara.control_idxSC_PCFICH_Len;

if HI_group == 0;
    info_PHICH_rx = [];
    return;
end

n(1) = control_idxSC_PCFICH_Len(1)/4;
n(3) = 3*Num_RB;
if Num_Ant_Tx == 4
    n(2) = 2*Num_RB;
else
    n(2) = n(3);
end
data_PHICH = [];
channel_PHICH = [];
if Num_PHICH_OFDM == 1
    control_idxSC_1 = control_idxSC_PCFICH(1:control_idxSC_PCFICH_Len(1));
    for i = 1:HI_group
        temp0 = mod(floor(Cell_ID*n(1)/n(1))+i-1,n(1));
        temp1 = mod(floor(Cell_ID*n(1)/n(1))+i-1+floor(n(1)/3),n(1));
        temp2 = mod(floor(Cell_ID*n(1)/n(1))+i-1+floor(2*n(1)/3),n(1));
        k0 = control_idxSC_1(temp0*4+1:(temp0+1)*4);
        k1 = control_idxSC_1(temp1*4+1:(temp1+1)*4);
        k2 = control_idxSC_1(temp2*4+1:(temp2+1)*4);
        data_PHICH(:,(i-1)*12+(1:4)) = ofdm_control_rx(1:Num_Ant_Rx,k0);
        data_PHICH(:,(i-1)*12+(5:8)) = ofdm_control_rx(1:Num_Ant_Rx,k1);
        data_PHICH(:,(i-1)*12+(9:12)) = ofdm_control_rx(1:Num_Ant_Rx,k2);
        for kk = 1:4
            channel_PHICH(:,:,(i-1)*12+kk) = squeeze(H_Est_ALL(:,:,1,k0(kk)));
            channel_PHICH(:,:,(i-1)*12+4+kk) = squeeze(H_Est_ALL(:,:,1,k1(kk)));
            channel_PHICH(:,:,(i-1)*12+8+kk) = squeeze(H_Est_ALL(:,:,1,k2(kk)));
        end
    end
elseif Num_PHICH_OFDM == 3
    control_idxSC_1 = control_idxSC_PCFICH(1:control_idxSC_PCFICH_Len(1));
    control_idxSC_2 = control_idxSC_PCFICH(control_idxSC_PCFICH_Len(1)+1:sum(control_idxSC_PCFICH_Len(1:2)));
    control_idxSC_3 = control_idxSC_PCFICH(sum(control_idxSC_PCFICH_Len(1:2))+1:sum(control_idxSC_PCFICH_Len(1:3)));
    for i = 1:HI_group
        temp0 = mod(floor(Cell_ID*n(1)/n(1))+i-1,n(1));
        temp1 = mod(floor(Cell_ID*n(2)/n(1))+i-1+floor(n(2)/3),n(2));
        temp2 = mod(floor(Cell_ID*n(3)/n(1))+i-1+floor(2*n(3)/3),n(3));
        k0 = control_idxSC_1(temp0*4+1:(temp0+1)*4);
        k1 = control_idxSC_2(temp1*4+1:(temp1+1)*4);
        k2 = control_idxSC_3(temp2*4+1:(temp2+1)*4);
        data_PHICH(:,(i-1)*12+(1:4)) = ofdm_control_rx(1:Num_Ant_Rx,k0);
        data_PHICH(:,(i-1)*12+(5:8)) = ofdm_control_rx(Num_Ant_Rx+1:2*Num_Ant_Rx,k1);
        data_PHICH(:,(i-1)*12+(9:12)) = ofdm_control_rx(2*Num_Ant_Rx+1:3*Num_Ant_Rx,k2);
        for kk = 1:4
            channel_PHICH(:,:,(i-1)*12+kk) = squeeze(H_Est_ALL(:,:,1,k0(kk)));
            channel_PHICH(:,:,(i-1)*12+4+kk) = squeeze(H_Est_ALL(:,:,2,k1(kk)));
            channel_PHICH(:,:,(i-1)*12+8+kk) = squeeze(H_Est_ALL(:,:,3,k2(kk)));
        end
    end
else
    control_idxSC_1 = control_idxSC_PCFICH(1:control_idxSC_PCFICH_Len(1));
    control_idxSC_2 = control_idxSC_PCFICH(control_idxSC_PCFICH_Len(1)+1:sum(control_idxSC_PCFICH_Len(1:2)));
    for i = 1:HI_group
        k = 0;
        ll = mod(floor((i-1)/2)+k+1,2);
        temp0 = mod(floor(Cell_ID*n(ll+1)/n(2))+i-1,n(ll+1));
        if ll == 0
            control_idxSC_temp = control_idxSC_1;
            kk = 1;
        else
            control_idxSC_temp = control_idxSC_2;
            kk = 2;
        end
        k0 = control_idxSC_temp(temp0*4+1:(temp0+1)*4);
        data_PHICH(:,(i-1)*12+(1:4)) = ofdm_control_rx(ll*Num_Ant_Rx+1:(ll+1)*Num_Ant_Rx,k0);
        for kkk = 1:4
            channel_PHICH(:,:,(i-1)*12+kkk) = squeeze(H_Est_ALL(:,:,kk,k0(kkk)));
        end

        k = 1;
        ll = mod(floor((i-1)/2)+k+1,2);
        temp1 = mod(floor(Cell_ID*n(ll+1)/n(2))+i-1+floor(n(ll+1)/3),n(ll+1));
        if ll == 0
            control_idxSC_temp = control_idxSC_1;
            kk = 1;
        else
            control_idxSC_temp = control_idxSC_2;
            kk = 2;
        end
        k1 = control_idxSC_temp(temp1*4+1:(temp1+1)*4);
        data_PHICH(:,(i-1)*12+(5:8)) = ofdm_control_rx(ll*Num_Ant_Rx+1:(ll+1)*Num_Ant_Rx,k1);
        for kkk = 1:4
            channel_PHICH(:,:,(i-1)*12+4+kkk) = squeeze(H_Est_ALL(:,:,kk,k1(kkk)));
        end

        k = 2;
        ll = mod(floor((i-1)/2)+k+1,2);
        temp2 = mod(floor(Cell_ID*n(ll+1)/n(2))+i-1+floor(2*n(ll+1)/3),n(ll+1));
        if ll == 0
            control_idxSC_temp = control_idxSC_1;
            kk = 1;
        else
            control_idxSC_temp = control_idxSC_2;
            kk = 2;
        end
        k2 = control_idxSC_temp(temp2*4+1:(temp2+1)*4);
        data_PHICH(:,(i-1)*12+(9:12)) = ofdm_control_rx(ll*Num_Ant_Rx+1:(ll+1)*Num_Ant_Rx,k2);
        for kkk = 1:4
            channel_PHICH(:,:,(i-1)*12+8+kkk) = squeeze(H_Est_ALL(:,:,kk,k2(kkk)));
        end
    end
end

if Num_Ant_Tx == 1
    channel_PHICH_1T = reshape(channel_PHICH,Num_Ant_Rx,length(channel_PHICH));
    output_de_Layer_mapper_PHICH = DeMod_tx1(data_PHICH,channel_PHICH_1T,NSR,MethodPara.DeMIMO);
elseif Num_Ant_Tx == 2
    output_de_Layer_mapper_PHICH = sfbc_decode(channel_PHICH,data_PHICH);
    output_de_Layer_mapper_PHICH = reshape(output_de_Layer_mapper_PHICH,1,[]);
else
    est = [];
    for n=1:4:12
        r = [data_PHICH(:,n);conj(data_PHICH(:,n+1));data_PHICH(:,n+2);conj(data_PHICH(:,n+3))];        
        h1 = channel_PHICH(:,1,n).';
        h2 = channel_PHICH(:,2,n).';
        h3 = channel_PHICH(:,3,n).';
        h4 = channel_PHICH(:,4,n).';
        h5 = zeros(1,Num_Ant_Rx);
        if mod(HI_group+(n-1)/4,2) == 0
            H = [conj(h1) h3 h5 h5;h5 h5 conj(h1) h3;-conj(h3) h1 h5 h5;h5 h5 -conj(h3) h1];
        else
            H = [conj(h2) h4 h5 h5;h5 h5 conj(h2) h4;-conj(h4) h2 h5 h5;h5 h5 -conj(h4) h2];
        end
        r = reshape(r,size(H,2),[]);
        s = H * r;
        s_temp = [s(1);s(3)';s(2);s(4)'];
        est = [est sqrt(1/2)*s_temp];
    end
    output_de_Layer_mapper_PHICH = reshape(est,1,[]);
end

SF = [1 1 1 1;1 -1 1 -1;1 1 -1 -1;1 -1 -1 1;j j j j;j -j j -j;j j -j -j;j -j -j j];
output_de_Layer_mapper_PHICH = reshape(output_de_Layer_mapper_PHICH,12,[]).';
info_PHICH_rx = [];
for i = 1:HI_group
    Data_HI_modulated = [];
    Cint = tti * (2*Cell_ID+1) * 2^9 + Cell_ID;  % ����830����  zt080715
    c = Scrambling_gen(31,Cint);
    c_PHICH = c(1:12);
    Data_HI_spreaded = output_de_Layer_mapper_PHICH(i,:).*(1 - 2*c_PHICH);
    option = 3*sqrt(2)*[4 4*j -4 -4*j 2+2*j -2-2*j];
    
    UE_option = [5 2 1];  % the first one is the object UE
    temp = Data_HI_spreaded.*repmat(SF(UE_option(1),:),1,3);
    sum_temp = sum(sum(reshape(temp,4,[])));
    [a b]= min(abs(sum_temp - option));
    if UE_option(1)<=4
        switch b
            case {1,2,5}
                Data_HI_modulated = 1/sqrt(2)*(1+j);
            case {3,4,6}
                Data_HI_modulated = -1/sqrt(2)*(1+j);
        end
    else
        switch b
            case {1,2,5}
                Data_HI_modulated = -1/sqrt(2)*(1+j);
            case {3,4,6}
                Data_HI_modulated = 1/sqrt(2)*(1+j);
        end
    end

    if Data_HI_modulated == 1/sqrt(2)*(1+j);
        info_PHICH_rx(i) = 0;
    elseif Data_HI_modulated == -1/sqrt(2)*(1+j);
        info_PHICH_rx(i) = 1;
    end
end