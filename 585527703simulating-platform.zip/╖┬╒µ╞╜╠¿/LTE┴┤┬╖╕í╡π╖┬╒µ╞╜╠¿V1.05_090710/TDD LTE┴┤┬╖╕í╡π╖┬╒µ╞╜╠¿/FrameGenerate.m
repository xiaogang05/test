function [TxDataInTimeDomain TxDataInTimeDomain_AdCell]= FrameGenerate(TxDataInFreqDomain,TxDataInFreqDomain_AdCell)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�FrameGenerate
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 176575)
%==============================================================================
% ����˵��:   ���IFFT����CP����֡���� ��
%
% �������:
% TxDataInFreqDomain   �� ���������Դӳ����Ƶ�����ݡ�
%
%
% �������:
% TxDataInTimeDomain   �� ���IFFT����CP����֡�������ʱ�����ݡ�
%
% ���ú�����Add_Zeros��IFFT_tfansform��Insert_CP��
%==============================================================================
% �汾��ʷ:
% 2008.10.22         �׽ܴ���
% 2008.11.24         modified by libin
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global SimLinkPara;
global UplinkPara
global PublicPara

FFT_Size = PublicPara.FFTNum;

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090317
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
end

if strcmp(SimLinkPara(1:4),'Down')
    % Ƶ������
    TxDataToIFFT = Add_Zeros(TxDataInFreqDomain,FFT_Size);
    % Ƶ�װ���
    TxDataToIFFT = [TxDataToIFFT(:,FFT_Size/2+1:end) TxDataToIFFT(:,1:FFT_Size/2)].';
    % IFFT�任
    IFFT_Output = ifft(TxDataToIFFT);
    %������CP
    TxDataInTimeDomain = Insert_CP(IFFT_Output);
    
    if AdCellFlag == 1      %added by libin 090317
        TxDataInTimeDomain_AdCell = [];
        for k = 1: AdCellNum
            % Ƶ������
            TxDataToIFFT = Add_Zeros(TxDataInFreqDomain_AdCell{k},FFT_Size);
            % Ƶ�װ���
            TxDataToIFFT = [TxDataToIFFT(:,FFT_Size/2+1:end) TxDataToIFFT(:,1:FFT_Size/2)].';
            % IFFT�任
            IFFT_Output = ifft(TxDataToIFFT);
            %������CP
            TxDataInTimeDomain_AdCell{k} = Insert_CP(IFFT_Output);
        end
    else
        TxDataInTimeDomain_AdCell = [];
    end
    
elseif strcmp(SimLinkPara,'UPRACHLink')
    TxDataInTimeDomain = TxDataInFreqDomain;
    TxDataInTimeDomain_AdCell = [];
elseif strcmp(SimLinkPara,'UPDataLink') || strcmp(SimLinkPara,'UPControlLink')
    % IFFT�任
    TxDataToIFFT = SubcarrierMap_Uplink(TxDataInFreqDomain);
    IFFT_Output = ifft(TxDataToIFFT);
    if UplinkPara.FixedFreOffsetFlag == 1 
        % ����7.5KHz�̶�Ƶƫ
        IFFT_Output = Add_Freq_Offset(IFFT_Output, FFT_Size);
    end
    %������CP
    TxDataInTimeDomain = Insert_CP(IFFT_Output);
    
     if AdCellFlag == 1      %added by libin 090317
        for k = 1: AdCellNum
            % IFFT�任
            TxDataToIFFT = SubcarrierMap_Uplink(TxDataInFreqDomain_AdCell{k});
            IFFT_Output = ifft(TxDataToIFFT);
            if UplinkPara.FixedFreOffsetFlag == 1
                % ����7.5KHz�̶�Ƶƫ
                IFFT_Output = Add_Freq_Offset(IFFT_Output, FFT_Size);
            end
            %������CP
            TxDataInTimeDomain_AdCell{k} = Insert_CP(IFFT_Output);
        end
    else
        TxDataInTimeDomain_AdCell = [];
    end
end






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DataInFre = SubcarrierMap_Uplink(TxDataInFreqDomain)

global PublicPara
global PUSCHPara
global PUCCHPara
global SimLinkPara

FFTNum = PublicPara.FFTNum;
TxAntennaNum = PublicPara.Num_UEAnt;
OverSampleRate = PublicPara.OverSampleRate;
OFDMSymbolNum = PublicPara.OFDMSymbolNum;
if  strcmp(SimLinkPara,'UPControlLink')
    TargetDataCarIndex = PUCCHPara.TargetDataCarIndex;
    DataAfterMapping = zeros(FFTNum,OFDMSymbolNum,TxAntennaNum);
    for i=1:TxAntennaNum
        DataAfterMapping(1+12*(TargetDataCarIndex(1)):12+12*(TargetDataCarIndex(1)),1:OFDMSymbolNum/2,i) = DataAfterMapping(1+12*(TargetDataCarIndex(1)):12+12*(TargetDataCarIndex(1)),1:OFDMSymbolNum/2,i) + TxDataInFreqDomain(:,1:OFDMSymbolNum/2,i);
        DataAfterMapping(1+12*TargetDataCarIndex(2):12+12*TargetDataCarIndex(2),OFDMSymbolNum/2+1:OFDMSymbolNum,i) = DataAfterMapping(1+12*TargetDataCarIndex(2):12+12*TargetDataCarIndex(2),OFDMSymbolNum/2+1:OFDMSymbolNum,i) + TxDataInFreqDomain(:,OFDMSymbolNum/2 + 1:OFDMSymbolNum,i);
    end
else
    DataOFDMSymNum = OFDMSymbolNum - 2;
    TargetDataCarIndex = PUSCHPara.TargetDataCarIndex;
    % Ƶ���ʼ��
    DataAfterMapping = zeros(FFTNum,OFDMSymbolNum,TxAntennaNum);
    SlotLen = ceil(DataOFDMSymNum / 2)+1;

    % ӳ�䵽��Ӧ���ز�λ��
    DataAfterMapping(TargetDataCarIndex(:,1),1:SlotLen,:) = TxDataInFreqDomain(:,1:OFDMSymbolNum/2,:);
    DataAfterMapping(TargetDataCarIndex(:,2),SlotLen + 1:2 * SlotLen,:) = TxDataInFreqDomain(:,OFDMSymbolNum/2 + 1:OFDMSymbolNum,:);
end
% Ƶ�����㣨ʱ���������
DataInFre = [ DataAfterMapping(1:FFTNum/2,:,:);zeros((OverSampleRate - 1) *...
    FFTNum,OFDMSymbolNum,TxAntennaNum);DataAfterMapping(FFTNum / 2 + 1:FFTNum,:,:)];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ofdm_data_tx = Add_Zeros(ofdm_data_tx_pure,FFT_Size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara

Num_sc = PublicPara.Num_Occupied_sc;

Len_zero_1 = ceil((FFT_Size-Num_sc)/2);
Len_zero_2 = FFT_Size-Num_sc-Len_zero_1;

Len = (Num_sc-1)/2;

Row = size(ofdm_data_tx_pure,1);

ofdm_data_tx = [zeros(Row,Len_zero_1) ofdm_data_tx_pure(:,1:Len) zeros(Row,1) ofdm_data_tx_pure(:,Len+1:Num_sc-1) zeros(Row,Len_zero_2)];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function AddedFreqOffsetOutput = Add_Freq_Offset(IFFT_Output, FFT_Size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�Add_Freq_Offset
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 176575)
%==============================================================================
% ����˵��:   ����7.5KHz�̶�Ƶƫ ��
%
% �������:
% IFFT_Output   �� IFFT�����
% FFT_Size   �� �� FFT/IFFT���ȡ�
%
% �������:
% AddedFreqOffsetOutput   �� ����7.5KHz�̶�Ƶƫ���ʱ�����ݡ�
%
% ���ú�������
%==============================================================================
% �汾��ʷ:
% 2008.10.2��         �׽ܴ���
%
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara;
Num_Ant_Tx = PublicPara.Num_UEAnt;   % uplink antenna number equals UE antenna number.
CP_Types = PublicPara.CPtype;        % 0-Normal CP, 1 - Extended CP
if CP_Types == 0
    nSymbol = 14;      % there are 14 symbols in one subframe when CP_Type is normal CP.
else
    nSymbol = 12;      % there are 12 symbols in one subframe when CP_Type is normal CP.
end

% generate fixed frequency offset data
FreqOffsetData =  exp((0:FFT_Size-1) * 1 * pi/FFT_Size * j);

% add fixed frequency offset 
for i = 1:nSymbol*Num_Ant_Tx 
    AddedFreqOffsetOutput(i,:) = IFFT_Output(i,:) .* FreqOffsetData;  
end

