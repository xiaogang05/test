function TxData = Insert_CP(IFFT_Output)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�insert_CP
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 142372)
%==============================================================================
% ����˵��:   ��CP ��
%
% �������:
% IFFT_Output      �� IFFT�����ݡ�
% FFTNum         �� FFT/IFFT����.
%
% �������:
% TxDataInTimeDomain         �� ��CP���
%
% ���ú������ޡ�
%==============================================================================
% �汾��ʷ:
% 2007.12.24         ���Ҵ���
% 2008.10.22         �׽��޸�
% 2008.11.24         modified by libin
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara;
global SimLinkPara;

CP_Types = PublicPara.CPtype;            % modified by leijie @20081022
LongCPLen = PublicPara.LongCPLen;
ShortCPLen = PublicPara.ShortCPLen;
FFTNum = PublicPara.FFTNum;
OFDMSymbolNum = PublicPara.OFDMSymbolNum;

if strcmp(SimLinkPara(1:4),'Down')
    Num_Ant_Tx = PublicPara.Num_eNBAnt;    % downlink antenna number equals eNodeB antenna number
    [R,C] = size(IFFT_Output);
    DataInTime = zeros(R,C/Num_Ant_Tx,Num_Ant_Tx);
    for i_Ant_Tx = 1:Num_Ant_Tx
        Index = i_Ant_Tx:Num_Ant_Tx:C;
        DataInTime(:,:,i_Ant_Tx) = IFFT_Output(:,Index);
    end  
else
    DataInTime = IFFT_Output ; 
end

switch CP_Types
    case 0  % normal CP
        % ����CP��ʼ��
        LCPStart = FFTNum - LongCPLen + 1; % ���㳤CP��ʼ��
        SCPStart = FFTNum - ShortCPLen + 1;% �����CP��ʼ��

        % ���ݼ�CP
        for SlotIndex = 1:2
            SymbolIndex = (SlotIndex - 1)*OFDMSymbolNum/2;
            FirstData   = [DataInTime(LCPStart:FFTNum,SymbolIndex+1,:);...
                           DataInTime(        :      ,SymbolIndex+1,:)];
            MidData     = [DataInTime(SCPStart:FFTNum,SymbolIndex+2:SymbolIndex+OFDMSymbolNum/2,:);...
                           DataInTime(        :      ,SymbolIndex+2:SymbolIndex+OFDMSymbolNum/2,:)];
            MidData     = reshape(MidData,size(MidData,1)*size(MidData,2),1,size(MidData,3));
            DataTmp     = [FirstData;MidData];    
            DataWithCP(:,SlotIndex,:) = reshape(DataTmp,size(DataTmp,1),size(DataTmp,3));
        end
        % ��֡��CP
        TxDataInTimeDomain = reshape(DataWithCP,size(DataWithCP,1)*size(DataWithCP,2),size(DataWithCP,3));  
        
    case 1  % extended CP
        CPStart = FFTNum - 512*(FFT_Size/2048) + 1; % ����CP��ʼ��
        DataWithCP =  [DataInTime(CPStart:FFTNum,:,:);...
                       DataInTime(        :     ,:,:)];
        TxDataInTimeDomain = reshape(DataWithCP,size(DataWithCP,1)*size(DataWithCP,2),size(DataWithCP,3));

    otherwise
        disp('wrong CP_Types')
end

TxData = TxDataInTimeDomain.';
