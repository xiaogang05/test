function Output = channel_estimation_2TmR(Y,Pilot_Sequence,SNR)
%***********************************************************************
%***********************************************************************
% �������ƣ� channel_estimation_dl            
% ���������� 2�����������ŵ�����     
%            
% ��������� 
%            input             �� �ŵ���������
%            CP_Types          �� CP���͡�% CP_Types = 0 ��ʾ Normal CP 
%                                           CP_Types = 1 ��ʾ Extended CP
%            Num_Ant_Tx        �� ������������
%            Num_Rx            �� ����������
%            Pilot_Sequence    �� ��Ƶ����
%            Resource_Grid     �� ��Ƶ����ͼ�������˵�Ƶ��Ƶ���λ��
%
% ���������
%            output           �� �����ز��ŵ�����ֵ

% �޸�����        �汾��     �޸���	             �޸�����
%-----------------------------------------------
% 2008/01/02	   V1.0     ����(ID: 142372)	     ����
% 2008/10/02       V1.0     ����	                 �޸�Ϊ֧�ֶ������յ��ŵ�����
% 2008/10/27       V1.0     ��Ƽ                   �����ŵ������㷨
%***********************************************************************
%***********************************************************************

global PublicPara 
global DownlinkPara
global System_clock

Resource_Grid = DownlinkPara.Resource_Grid;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Ant_Rx = PublicPara.Num_UEAnt;
Num_D_G_U_ofdm = PublicPara.ConfigDGUFrame;
Num_DwPTS_ofdm = Num_D_G_U_ofdm(1);
tti = System_clock(2);
SubframeType = PublicPara.ConfigFrame(tti);
MaxRB = PublicPara.MaxRB;

[row col] = size(Resource_Grid);
symbol = row/Num_Ant_Tx;
pilot_loc = (1:2*MaxRB) + 110 - MaxRB;

pilotsymbol_1 = Pilot_Sequence(1,pilot_loc);
pilotsymbol_5 = Pilot_Sequence(2,pilot_loc);
pilotsymbol_8 = Pilot_Sequence(3,pilot_loc);
pilotsymbol_12 = Pilot_Sequence(4,pilot_loc);

Pilot_Location1_1 = find(Resource_Grid(1,:)~=0 & Resource_Grid(1,:)~=100);      %��һ�����ߵ�һ�������ϵĵ�Ƶλ��
L1_1 = length(Pilot_Location1_1);
Pilot_Location1_5 = find(Resource_Grid(9,:)~=0 & Resource_Grid(9,:)~=100);      %��һ�����ߵ�5�������ϵĵ�Ƶλ��
L1_5 = length(Pilot_Location1_5);

Pilot_Location2_1 = find(Resource_Grid(2,:)~=0 & Resource_Grid(2,:)~=100);      %�ڶ������ߵ�һ�������ϵĵ�Ƶλ��
L2_1 = length(Pilot_Location2_1);
Pilot_Location2_5 = find(Resource_Grid(10,:)~=0 & Resource_Grid(10,:)~=100);      %�ڶ������ߵ�5�������ϵĵ�Ƶλ��
L2_5 = length(Pilot_Location2_5);
%########################�����ÿ�����Ž��е�Ƶ����################################
Subcarrier = PublicPara.Num_Occupied_sc - 1;
Output = zeros(Num_Ant_Rx,Num_Ant_Tx,symbol,col);
%%%%%%%%%%%%%%%%% �ŵ����� %%%%%%%%%%%%
h1 = [];
h2 = [];
for irx = 1:Num_Ant_Rx
    Yi(:,:)=Y(irx:Num_Ant_Rx:end,:).';
    RxPilotInTime(:,irx,1,1) =Yi(Pilot_Location1_1,1,:);
    RxPilotInTime(:,irx,1,2) =Yi(Pilot_Location2_1,1,:);
    RxPilotInTime(:,irx,2,1) =Yi(Pilot_Location1_1,8,:);
    RxPilotInTime(:,irx,2,2) =Yi(Pilot_Location2_1,8,:);
    RxPilotInTime(:,irx,3,1) =Yi(Pilot_Location1_5,5,:);
    RxPilotInTime(:,irx,3,2) =Yi(Pilot_Location2_5,5,:);
    RxPilotInTime(:,irx,4,1) =Yi(Pilot_Location1_5,12,:);
    RxPilotInTime(:,irx,4,2) =Yi(Pilot_Location2_5,12,:);
end
% symbol = 1/8
if L1_1 ~= 0
    %%%%%%%%%%%%%%%%%%%%%%%%%
    TargetPilotInFre = pilotsymbol_1.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,1,1),TargetPilotInFre,SNR);
    T1_1(Pilot_Location1_1,:) = PilotChannelEsti(:,:,1,1);
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,1,2),TargetPilotInFre,SNR);
    T2_1(Pilot_Location2_1,:) = PilotChannelEsti(:,:,1,1);
    TargetPilotInFre = pilotsymbol_8.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,2,1),TargetPilotInFre,SNR);
    T1_8(Pilot_Location1_1,:) = PilotChannelEsti(:,:,1,1);
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,2,2),TargetPilotInFre,SNR);
    T2_8(Pilot_Location2_1,:) = PilotChannelEsti(:,:,1,1);
end
%    symbol =5/12
if L1_5 ~= 0
        %%%%%%%%%%%%%%%%%%%%%%%%%
    TargetPilotInFre = pilotsymbol_5.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,3,1),TargetPilotInFre,SNR);%��һ���������ߺ͵�һ�����������ڵ�Ƶ�����ŵ�����
    T1_5(Pilot_Location1_5,:) = PilotChannelEsti(:,:,1,1);
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,3,2),TargetPilotInFre,SNR);%�ڶ����������ߺ͵�һ�����������ڵ�Ƶ�����ŵ�����    
    T2_5(Pilot_Location2_5,:) = PilotChannelEsti(:,:,1,1);
    TargetPilotInFre = pilotsymbol_12.';
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,4,1),TargetPilotInFre,SNR);
    T1_12(Pilot_Location1_5,:) = PilotChannelEsti(:,:,1,1);
    PilotChannelEsti       = channel_est_method(RxPilotInTime(:,:,4,2),TargetPilotInFre,SNR);
    T2_12(Pilot_Location2_5,:) = PilotChannelEsti(:,:,1,1);
end
for irx = 1:Num_Ant_Rx
    %%%%%%%%  % symbol = 1/8 %%%%%%%%%%%%%%%%
    if L1_1 ~= 0
        %����Ϊ�������Բ�ֵ
        L1 = 1;
        % �м䲿������ѭ��
        for rep1 = 1:length(Pilot_Location1_1)-1
            rep2 = 0:5;
            h1(1,L1+rep2,irx) = (T1_1(6*rep1+Pilot_Location1_1(1),irx)-T1_1(6*(rep1-1)+Pilot_Location1_1(1),irx)).*rep2/6+T1_1(6*(rep1-1)+Pilot_Location1_1(1),irx);
            h1(8,L1+rep2,irx) = (T1_8(6*rep1+Pilot_Location1_1(1),irx)-T1_8(6*(rep1-1)+Pilot_Location1_1(1),irx)).*rep2/6+T1_8(6*(rep1-1)+Pilot_Location1_1(1),irx);
            L1 = L1+6;
        end
        L2=4;
        for rep3 = 1:length(Pilot_Location2_1)-1
            rep4 = 0:5;
            h2(1,L2+rep2,irx) = (T2_1(6*rep3+Pilot_Location2_1(1),irx)-T2_1(6*(rep3-1)+Pilot_Location2_1(1),irx)).*rep4/6+T2_1(6*(rep3-1)+Pilot_Location2_1(1),irx);
            h2(8,L2+rep2,irx) = (T2_8(6*rep3+Pilot_Location2_1(1),irx)-T2_8(6*(rep3-1)+Pilot_Location2_1(1),irx)).*rep4/6+T2_8(6*(rep3-1)+Pilot_Location2_1(1),irx);
            L2 = L2+6;
        end
        % ���ಿ�ַ�����ѭ��
        rep2 = 0:Subcarrier-L1;
        h1(1,L1+rep2,irx) = (T1_1(Pilot_Location1_1(L1_1),irx)-T1_1(Pilot_Location1_1(L1_1-1),irx)).*rep2/6+T1_1(Pilot_Location1_1(L1_1),irx);
        h1(8,L1+rep2,irx) = (T1_8(Pilot_Location1_1(L1_1),irx)-T1_8(Pilot_Location1_1(L1_1-1),irx)).*rep2/6+T1_8(Pilot_Location1_1(L1_1),irx);

        rep2 = 0:Subcarrier-L2;
        h2(1,L2+rep2,irx) = (T2_1(Pilot_Location2_1(L2_1),irx)-T2_1(Pilot_Location2_1(L2_1-1),irx)).*rep2/6+T2_1(Pilot_Location2_1(L2_1),irx);
        h2(8,L2+rep2,irx) = (T2_8(Pilot_Location2_1(L2_1),irx)-T2_8(Pilot_Location2_1(L2_1-1),irx)).*rep2/6+T2_8(Pilot_Location2_1(L2_1),irx);

        rep2 = 1:3;
        h2(1,rep2,irx) =T2_1(Pilot_Location2_1(1),irx)-(T2_1(Pilot_Location2_1(2),irx)-T2_1(Pilot_Location2_1(1),irx)).*(4-rep2)/6;
        h2(8,rep2,irx) =T2_8(Pilot_Location2_1(1),irx)-(T2_8(Pilot_Location2_1(2),irx)-T2_8(Pilot_Location2_1(1),irx)).*(4-rep2)/6;
    end

    if L1_5 ~= 0
        L1 = 4;
        % �м䲿������ѭ��
        for rep1 = 1:length(Pilot_Location1_5)-1
            rep2 = 0:5;
            h1(5,L1+rep2,irx) = (T1_5(6*rep1+Pilot_Location1_5(1),irx)-T1_5(6*(rep1-1)+Pilot_Location1_5(1),irx)).*rep2/6+T1_5(6*(rep1-1)+Pilot_Location1_5(1),irx);
            h1(12,L1+rep2,irx) = (T1_12(6*rep1+Pilot_Location1_5(1),irx)-T1_12(6*(rep1-1)+Pilot_Location1_5(1),irx)).*rep2/6+T1_12(6*(rep1-1)+Pilot_Location1_5(1),irx);
            L1 = L1+6;
        end
        L2=1;
        for rep3 = 1:length(Pilot_Location2_5)-1
            rep4 = 0:5;
            h2(5,L2+rep4,irx) = (T2_5(6*rep3+Pilot_Location2_5(1),irx)-T2_5(6*(rep3-1)+Pilot_Location2_5(1),irx)).*rep4/6+T2_5(6*(rep3-1)+Pilot_Location2_5(1),irx);
            h2(12,L2+rep4,irx) = (T2_12(6*rep3+Pilot_Location2_5(1),irx)-T2_12(6*(rep3-1)+Pilot_Location2_5(1),irx)).*rep4/6+T2_12(6*(rep3-1)+Pilot_Location2_5(1),irx);
            L2 = L2+6;
        end

        % ���ಿ�ַ�����ѭ��
        rep2 = 0:Subcarrier-L1;
        h1(5,L1+rep2,irx) = (T1_5(Pilot_Location1_5(L1_5),irx)-T1_5(Pilot_Location1_5(L1_5-1),irx)).*rep2/6+T1_5(Pilot_Location1_5(L1_5),irx);
        h1(12,L1+rep2,irx) = (T1_12(Pilot_Location1_5(L1_5),irx)-T1_12(Pilot_Location1_5(L1_5-1),irx)).*rep2/6+T1_12(Pilot_Location1_5(L1_5),irx);

        rep2 = 0:Subcarrier-L2;
        h2(5,L2+rep2,irx) = (T2_5(Pilot_Location2_5(L2_5),irx)-T2_5(Pilot_Location2_5(L2_5-1),irx)).*rep2/6+T2_5(Pilot_Location2_5(L2_5),irx);
        h2(12,L2+rep2,irx) = (T2_12(Pilot_Location2_5(L2_5),irx)-T2_12(Pilot_Location2_5(L2_5-1),irx)).*rep2/6+T2_12(Pilot_Location2_5(L2_5),irx);

        rep2 = 1:3;
        h1(5,rep2,irx) =T1_5(Pilot_Location1_5(1),irx)-(T1_5(Pilot_Location1_5(2),irx)-T1_5(Pilot_Location1_5(1),irx)).*(4-rep2)/6;
        h1(12,rep2,irx) =T1_12(Pilot_Location1_5(1),irx)-(T1_12(Pilot_Location1_5(2),irx)-T1_12(Pilot_Location1_5(1),irx)).*(4-rep2)/6;
    end

    % �������ʱ���ֵ
    for i=2:4
        h1(i,:,irx)=(h1(5,:,irx)- h1(1,:,irx))*(i-1)/4+h1(1,:,irx);
        h2(i,:,irx)=(h2(5,:,irx)- h2(1,:,irx))*(i-1)/4+h2(1,:,irx);
    end
    for i=6:7
        h1(i,:,irx)=(h1(8,:,irx)- h1(5,:,irx)).*(i-5)/3+h1(5,:,irx);
        h2(i,:,irx)=(h2(8,:,irx)- h2(5,:,irx)).*(i-5)/3+h2(5,:,irx);
    end
    for i=9:14
        h1(i,:,irx)=(h1(12,:,irx)- h1(8,:,irx)).*(i-8)/4+h1(8,:,irx);
        h2(i,:,irx)=(h2(12,:,irx)- h2(8,:,irx)).*(i-8)/4+h2(8,:,irx);
    end

    if strcmp(SubframeType,'S')
        switch Num_DwPTS_ofdm
            case 3
                h1(2:3,:,irx) = repmat(h1(1,:,irx),2,1);
                h2(2:3,:,irx) = repmat(h2(1,:,irx),2,1);
            case {9,10,11}
                for i = 9:11
                    h1(i,:,irx) = (h1(8,:,irx) - h1(5,:,irx)).*(i-5)/3 + h1(5,:,irx);
                    h2(i,:,irx) = (h2(8,:,irx) - h2(5,:,irx)).*(i-5)/3 + h2(5,:,irx);
                end
        end
    end
    Output(irx,1,:,:)=h1(:,:,irx);
    Output(irx,2,:,:)=h2(:,:,irx);
end