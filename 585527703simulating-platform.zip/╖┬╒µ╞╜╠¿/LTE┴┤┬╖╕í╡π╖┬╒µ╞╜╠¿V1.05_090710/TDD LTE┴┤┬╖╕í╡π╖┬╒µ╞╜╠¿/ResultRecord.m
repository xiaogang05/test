function  [ResultRec] = ResultRecord(nSNR,Results)
%**********************************************************************
% �������ƣ� ResultRecord
% ����������ͳ�Ʋ�ͬSNR��Ľ��
% ���������
%nSNR          SNR��ѭ������
%Results       ����ͳ�ƽ���Ľṹ��
% ���������
%ResultRec     ���ý���ľ���
%
%
% �޸�����        �汾��     �޸���	      �޸�����
%-----------------------------------------------
% 2008/10/28       V1.1      ����
%**********************************************************************
global SimLinkPara
global PublicPara
global PUCCHPara
global DownlinkPara
global ResultRec

CPtype = PublicPara.CPtype;
TBSize = PublicPara.TBSize;
ResultRec.stream_BLER=[];
ResultRec.stream_BER=[];
ResultRec.stream_Throughput=[];

if strcmp(SimLinkPara,'UPRACHLink')  %PRACH
    FalseDetectPro = Results. FalseDetectNum / Results.PRACHTTI;
    MissDetectPro  =  Results. MissDetectNum  / Results.PRACHTTI;
    ResultRec.FalseDetectPro(nSNR) = FalseDetectPro ;%���ͳ��
    ResultRec.MissDetectPro(nSNR) = MissDetectPro ;
elseif strcmp(SimLinkPara,'UPControlLink') %PUCCH
    Config = PUCCHPara.Config ; %PUCCH �ĸ�ʽ
    if strcmp(Config,'1') ||strcmp(Config,'1a')
        ResultRec.PUCCHACKBLER(nSNR) =  Results.PUCCHACKBlockNumErr / Results.PUCCHTTI;
        fid=fopen('Result.txt','a+');
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHACKBLER);
        fclose(fid);
        if strcmp(Config,'1')
            disp('SR information BER');
            disp(ResultRec.PUCCHACKBLER);
        else
            disp('PUCCHACKBLER');
            disp(ResultRec.PUCCHACKBLER);
        end
    elseif strcmp(Config,'1b')
        ResultRec.PUCCHACKBLER(nSNR) =  Results.PUCCHACKBlockNumErr / Results.PUCCHTTI;
        ResultRec.PUCCHACKBER(nSNR) =  Results.PUCCHACKBitNumErr / Results.PUCCHTotalBitNum;
        fid=fopen('Result.txt','a+');
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHACKBLER);
        fclose(fid);
        disp('PUCCHACKBLER');
        disp(ResultRec.PUCCHACKBLER);
        disp('PUCCHACKBER');
        disp(ResultRec.PUCCHACKBER);
    elseif  strcmp(Config,'2')
        if CPtype == 0 %NOR CP  ��ʽ2������ACK��Ϣ
            ResultRec.PUCCHCQIBLER(nSNR) = Results. PUCCHCQINumErr/ Results.PUCCHTTI;
            fid=fopen('Result.txt','a+');
            fprintf(fid,'Result= %f\n', ResultRec.PUCCHCQIBLER);
            fclose(fid);
            disp('PUCCHCQIBLER');
            disp(ResultRec.PUCCHCQIBLER);
        else %EXT CP  ��ʽ2����ACK��Ϣ
            ResultRec.PUCCHACKBLER(nSNR) =  Results.PUCCHACKBlockNumErr / Results.PUCCHTTI;
            ResultRec.PUCCHACKBER(nSNR) =  Results.PUCCHACKBitNumErr / Results.PUCCHTotalBitNum;
            ResultRec.PUCCHCQIBLER(nSNR) = Results. PUCCHCQINumErr/ Results.PUCCHTTI;
            fid=fopen('Result.txt','a+');
            fprintf(fid,'Result= %f\n', ResultRec.PUCCHACKBLER);
            fprintf(fid,'Result= %f\n', ResultRec.PUCCHCQIBLER);
            fclose(fid);
            disp('PUCCHCQIBLER');
            disp(ResultRec.PUCCHCQIBLER);
            disp('PUCCHACKBLER');
            disp(ResultRec.PUCCHACKBLER);
            disp('PUCCHACKBER');
            disp(ResultRec.PUCCHACKBER);
        end
    elseif  strcmp(Config,'2a')
        ResultRec.PUCCHACKBLER(nSNR) =  Results.PUCCHACKBlockNumErr / Results.PUCCHTTI;
        ResultRec.PUCCHCQIBLER(nSNR) = Results. PUCCHCQINumErr/ Results.PUCCHTTI;
        fid=fopen('Result.txt','a+');
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHACKBLER);
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHCQIBLER);
        fclose(fid);
        disp('PUCCHCQIBLER');
        disp(ResultRec.PUCCHCQIBLER);
        disp('PUCCHACKBLER');
        disp(ResultRec.PUCCHACKBLER);
    else strcmp(Config,'2b')
        ResultRec.PUCCHACKBLER(nSNR) =  Results.PUCCHACKBlockNumErr / Results.PUCCHTTI;
        ResultRec.PUCCHACKBER(nSNR) =  Results.PUCCHACKBitNumErr / Results.PUCCHTotalBitNum;
        ResultRec.PUCCHCQIBLER(nSNR) = Results. PUCCHCQINumErr/ Results.PUCCHTTI;
        fid=fopen('Result.txt','a+');
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHACKBLER);
        fprintf(fid,'Result= %f\n', ResultRec.PUCCHCQIBLER);
        fclose(fid);
        disp('PUCCHCQIBLER');
        disp(ResultRec.PUCCHCQIBLER);
        disp('PUCCHACKBLER');
        disp(ResultRec.PUCCHACKBLER);
        disp('PUCCHACKBER');
        disp(ResultRec.PUCCHACKBER);
    end
elseif strcmp(SimLinkPara,'UPDataLink') %PUSCH
    ResultRec.BER (nSNR,:) =  Results.TotalErrorBit./ Results.TotalBit;
    if PublicPara.HARQFlag == 1
        MaxNumHARQ = PublicPara.MaxNumHARQ;    %HARQ����ش�����
        ResultRec.BLER(nSNR) =  Results.ErrorTBNum(MaxNumHARQ,:)./ Results.TBNum;
    else
        ResultRec.BLER(nSNR,:) =  Results.ErrorTBNum./ Results.TBNum;
    end
    ResultRec.Throughput(nSNR) =  Results.TBNum.*(1- ResultRec.BLER(nSNR))*(TBSize^2)/Results.TotalBit;
    %%%%%% TDD: Add Throughput output %%%%%%
    fid=fopen('Result.txt','a+');
    fprintf(fid,'Result= %f\n',  ResultRec.BER) ;
    fprintf(fid,'Result= %f\n',   ResultRec.BLER);
    fprintf(fid,'Result= %f\n',   ResultRec.Throughput);
    fclose(fid);
elseif strcmp(SimLinkPara,'DownDataLink')    %����ҵ�����
    switch DownlinkPara.Linkmode
        case 'PBCH'
            ResultRec.Control_BLER (nSNR)  =  Results.PBCH_Block_Err_Num/Results.Contorl_Block_Num;
        case 'PCFICH'
            ResultRec.Control_BLER (nSNR) = Results.PCFICH_Block_Err_Num/Results.Contorl_Block_Num;
        case 'PHICH'
            ResultRec.Control_BLER (nSNR) =  Results.PHICH_Block_Err_Num/Results.Contorl_Block_Num;
        case 'PDCCH'
            ResultRec.Control_BLER (nSNR) =  Results.PDCCH_Block_Err_Num/Results.Contorl_Block_Num;
            %         end
            %         if Channel_Types == 1||Channel_Types == 2
        case 'PDSCH'
            if PublicPara.HARQFlag == 0
                ResultRec.stream_BER(:,nSNR) = Results.Stream_Bit_Err_Num./Results.BitTotalNum;
                ResultRec.BER(nSNR)  =   sum(Results.Stream_Bit_Err_Num)/sum(Results.BitTotalNum);
                ResultRec.stream_BLER(:,nSNR) = Results.Stream_Block_Err_Num./Results.TBNum;
                ResultRec.BLER(nSNR)  =  sum(Results.Stream_Block_Err_Num)/sum(Results.TBNum);
                ResultRec.stream_Throughput(:,nSNR) = TBSize * (1-ResultRec.stream_BLER(:,nSNR))*DownlinkPara.NumStream;
                ResultRec.Throughput(nSNR) = TBSize * (1-ResultRec.BLER(nSNR))*DownlinkPara.NumStream;
            else
                ResultRec.stream_BLER(:,nSNR) = Results.ErrorTBNum(PublicPara.MaxNumHARQ,:)./Results.TBNum;
                ResultRec.BLER(nSNR) = sum(Results.ErrorTBNum(PublicPara.MaxNumHARQ,:))/sum(Results.TBNum);
                ResultRec.stream_Throughput(:,nSNR) = Results.TBNum.*(1-ResultRec.stream_BLER(:,nSNR))*TBSize/PublicPara.SubFrameCount;
                ResultRec.Throughput(nSNR) = sum(Results.TBNum)*(1-sum(ResultRec.BLER(nSNR)))*TBSize/PublicPara.SubFrameCount;
            end
            fid=fopen('Result.txt','a+t');
            fprintf(fid,'PDSCH_stream_BLER = %f\n',ResultRec.stream_BLER);
            fprintf(fid,'PDSCH_BLER = %f\n',ResultRec.BLER);
            fprintf(fid,'PDSCH_stream_Throughput = %f\n',ResultRec.stream_Throughput);
            fprintf(fid,'PDSCH_Throughput = %f\n',ResultRec.Throughput);
            fclose(fid);
    end
elseif strcmp(SimLinkPara,'DownSyncLink') %ͬ���ŵ�
    ResultRec.CellSearchRatio(nSNR) = Results.CellSearchSeccessed/PublicPara. TotalNframe(nSNR);
    ResultRec.CellIDIdentify(nSNR) = Results.CellIDIdentifyAll;
    ResultRec.FreoffsetValue(nSNR)  = round(Results.FreoffsetValue*15e3);
    if CPtype == 0
        CPLengthNormal=144*(PublicPara.FFTNum/2048);
        CPLength      =160*(PublicPara.FFTNum/2048);
        ResultRec.CellSearchTime(nSNR)  =  Results.TimingValue-PublicPara.FFTNum*2-CPLengthNormal*2-CPLength-1;
    else
        CPLengthExtend=512*(PublicPara.FFTNum/2048);
        ResultRec.CellSearchTime(nSNR)  =  Results.TimingValue-PublicPara.FFTNum*2-CPLengthExtend*3-1;
    end
end
save ResultRec ResultRec;
% %**************************************************************************
% %��ͼ�������ʾ �׶� �����Ҫ��ͼ�Ļ�
% Results_Plot(ResultRec)
% %**************************************************************************
