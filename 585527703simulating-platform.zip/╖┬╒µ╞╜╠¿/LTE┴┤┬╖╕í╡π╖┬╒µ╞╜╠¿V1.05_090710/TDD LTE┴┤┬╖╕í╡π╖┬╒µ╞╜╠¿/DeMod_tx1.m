%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function output = DeMod_tx1(data,H_temp,NSR,DeMIMOType)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��������Ϊ1ʱ����㷨

switch DeMIMOType
    case 'ZF'   % ZF
        DataR = sum(data.*conj(H_temp),1);
        DataZF = sum(conj(H_temp).*H_temp,1);
        output = DataR./DataZF;
    case 'MMSE'   % MMSE
        DataR = sum(data.*conj(H_temp),1);
        DataMMSE = sum(conj(H_temp).*H_temp,1) + NSR;
        output = DataR./DataMMSE;
    case 'MF'   % MF
        output = sum(data.*conj(H_temp),1);
end