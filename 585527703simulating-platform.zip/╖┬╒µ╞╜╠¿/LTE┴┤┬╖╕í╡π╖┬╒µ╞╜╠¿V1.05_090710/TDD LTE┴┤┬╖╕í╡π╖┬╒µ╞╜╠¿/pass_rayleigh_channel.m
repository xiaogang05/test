function ofdm_rx = pass_rayleigh_channel(signal)
%************************************************************************
%*  Copyright 2008 by LTE TDD.      All rights reserved.
%*  This software is PROPRIETARY and CONFIDENTIAL
%************************************************************************
% ��Ȩ���� (C)2008, ����ͨѶ
%
% �ļ����ƣ�PassRadioChannel
% �ļ���ʶ��
% ����ժҪ�����ļ���LTE������·����ƽ̨��Raileigh�����ŵ�ģ��
% ����˵������
% ��ǰ�汾��V0.1
% ��    �ߣ������㷨��LTE��Ŀ��
% ������ڣ�2008/11/24
%
% �޸�����        �汾��     �޸���	      �޸�����
%-------------------------------------------------------------------------
% 2008/11/24 	  V0.1	     ���	          ����
% 2009
%**************************************************************************
%��ģ������AWGN����ط�SCME�ŵ����棬��MIMOģʽ�£�ÿ���Ӿ�˥���������
%*************************************************************************
global Channel
global PublicPara
global UplinkPara
global DownlinkPara

condition_rayleigh = Channel.condition_rayleigh;
Speed = PublicPara.UEspeed;

if  strcmp(Channel.Direction,'D')  % ����
    Num_Rx = PublicPara.Num_UEAnt;
    Num_Tx = PublicPara.Num_eNBAnt;  
else % ����
    Num_Tx = UplinkPara.NumUser;
    Num_Rx = PublicPara.Num_eNBAnt;
end

N_multi = length(Channel.PathDelay);
delay_path = Channel.PathDelay;
power_path = Channel.power_path;
angle_path = Channel.angle*pi/180;
data_length = size(signal,2);
phase_path = Channel.path_phase;

Receive_signal = zeros(Num_Rx,data_length);

if (PublicPara.Channel == 0) && (Num_Tx == Num_Rx) %AWGN�ŵ�����ֱͨ��ʽ������MIMO����£�
    
    if Num_Tx>1 && DownlinkPara.modeOperation == 1
        error('Precoding mode can not be uesd in AWGN Channel!');
    end
    
    signal1 = zeros(Num_Tx,data_length);
    signal1(:,delay_path+1:data_length) = signal(:,1:(data_length-delay_path));
    
    if Speed ~= 0
        for ka = 1: Num_Rx
            multipath_ID = [ka,1];
            envelope(ka,:)= rayleigh_fading(multipath_ID,condition_rayleigh);
        end
    else  % speed ==0
        envelope = ones(Num_Rx,data_length);
    end
    
    Receive_signal = signal1.*envelope;

else
    for n=1:N_multi
        
        if Channel.CellType == 0    %  �����߼��ŵ��������ɣ�ģ��΢΢С��
            
            path_delay = delay_path(n);

            signal1 = zeros(Num_Tx,data_length);
            signal1(:,path_delay+1:data_length) = signal(:,1:(data_length-path_delay));

            signal2 = signal1 * sqrt(power_path(n));
            
            signal3 = signal2 * exp(j*phase_path(n));

            if Speed ~= 0
                for ka = 1: Num_Rx*Num_Tx
                    multipath_ID = [ka,n];
                    envelope(ka,:)= rayleigh_fading(multipath_ID,condition_rayleigh);
                end
            else  % speed ==0
                envelope = ones(Num_Rx*Num_Tx,data_length);
            end

            signal4 = zeros(Num_Rx,data_length);
            for tx = 1:Num_Tx
                %%%%��tx�����߷������ݾ����ŵ���Ľ�������%%%%%%%%%%
                signal4 =signal4+envelope((tx-1)*Num_Rx+1:tx*Num_Rx,:).*repmat(signal3(tx,:),[Num_Rx,1]);
            end

            Receive_signal = Receive_signal+signal4;

        else   % Channel.CellType==1,���ŵ����ɷ�ʽ���ö�������һ����������ݵ���ʸ����ʽ����
            
            %%���ɷ���˵���ʸ������������ʽ
            for ka=1:PublicPara.Num_eNBAnt              
                temp = -2*(ka-1)*pi*PublicPara.Dis_eNBAnt*sin(angle_path(n,ka));
                path_weight(ka)=cos(temp)+j*sin(temp);
            end
            
           if  strcmp(Channel.Direction,'D')  % ����
               signal0=path_weight*signal;	
               signal1 = zeros(1,data_length);
           else
               signal0=signal;
               signal1 = zeros(PublicPara.Num_UEAnt,data_length);
           end
           
           %����ʱ�� ����
           path_delay = delay_path(n);           
           signal1(:,path_delay+1:data_length) = signal0(:,1:(data_length-path_delay));           
           signal2 = signal1 * sqrt(power_path(n));
           signal3 = signal2 * exp(j*phase_path(n));
           
           if Speed ~= 0
               for  ka = 1:PublicPara.Num_UEAnt
                   multipath_ID = [ka,n];
                   envelope(ka,:)= rayleigh_fading(multipath_ID,condition_rayleigh);
               end
           else  % speed ==0
               envelope = ones(PublicPara.Num_UEAnt,data_length);
           end

           if  strcmp(Channel.Direction,'D')  % ����
               Receive_signal = Receive_signal + envelope.*repmat(signal3,PublicPara.Num_UEAnt,1);
           else
               for  ka = 1:PublicPara.Num_UEAnt
                   Receive_signal = Receive_signal+path_weight.'*(envelope(ka,:).*signal3(ka,:));
               end
           end
             
        end     %corresponding to if Channel.CellType

    end      % corresponding to for n=1:N_multi
end

ofdm_rx = Receive_signal;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function envelope = rayleigh_fading(multipath_ID,condition_rayleigh)

global PublicPara
global System_clock
global Channel
global SimLinkPara
global PRACHPara
global MethodPara

n_block = System_clock(1);  % frame number
frame = System_clock(2);  % subframe number
rayleigh_parameter = Channel.rayleigh_parameter;
ka = multipath_ID(1);  % multipath number
multipath = multipath_ID(2);  % multipath number
k1k2  = size(condition_rayleigh,2);
d_n1  = ceil(k1k2/2);  % the default value: d_n1 = d_n2 + 1
d_n2  = floor(k1k2/2);
f1    = rayleigh_parameter(1, 1:d_n1);
c1    = rayleigh_parameter(2, 1:d_n1);
f2    = rayleigh_parameter(3, 1:d_n2);
c2    = rayleigh_parameter(4, 1:d_n2);
Fs = PublicPara.Fs * PublicPara.OverSampleRate;

cita1 = condition_rayleigh(multipath, 1:d_n1, ka);
cita2 = condition_rayleigh(multipath, (d_n1+1):(d_n1+d_n2), ka);

if strcmp(Channel.Direction,'D') && MethodPara.BFFlag == 1         %  added by libin 090511
   TS_start = (n_block-1)*Fs*10^-2+(frame+5-1)*10^-3*Fs-1;
else
    TS_start = (n_block-1)*Fs*10^-2+(frame-1)*10^-3*Fs-1;
end

if strcmp(SimLinkPara,'UPRACHLink') && PRACHPara.RACHTime>1  %��Ը��ֳ������õ�RACH��ʽ
    RACHTime = PRACHPara.RACHTime;
    d_t = TS_start : 128 :TS_start + Fs*10^-3*RACHTime;
else
    d_t = TS_start : 128 :TS_start + Fs*10^-3;  % length(d_t) = 57 is for interpolation
end

M = length(d_t);
temp1 = zeros(1, M);
temp2 = zeros(1, M);

for loop = 1 : d_n1
    temp1 = temp1 + c1(loop) * cos(f1(loop)*d_t+cita1(loop));
end
for loop = 1 : d_n2
    temp2 = temp2 + c2(loop) * cos(f2(loop)*d_t+cita2(loop));
end

temp = temp1 + j * temp2;

% interpolation
x  = 0 : M-1;
xi = 0 : 1/128 : M-1;  % 0.0078125 = 1/128
env = interp1(x, temp, xi, '*linear');  % '*linear' for linear interpolation, or '*cubic' for cubic interpolation

if strcmp(SimLinkPara,'UPRACHLink') && PRACHPara.RACHTime<1
    Length = round(Fs*10^-3*PRACHPara.RACHTime)+1;
    envelope = env(2: Length);
else
    envelope = env(2 : end);
end
