function [insertdata control_idxSC Len] = insert_PCFICH(insertdata,tti,control_idxSC,Len)
%  ����˵��������CFI��Ϣ�����м��ţ����ƣ���ӳ�䣬Ԥ���룬������Դӳ�����  zt 080604
global PublicPara
global DownlinkPara

Num_Control_OFDM = DownlinkPara.LengthCon;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_RB = PublicPara.MaxRB;              % zt 080722
Cell_ID = PublicPara.NcellID;
linkmode = DownlinkPara.Linkmode;

%  ������Դӳ��λ��
control_idxSC_1 = control_idxSC(1:Len(1));
control_idxSC_other = control_idxSC(Len(1)+1:end);
RE_group_PCFICH = reshape(control_idxSC_1,4,length(control_idxSC_1)/4);

k0 = RE_group_PCFICH(:,mod(6*mod(Cell_ID,2*Num_RB),Num_RB*12)/6+1).';
k1 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(Num_RB/2)*6),Num_RB*12)/6+1).';
k2 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(2*Num_RB/2)*6),Num_RB*12)/6+1).';
k3 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(3*Num_RB/2)*6),Num_RB*12)/6+1).';

if strcmp(linkmode,'PDSCH') || strcmp(linkmode,'PBCH')   %% ��ҵ���PBCH���ܷ��棬PBCH����λ�ò���0����
    %  ������Դӳ��
    insertdata(1:Num_Ant_Tx,k0) = zeros(Num_Ant_Tx,4);
    insertdata(1:Num_Ant_Tx,k1) = zeros(Num_Ant_Tx,4);
    insertdata(1:Num_Ant_Tx,k2) = zeros(Num_Ant_Tx,4);
    insertdata(1:Num_Ant_Tx,k3) = zeros(Num_Ant_Tx,4);       
else    
     %  ����CFI��Ϣ����
    switch Num_Control_OFDM
        case 1
            Data_CFI = [0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1];
        case 2
            Data_CFI = [1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0];
        case 3
            Data_CFI = [1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1];
        case 4
            Data_CFI = zeros(1,32);
    end
  
    %  ����
    Cint = tti * (2*Cell_ID+1) * 2^9 + Cell_ID;  % ����830����  zt 080715
    Data_CFI_scrambled = Scrambling(Data_CFI,Cint);
    %  QPSK����
    Data_CFI_modulated = Modulator(Data_CFI_scrambled,1);
    %  ��ӳ��
    nSymb = length(Data_CFI_modulated);
    if Num_Ant_Tx == 1
        Data_layermapped = Data_CFI_modulated;
    else
        switch Num_Ant_Tx
            case 2 % 1:2 ӳ��ģʽ
                Data_layermapped = zeros(2, nSymb/2);

                Data_layermapped(1, :) = Data_CFI_modulated(1, 1:2:end );
                Data_layermapped(2, :) = Data_CFI_modulated(1, 2:2:end);
            case 4 % 1:4 ӳ��ģʽ
                Data_layermapped = zeros(4, nSymb/4);

                Data_layermapped(1, :) = Data_CFI_modulated(1, 1:4:end);
                Data_layermapped(2, :) = Data_CFI_modulated(1, 2:4:end);
                Data_layermapped(3, :) = Data_CFI_modulated(1, 3:4:end);
                Data_layermapped(4, :) = Data_CFI_modulated(1, 4:4:end);
        end
    end
    %  Ԥ����
    if Num_Ant_Tx == 1
        Data_precoded = Data_layermapped;
    else
        Data_precoded = sfbc_encode(Data_layermapped);
    end
    %  ������Դӳ��
    insertdata(1:Num_Ant_Tx,k0) = Data_precoded(:,1:4);
    insertdata(1:Num_Ant_Tx,k1) = Data_precoded(:,5:8);
    insertdata(1:Num_Ant_Tx,k2) = Data_precoded(:,9:12);
    insertdata(1:Num_Ant_Tx,k3) = Data_precoded(:,13:end);
end

%  ���Ʒ���ӳ�����ز���Ÿ���
for i = 1:4
    control_idxSC_1((control_idxSC_1 == k0(i))) = [];
    control_idxSC_1((control_idxSC_1 == k1(i))) = [];
    control_idxSC_1((control_idxSC_1 == k2(i))) = [];
    control_idxSC_1((control_idxSC_1 == k3(i))) = [];
end
control_idxSC = [control_idxSC_1 control_idxSC_other];
Len(1) = length(control_idxSC_1);

DownlinkPara.control_idxSC_PCFICH = control_idxSC;
DownlinkPara.control_idxSC_PCFICH_Len = Len;

insertdata((insertdata == 100)) = 0;