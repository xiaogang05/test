function [ output ] = turbo_encode_PDSCH(input)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program Name: turbo_encoder
% CopyRight: (C)2008, ZTE Corporation. All Rights Reserved
% Program Author: LIU Lei(ID: 140174)
%==============================================================================
% Program Function: perform attachment of CRC code element.
% 
% Input Argument:   
% input             - code block after segmentation
%
% Output Argument:  
% output            - code block after Turbo encoded
% outLen            - length of output
%
% Calling Function: 
% Encode_ConstituentEncode.mexw32
% Encode_TurboPuncture.mexw32
% RateMatching.mexw32
%
%==============================================================================
% Version History:
% 2008-01-17 V1.0  -- Initial creation
%
% Version Now: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����������
% -------------------------------------------------------------------------
% addpath chk
% error(chk_param(input, 'vector', 'real', 'integer'));

% ִ��Turbo����
% -------------------------------------------------------------------------
c = input;
cbLen = length(c);

% ȷ��������Ӧ�Ľ�֯�����е�����������188
load QPP_EM.mat
paramTab_Turbo_internal_interleaver = QPP_EM;

K  = paramTab_Turbo_internal_interleaver(:, 1);
f1 = paramTab_Turbo_internal_interleaver(:, 2);
f2 = paramTab_Turbo_internal_interleaver(:, 3);

n = find(paramTab_Turbo_internal_interleaver(:, 1) == cbLen);

for k = 1 : K(n)
    idxInterleaving(k) = mod(f1(n) * (k-1) + f2(n) * (k-1)^2, K(n)) + 1;
end

% 1st Constituent Encoder
[ conEnc1 ] = Encode_ConstituentEncode(c, 1); 

% Internal Interleaver for output of 1st Constituent Encoder
c_interleaved = c(idxInterleaving); 

% 2nd Constituent Encoder
[ conEnc2 ] = Encode_ConstituentEncode(c_interleaved, 2);  

% Turbo Puncture
idxPuncPatern = 6;
[ temp ] = Encode_TurboPuncture(conEnc1, conEnc2, idxPuncPatern);          % �Ա�������ݽ���ɾ��

outLen = 3*length(input)+12;      %   zt  080619

% Rate Matching inside Turbo
[ output ] = RateMatching(temp, outLen);