%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DeBitScramble = bit_descramble(Input,scrambling_sequence)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�bit_descramble
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 142372)
%==============================================================================
% ����˵��:   ���š�
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [row col] = size(Input);
temp = -2.*scrambling_sequence+1;    %  zt  090427
DeBitScramble = temp.*Input;
% for i_col = 1:col
%     if scrambling_sequence(i_col) == 1
%         DeBitScramble(i_col) = -Input(i_col);
%     else
%         DeBitScramble(i_col) = Input(i_col);
%     end
% end