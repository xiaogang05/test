function [G Num_Layer sym2bit] = Calcultation(tti,iStream)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�Calcultation
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 142372)
%==============================================================================
% ����˵��:   ��Ƶ��RE��ӳ�䡣
%
% �������:
% BW                              �� ϵͳ������
% CP_Type                         �� CP���͡�
% Number_Tx                       �� ������������
% tti                             �� ��֡���   zt
% Number_of_Control_Symbol        �� ���Ʒ�����
% Modulation_Flag                 �� ���Ʒ�ʽ
% Num_Layer                       �� ӳ�䵽�Ĳ���
%
% �������:
% G                               �� TS36.212������ƥ�䴦Ҫ�õ�
%
% ���ú������ޡ�
%==============================================================================
% �汾��ʷ:
% 2007.12.24         ���Ҵ���
%
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%
%�޸ļ�¼������36.211.820�޸�ΪTDDģʽ��G�ļ��㡣zt  080324
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% global SimParameter           % ����������ʼ��  modified by libin 080417
% global DCCH                   % ���Ʋ�����ʼ��  modified by libin 080417
global PublicPara
global DownlinkPara
global MethodPara               % BFFlagʹ�ܱ�ʾ    sy 081219

nStream = DownlinkPara.NumStream;
CP_Types = PublicPara.CPtype;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Control_OFDM = DownlinkPara.LengthCon;
nLayer = DownlinkPara.NumLayer;
ModulationMode = PublicPara.Mod;
Num_D_G_U_ofdm = PublicPara.ConfigDGUFrame; % ������֡���ã�����36.211Э���й涨������9�����÷�ʽ��
config_U_D_index = PublicPara.ConfigFrame; % ���������ã�����36.211Э���й涨������7�����÷�ʽ��
Num_RB = PublicPara.NumRB;
MaxRB = PublicPara.MaxRB;
%%%%%%%%%%%%%%%%%%
if PublicPara.BW < 1.8e6
    Num_Control_OFDM = Num_Control_OFDM+1;
end


% ����Num_Layer
if nLayer == 1
    Num_Layer = 1;
elseif nLayer == 2
    if nStream == 2
        Num_Layer = 1;
    else
        if Num_Ant_Tx == 2
            Num_Layer = 1;
        else
            Num_Layer = 2;
        end
    end
elseif nLayer == 3
    if iStream == 1
        Num_Layer = 1;
    else
        Num_Layer = 2;
    end
else
    if nStream == 1
        Num_Layer = 1;
    else
        Num_Layer = 2;
    end
end


switch ModulationMode
    case 1  %   % QPSK->0;
        sym2bit=2;
    case 2   %  16QAM->1;
        sym2bit=4;
    case 3   %  64QAM->2;
        sym2bit=6;
    otherwise
        error('error, ModulationMode is only QPSK,16QAM, 64QAM !');
end   % end of switch  Model

switch CP_Types
    case 0
        Num_Sym_perRB = 14;
        if tti == 1     %  zt  080527
            %             if MethodPara.BFFlag == 1
            %                 G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-2*12/6-9)*Num_RB-72-72*4-(2+3)*(Num_RB-6))*Num_Layer*sym2bit;     % ��ȥUE�ο��ź���ռ��λ��   sy    081219
            %             else
            PB_num = ((Num_RB>=(MaxRB/2+3))*6+((Num_RB<(MaxRB/2+3))&&(Num_RB>(MaxRB/2-3)))*(Num_RB-MaxRB/2+3))*(60-2*Num_Ant_Tx);    %  zt  090427
            switch Num_Ant_Tx
                case 1
                    G = (((Num_Sym_perRB-Num_Control_OFDM)*12-3*12/6)*Num_RB-PB_num)*Num_Layer*sym2bit;
                case 2
                    if MethodPara.BFFlag == 1
                        G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-2*4-3*3)*Num_RB-72-72*4-(4+3)*(Num_RB-6))*Num_Layer*sym2bit;
                    else
                        G = (((Num_Sym_perRB-Num_Control_OFDM)*12-3*12/3)*Num_RB-PB_num)*Num_Layer*sym2bit;
                    end
                case {4,8}
                    if Num_Control_OFDM == 1
                        if MethodPara.BFFlag == 1
                            G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-3*4-3*3)*Num_RB-72-72*4-(8+3)*(Num_RB-6))*Num_Layer*sym2bit;           %   sy  090114
                        else
                            G = (((Num_Sym_perRB-Num_Control_OFDM)*12-5*12/3)*Num_RB-PB_num)*Num_Layer*sym2bit;
                        end
                    else
                        if MethodPara.BFFlag == 1
                            G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-2*4-3*3)*Num_RB-72-72*4-(8+3)*(Num_RB-6))*Num_Layer*sym2bit;          %  sy  090114
                        else
                            G = (((Num_Sym_perRB-Num_Control_OFDM)*12-4*12/3)*Num_RB-PB_num)*Num_Layer*sym2bit;
                        end
                    end
            end
            %             end
        elseif tti == 6   %  zt  080527
            %             if MethodPara.BFFlag == 1
            %                  G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/6-12)*Num_RB-72)*Num_Layer*sym2bit;                 %  sy  081219
            %             else
            ss_num = ((Num_RB>=(MaxRB/2+3))*6+((Num_RB<(MaxRB/2+3))&&(Num_RB>(MaxRB/2-3)))*(Num_RB-MaxRB/2+3))*72;   %  zt  090427
            switch Num_Ant_Tx
                case 1
                    G = (((Num_Sym_perRB-Num_Control_OFDM)*12-3*12/6)*Num_RB-ss_num)*Num_Layer*sym2bit;
                case 2
                    if MethodPara.BFFlag == 1
                        G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/3-4*3)*Num_RB-72)*Num_Layer*sym2bit;
                    else
                        G = (((Num_Sym_perRB-Num_Control_OFDM)*12-3*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                    end
                case {4,8}
                    if Num_Control_OFDM == 1
                        if MethodPara.BFFlag == 1
                            G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-5*12/3-4*3)*Num_RB-72)*Num_Layer*sym2bit;       % sy  090114
                        else
                            G = (((Num_Sym_perRB-Num_Control_OFDM)*12-5*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        end
                    else
                        if MethodPara.BFFlag == 1
                            G = ((Num_Sym_perRB*12-Num_Control_OFDM*12-4*12/3-4*3)*Num_RB-72)*Num_Layer*sym2bit;       % sy  090114
                        else
                            G = (((Num_Sym_perRB-Num_Control_OFDM)*12-4*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        end
                    end
            end
            %             end
        elseif strcmp(config_U_D_index(tti),'S')  %  zt  080527
            if MaxRB <= 10
                Num_Control_ofdm_DwPTS = 2;
            else
                if Num_Control_OFDM > 1
                    Num_Control_ofdm_DwPTS = 2;
                end
            end
            Num_DwPTS_ofdm = Num_D_G_U_ofdm(1);
            ss_num = ((Num_RB>=(MaxRB/2+3))*6+((Num_RB<(MaxRB/2+3))&&(Num_RB>(MaxRB/2-3)))*(Num_RB-MaxRB/2+3))*72;    %  zt  090427
            switch Num_DwPTS_ofdm
                case 3
                    switch Num_Ant_Tx
                        case {1,2}
                            G = ((Num_DwPTS_ofdm-Num_Control_ofdm_DwPTS)*12*Num_RB-ss_num)*Num_Layer*sym2bit;
                        case 4
                            if Num_Control_ofdm_DwPTS == 1
                                G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                            else
                                G = ((Num_DwPTS_ofdm-Num_Control_ofdm_DwPTS)*12*Num_RB-ss_num)*Num_Layer*sym2bit;
                            end
                    end
                case {9,10,11}
                    switch Num_Ant_Tx
                        case 1
                            G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-2*12/6)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        case 2
                            G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-2*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        case 4
                            if Num_Control_ofdm_DwPTS == 1
                                G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-4*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                            else
                                G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-3*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                            end
                    end
                case {12,14}
                    switch Num_Ant_Tx
                        case 1
                            G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-3*12/6)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        case 2
                            G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-3*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                        case 4
                            if Num_Control_ofdm_DwPTS == 1
                                G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-5*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                            else
                                G = ((Num_DwPTS_ofdm*12-Num_Control_ofdm_DwPTS*12-4*12/3)*Num_RB-ss_num)*Num_Layer*sym2bit;
                            end
                    end
            end
        else
            %             if MethodPara.BFFlag == 1
            %                 G = (Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/6-12)*Num_RB*Num_Layer*sym2bit;        %  sy  081219
            %             else
            switch Num_Ant_Tx
                case 1
                    G = (Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/6)*Num_RB*Num_Layer*sym2bit;      %  zt  080526
                case 2
                    if MethodPara.BFFlag == 1
                        G = (Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/3-4*3)*Num_RB*Num_Layer*sym2bit;
                    else
                        G = (Num_Sym_perRB*12-Num_Control_OFDM*12-3*12/3)*Num_RB*Num_Layer*sym2bit;      %  zt  080526
                    end
                case {4,8}
                    if Num_Control_OFDM == 1
                        if MethodPara.BFFlag == 1
                            G = (Num_Sym_perRB*12-Num_Control_OFDM*12-5*12/3-4*3)*Num_RB*Num_Layer*sym2bit;        %  sy  090114
                        else
                            G = (Num_Sym_perRB*12-Num_Control_OFDM*12-5*12/3)*Num_RB*Num_Layer*sym2bit;  %  zt  080526
                        end
                    else
                        if MethodPara.BFFlag == 1
                            G = (Num_Sym_perRB*12-Num_Control_OFDM*12-4*12/3-4*3)*Num_RB*Num_Layer*sym2bit;         %  sy  091014
                        else
                            G = (Num_Sym_perRB*12-Num_Control_OFDM*12-4*12/3)*Num_RB*Num_Layer*sym2bit;  %  zt  080526
                        end
                    end
                otherwise
                    disp('wrong Num_Ant_Tx')
            end
            %             end
        end
    case 1

    otherwise
        disp('wrong CP type')
end