function [ofdm_data_tx_pure ofdm_data_tx_pure_AdCell]= insert_data_normal(data_precoded,data_precoded_AdCell)  %  zt 080527
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�insert_data_normal
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara
global DownlinkPara
global MethodPara                 % sy  081219
global Resource_Grid_ue_dl           % sy  081219
global BF_weight

Num_Ant_Tx = PublicPara.Num_eNBAnt;
CP_Types = PublicPara.CPtype;
N_Symbol_PerRB = PublicPara.OFDMSymbolNum;
Resource_Grid_Empty = DownlinkPara.Resource_Grid_Empty;
BFFlag = MethodPara.BFFlag;       % sy
Num_UE_sc = PublicPara.NumRB * 12;

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090317
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    Resource_Grid_Empty_AdCell = DownlinkPara.Resource_Grid_Empty_AdCell;  
    Resource_Grid_temp_AdCell = DownlinkPara.Resource_Grid_AdCell;
    ofdm_data_tx_pure_AdCell = [];
end

if BFFlag == 1
    data_precoded_temp = repmat(data_precoded,Num_Ant_Tx,1);    %  zt  090427
else
    data_precoded_temp = data_precoded;
end

switch CP_Types
    case 0    % Normal CP        
        for i_N_Symbol_PerRB = 1:N_Symbol_PerRB
            Length_1 = length(find(Resource_Grid_Empty((i_N_Symbol_PerRB-1)*Num_Ant_Tx+1,:) == 0));
            if Length_1 ~= 0
                Resource_Grid_Empty((i_N_Symbol_PerRB-1)*Num_Ant_Tx+(1:Num_Ant_Tx),(Resource_Grid_Empty((i_N_Symbol_PerRB-1)*Num_Ant_Tx+1,:) == 0)) = data_precoded_temp(:,1:Length_1);
                data_precoded_temp(:,1:Length_1) = [];
            end
        end
        if ~isempty(data_precoded_temp)
            error('the resource mapping is wrong');
        end

    case 1   % Extended CP

    otherwise
        dsip('wrong CP_Types')
end
% end

DownlinkPara.Resource_Grid_Empty = Resource_Grid_Empty;

insertdata = Resource_Grid_Empty;
insertdata((insertdata == 100)) = 0;

%%%%���뵼Ƶ�����%%%%%%%%%%%%%%%%%%%%%%%%
Resource_Grid_temp = DownlinkPara.Resource_Grid;
Resource_Grid_temp((DownlinkPara.Resource_Grid == 100)) = 0;

if BFFlag == 1
    Resource_Grid_temp_ue = Resource_Grid_ue_dl;                                            %  sy   081219
    Resource_Grid_temp_ue((Resource_Grid_ue_dl == 100)) = 0;                                %  sy   081219
    ofdm_data_tx_pure = Resource_Grid_temp + Resource_Grid_temp_ue + insertdata;         %  sy   081219
    
    Resource_Grid_BF_temp = DownlinkPara.Resource_Grid(1:Num_Ant_Tx:end,:).';
    Num_Occupied_sc = size(Resource_Grid_BF_temp,1);
    TxData_BFValue = ones(Num_Occupied_sc,N_Symbol_PerRB,Num_Ant_Tx);
    for num_Tx = 1:Num_Ant_Tx
        BF_temp = BF_weight(:,:,num_Tx);
        TxData_BFValue(1:Num_UE_sc, :,num_Tx) = BF_temp;
        TxData_BFValue_temp = TxData_BFValue(:,:,num_Tx);
        TxData_BFValue_temp(Resource_Grid_BF_temp~=0) = 1;

        ofdm_data_tx_pure(num_Tx: Num_Ant_Tx: end , :) = ofdm_data_tx_pure(num_Tx:Num_Ant_Tx:end,:) .* TxData_BFValue_temp';
    end

else
    ofdm_data_tx_pure = Resource_Grid_temp + insertdata;
end



if AdCellFlag == 1               %added by libin 090317
    for k = 1: AdCellNum        
        data_precoded_temp = data_precoded_AdCell{k};
        
        switch CP_Types
            case 0    % Normal CP
                for i_N_Symbol_PerRB = 1:N_Symbol_PerRB
                    Length_1 = length(find(Resource_Grid_Empty_AdCell{k}((i_N_Symbol_PerRB-1)*Num_Ant_Tx+1,:) == 0));
                    if Length_1 ~= 0
                        Resource_Grid_Empty_AdCell{k}((i_N_Symbol_PerRB-1)*Num_Ant_Tx+(1:Num_Ant_Tx),(Resource_Grid_Empty_AdCell{k}((i_N_Symbol_PerRB-1)*Num_Ant_Tx+1,:) == 0)) = data_precoded_temp(:,1:Length_1);
                        data_precoded_temp(:,1:Length_1) = [];
                    end
                end
            case 1   % Extended CP

            otherwise
                disp('wrong CP_Types')
        end
        % end

        DownlinkPara.Resource_Grid_Empty_AdCell{k} = Resource_Grid_Empty_AdCell{k};

        insertdata_AdCell = Resource_Grid_Empty_AdCell{k};
        insertdata_AdCell(insertdata_AdCell == 100) = 0;

        %%%%���뵼Ƶ�����%%%%%%%%%%%%%%%%%%%%%%%%

        Resource_Grid_temp_AdCell{k}((DownlinkPara.Resource_Grid_AdCell{k} == 100)) = 0;
        ofdm_data_tx_pure_AdCell{k} = Resource_Grid_temp_AdCell{k} + insertdata_AdCell;
    end
else
    ofdm_data_tx_pure_AdCell = [];
end
