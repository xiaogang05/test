function [TxDataInFreqDomain TxDataInFreqDomain_AdCell] = ResourceMap (CW_precoded,CW_precoded_AdCell,Pilot,Pilot_AdCell)

%%%:������Դ��Ԫӳ��ģ��
%%%�������:CW_precoded:Ԥ����ģ�����������
%           TTIIndex:��֡���
%%%�������:TxDataInFreqDomain: �����͵�Ƶ��������
% �汾��Ϣ��  Version 1.0
% �������ڣ�  2008/10/29
% �������ߣ�  ʢԨ
% ��Ȩ���У�  (C),2008,����ͨѶ�ɷ����޹�˾
%**************************************************************************
global PublicPara
global SimLinkPara
global System_clock
global DownlinkPara
global PUCCHPara

TTIIndex = System_clock(2);
CPtype = PublicPara.CPtype;
iteration = System_clock(1);

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090317
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
end

if strcmp(SimLinkPara(1:2),'UP')
    if isempty(CW_precoded)
        %�������û���RACH�ź�
        TxDataInFreqDomain  = RACHSignatureGeneration(TTIIndex);
        TxDataInFreqDomain_AdCell = [];
    elseif strcmp(SimLinkPara, 'UPDataLink')
        switch CPtype
            case 0
                TxDataInFreqDomain = [CW_precoded(:,1:3) Pilot(:,1) CW_precoded(:,4:9) Pilot(:,2) CW_precoded(:,10:12)];
                if AdCellFlag == 1               %added by libin 090317
                    for k = 1: AdCellNum
                        TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1:3) Pilot_AdCell{k}(:,1) ...
                            CW_precoded_AdCell{k}(:,4:9) Pilot_AdCell{k}(:,2) CW_precoded_AdCell{k}(:,10:12)];
                    end
                else                    
                    TxDataInFreqDomain_AdCell = [];
                end
            case 1
                TxDataInFreqDomain = [CW_precoded(:,1:3) Pilot(:,1) CW_precoded(:,4:8) Pilot(:,2) CW_precoded(:,9:10)];
                if AdCellFlag == 1               %added by libin 090317
                    for k = 1: AdCellNum
                        TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1:3) Pilot_AdCell{k}(:,1) ...
                            CW_precoded_AdCell{k}(:,4:8) Pilot_AdCell{k}(:,2) CW_precoded_AdCell{k}(:,9:10)];
                    end
                else
                    TxDataInFreqDomain_AdCell = [];
                end
        end
    elseif strcmp(SimLinkPara ,'UPControlLink')  %add by wang hui
        Config = PUCCHPara.Config;
        switch CPtype
            case 0
                if strcmp(Config(1),'1')
                    TxDataInFreqDomain = [CW_precoded(:,1:2) Pilot(:,1:3) CW_precoded(:,3:4)  CW_precoded(:,5:6) Pilot(:,4:6)  CW_precoded(:,7:8)];
                    if AdCellFlag == 1               %added by libin 090317
                        for k = 1: AdCellNum
                            TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1:2) Pilot_AdCell{k}(:,1:3) ...
                                CW_precoded_AdCell{k}(:,3:6) Pilot_AdCell{k}(:,4:6) CW_precoded_AdCell{k}(:,7:8)];
                        end
                    else
                        TxDataInFreqDomain_AdCell = [];
                    end
                else
                    TxDataInFreqDomain = [CW_precoded(:,1) Pilot(:,1) CW_precoded(:,2:4) Pilot(:,2) CW_precoded(:,5:6) Pilot(:,3) CW_precoded(:,7:9) Pilot(:,4) CW_precoded(:,10)];
                    if AdCellFlag == 1               %added by libin 090317
                        for k = 1: AdCellNum
                            TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1) Pilot_AdCell{k}(:,1) CW_precoded_AdCell{k}(:,2:4) ...
                                Pilot_AdCell{k}(:,2) CW_precoded_AdCell{k}(:,5:6) Pilot_AdCell{k}(:,3) CW_precoded_AdCell{k}(:,7:9) Pilot_AdCell{k}(:,4) CW_precoded_AdCell{k}(:,10)];
                        end
                    else                       
                        TxDataInFreqDomain_AdCell = [];
                    end
                end
            case 1
                if strcmp(Config(1),'1')
                    TxDataInFreqDomain = [CW_precoded(:,1:2) Pilot(:,1:2) CW_precoded(:,3:6) Pilot(:,3:4) CW_precoded(:,7:8)];
                    if AdCellFlag == 1               %added by libin 090317
                        for k = 1: AdCellNum
                            TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1:2) Pilot_AdCell{k}(:,1:2) CW_precoded_AdCell{k}(:,3:6) ...
                                Pilot_AdCell{k}(:,3:4) CW_precoded_AdCell{k}(:,7:8)];
                        end
                    else
                        TxDataInFreqDomain_AdCell = [];
                    end
                else
                    TxDataInFreqDomain = [CW_precoded(:,1:3) Pilot(:,1) CW_precoded(:,4:8)  Pilot(:,2) CW_precoded(:,9:10)];
                    if AdCellFlag == 1               %added by libin 090317
                        for k = 1: AdCellNum
                            TxDataInFreqDomain_AdCell{k} = [CW_precoded_AdCell{k}(:,1:3) Pilot_AdCell{k}(:,1) CW_precoded_AdCell{k}(:,4:8) ...
                                Pilot_AdCell{k}(:,2) CW_precoded_AdCell{k}(:,9:10)];
                        end
                    else
                        TxDataInFreqDomain_AdCell = [];
                    end
                end
        end
    end
elseif strcmp(SimLinkPara(1:4),'Down')
    linkmode = DownlinkPara.Linkmode;
    Num_Control_OFDM = DownlinkPara.LengthCon;
    Num_Ant_Tx = PublicPara.Num_eNBAnt;
    Num_RB = PublicPara.MaxRB;
    if isempty(CW_precoded)
        % ��������ŵ�ʱ����PDSCH����
        insertdata = DownlinkPara.Resource_Grid;
        insertdata_AdCell = DownlinkPara.Resource_Grid_AdCell;

        %%%% ��������ŵ�ʱ����PDSCH����
%         data_type = 1;  %  1:QPSK  2:16QAM  3:64QAM
%         Resource_Grid = DownlinkPara.Resource_Grid;
%         [m n] = size(Resource_Grid);
%         rand('state',20*iteration+TTIIndex);
%         PDSCH_data = randint(1,m*n*2*data_type);
%         PDSCH_data_modu = Modulator(PDSCH_data,data_type);
%         insertdata = reshape(PDSCH_data_modu,m,n);
%         insertdata(Resource_Grid~=0) = 0;
%         insertdata(1:Num_Control_OFDM*Num_Ant_Tx,:) = 0;
%         PB_loc = (Num_RB * 12)/2 + (-35:36);
%         insertdata(13*Num_Ant_Tx+1:14*Num_Ant_Tx,PB_loc) = 0;
%         insertdata(7*Num_Ant_Tx+1:11*Num_Ant_Tx,PB_loc) = 0;
%         insertdata = insertdata + Resource_Grid;
%         insertdata(insertdata == 100) = 0;
% 
%         Resource_Grid_AdCell = DownlinkPara.Resource_Grid_AdCell;
%         insertdata_AdCell = [];
        if AdCellFlag == 1
            for k = 1: AdCellNum
                Resource_Grid = Resource_Grid_AdCell{k};
                rand('state',30*iteration+TTIIndex*k);
                PDSCH_data = randint(1,m*n*2*data_type);
                PDSCH_data_modu = Modulator(PDSCH_data,data_type);
                insertdata_AdCell_temp = reshape(PDSCH_data_modu,m,n);
                insertdata_AdCell_temp(Resource_Grid~=0) = 0;
                insertdata_AdCell_temp(1:Num_Control_OFDM*Num_Ant_Tx,:) = 0;
                insertdata_AdCell_temp(13*Num_Ant_Tx+1:14*Num_Ant_Tx,PB_loc) = 0;
                insertdata_AdCell_temp(7*Num_Ant_Tx+1:11*Num_Ant_Tx,PB_loc) = 0;
                insertdata_AdCell_temp = insertdata_AdCell_temp + Resource_Grid;
                insertdata_AdCell_temp(insertdata_AdCell_temp == 100) = 0;
                insertdata_AdCell{k} = insertdata_AdCell_temp;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if strcmp(SimLinkPara,'DownSyncLink')
            %%%PSS��SSSӳ��
            [insertdata insertdata_AdCell] = insert_ss(insertdata,insertdata_AdCell,TTIIndex);
        elseif strcmp(linkmode,'PBCH')
            if TTIIndex == 1
                %%%PBCHӳ��
                [insertdata insertdata_AdCell] = insert_PBCH(insertdata,insertdata_AdCell,iteration);
            end
        else
            %%%��������ź����ز�����
            [control_idxSC ConLen] = calculate_control_index;
            DownlinkPara.control_idxSC = control_idxSC;
            DownlinkPara.ConLen = ConLen;
            %% ��ҵ���PBCH���ܷ��棬���Ʒ���λ�ò���0����
            %%%PCFICHӳ��
            [insertdata control_idxSC ConLen] = insert_PCFICH(insertdata,TTIIndex,control_idxSC,ConLen);
            %%%PHICHӳ��
            [insertdata control_idxSC ConLen] = insert_PHICH(insertdata,TTIIndex,control_idxSC,ConLen,iteration);
            %%%PDCCHӳ��
            insertdata = insert_PDCCH(insertdata,TTIIndex,control_idxSC,ConLen,iteration);
        end
    else
        %%%PDSCHӳ��
        [insertdata insertdata_AdCell] = insert_data_normal(CW_precoded,CW_precoded_AdCell);
    end
    %**************************************************************************
    TxDataInFreqDomain = insertdata;
    TxDataInFreqDomain_AdCell = insertdata_AdCell;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [control_idxSC Len] = calculate_control_index
%  ����˵������������ڿ����ŵ���������ز�����   zt
global DownlinkPara
global PublicPara

Resource_Grid = DownlinkPara.Resource_Grid;
Num_eNBAnt = PublicPara.Num_eNBAnt;

temp = Resource_Grid;
if Num_eNBAnt == 1
    temp(1,:) = temp(1,:) + temp(5,:);
end
temp = temp(1:Num_eNBAnt:Num_eNBAnt*4,:);
Len = zeros(1,4);  %modified by libin 081204
control_idxSC = [];
for i = 1:4
    temp1 = find(temp(i,:) == 0);
    control_idxSC = [control_idxSC temp1];
    Len(i) = length(temp1);
end