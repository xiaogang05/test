function [BitStream]=BinaryGeneratorPUCCH
%**********************************************************************
% �������ƣ� BinaryGeneratorPUCCH
% ���������� PUCCHԭʼbitλ���ɺ���
% ���������
% ���������
%     BitStream      �� ���ɵ�ԭʼ�����ź�
% �޸�����        �汾��     �޸���	      �޸�����
%-----------------------------------------------
% 2008/11/25     V1.0       ����           ����
%**********************************************************************
global PUCCHPara
global PublicPara
global System_clock

TTIIndex = System_clock(2);
Config = PUCCHPara.Config; %PUCCH�����ʽ����ѡ��ȡֵ��Χ����1/1a/1b/2/2a/2b��
TBSize = PublicPara.TBSize;
Seed = PublicPara.Seed;

%����PUCCH�ź����ڵ�Ƶ��λ��
for i=1:PublicPara.Num_UEAnt
    % �µ���Դ�ڴ˲���
    switch Config%????/
        case '1'
            BitStream(i,:) =1; % SR d(0) = 1
        case '1a'
            if Seed == 0
                BitStream(i,:) = randint(1);
            else
                state = 100 * TTIIndex + 10 * i + Seed;
                BitStream(i,:) = randint(1,1,[0,1],state); % 0,ACK;1,NACK,2,DTX.
            end
        case '1b'
            if Seed == 0
                BitStream(i,:) = randint(1,2);
            else
                state = 100 * TTIIndex + 10 * i + Seed;
                BitStream(i,:) = randint(1,2,[0,1],state); % 0,ACK;1,NACK,2,DTX.
            end
        case '2'
            if TBSize < 4 || TBSize > 13
                error('PUCCH CQI Bit Width is 4~13')
            else
                if Seed == 0  % db seed -> Seed  PUCCH 2 2a 2b ��TBSize��Χ��4~13
                    BitStream(i,:) = randint(1,TBSize);
                else
                    state = 100 * TTIIndex + 10 * i + Seed;  % db seed -> Seed
                    BitStream(i,:) = randint(1,TBSize,[0,1],state);
                end
            end
        case '2a'
            if TBSize < 4 || TBSize > 13
                error('PUCCH CQI Bit Width is 4~13')
            else
                if Seed == 0  % db seed -> Seed
                    BitStream(i,:) = randint(1,TBSize);
                else
                     state = 100 * TTIIndex + 10 * i + Seed;  % db seed -> Seed
                     BitStream(i,:) = randint(1,TBSize,[0 1],state);
                end
            end
             if Seed == 0  
                PUCCHPara.ACKInform(i,:) = randint(1);
            else
                state = 100 * TTIIndex + 10 * i + Seed;  
                PUCCHPara.ACKInform(i,:) = randint(1,1,[0,1],state); % 0,ACK;1,NACK,2,DTX.
            end
        case '2b'
            if TBSize < 4 || TBSize > 13
                error('PUCCH CQI Bit Width is 4~13')
            else
                if Seed == 0  % db seed -> Seed
                    BitStream(i,:) = randint(1,TBSize);
                else
                    state = 100 * TTIIndex + 10 * i + Seed;  % db seed -> Seed
                    BitStream(i,:) = randint(1,TBSize,[0 1],state);
                end
            end
            if Seed == 0
                PUCCHPara.ACKInform(i,:) = randint(1,2);
            else
                state = 100 * TTIIndex + 10 * i + Seed;
                PUCCHPara.ACKInform(i,:) = randint(1,2,[0,1],state); % 0,ACK;1,NACK,2,DTX.
            end
    end
end

