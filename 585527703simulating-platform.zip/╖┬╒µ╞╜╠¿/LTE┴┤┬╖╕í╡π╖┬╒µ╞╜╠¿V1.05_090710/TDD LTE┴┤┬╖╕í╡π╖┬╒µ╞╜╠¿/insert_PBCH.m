function [insertdata insertdata_AdCell] = insert_PBCH(insertdata,insertdata_AdCell,iteration)
%  ����˵���������㲥��Ϣ������CRC���������룬����ƥ�䣬���ţ����ƣ�������Դӳ�����  zt 080530
%  modified by libin 081126
global PublicPara
global DownlinkPara
global Data_layermapped

Num_Ant_Tx = PublicPara.Num_eNBAnt;
N_Subcarrier_PerRB = PublicPara.NumSubCarrierPRB;
Num_RB = PublicPara.MaxRB;              % zt 080722
Cell_ID = PublicPara.NcellID;
seed = PublicPara.Seed;

%  ������Դӳ��
temp = DownlinkPara.Resource_Grid;
PB_loc34 = (Num_RB * N_Subcarrier_PerRB)/2 + (-35:36);
if Num_Ant_Tx == 1
    temp(8,:) = temp(8,:) + temp(12,:);
    PB_loc12 = PB_loc34(temp(8,PB_loc34) == 0);
else
    PB_loc12 = PB_loc34(temp(7*Num_Ant_Tx+1,PB_loc34) == 0);
end

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090317
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    AdCellID = PublicPara.AdCellID;
end

% if strcmp(DownlinkPara.Linkmode,'PBCH')
if mod(iteration,4) == 1
    if seed == 1%%  �����㲥��Ϣ����
        rand('state',100 * iteration + seed);
        info_PBCH = randint(1,24);
    else
        info_PBCH = randint(1,24);
    end
    DownlinkPara.info_PBCH = info_PBCH;
    %  CRCУ��
    CrcLength_PBCH = 16;
    DataCrc = CrcEncoder(info_PBCH,CrcLength_PBCH,0);
    %  CRC����
    DataCrc(length(DataCrc)-16+1:end) = crc_scramble(DataCrc(length(DataCrc)-16+1:end),Num_Ant_Tx);
    %  ��������
    Rate = 0;    %  ��������  1/3
    Data_coded = cc_encode(DataCrc,Rate);
    DownlinkPara.Length_BCH_coded = length(Data_coded);
    %  ����ƥ��
    DataRateMatch = CB_RateMatching(Data_coded,480,[],[],0);   %  ��CP���
    DataRateMatch_copy = kron([1 1 1 1],DataRateMatch);
    %  ����
    PBCH_scrambled_temp = Scrambling(DataRateMatch_copy,Cell_ID);
    DownlinkPara.PBCH_scrambled_temp = PBCH_scrambled_temp;
    Len = length(PBCH_scrambled_temp);
    Data_scrambled = PBCH_scrambled_temp(1:Len/4);
else
    PBCH_scrambled_temp = DownlinkPara.PBCH_scrambled_temp;
    Len = length(PBCH_scrambled_temp);
    if mod(iteration,4) == 2
        Data_scrambled = PBCH_scrambled_temp(Len/4+1:Len/2);
    elseif mod(iteration,4) == 3
        Data_scrambled = PBCH_scrambled_temp(Len/2+1:Len*3/4);
    else
        Data_scrambled = PBCH_scrambled_temp(Len*3/4+1:end);
    end
end
%  QPSK����
Data_modulated = Modulator(Data_scrambled,1);
%  ��ӳ��
nSymb = length(Data_modulated);
if Num_Ant_Tx == 1
    Data_layermapped = Data_modulated;
else
    switch Num_Ant_Tx
        case 2 % 1:2 ӳ��ģʽ
            Data_layermapped = zeros(2, nSymb/2);
            Data_layermapped(1, :) = Data_modulated(1, 1:2:end );
            Data_layermapped(2, :) = Data_modulated(1, 2:2:end);
        case 4 % 1:4 ӳ��ģʽ
            Data_layermapped = zeros(4, nSymb/4);
            Data_layermapped(1, :) = Data_modulated(1, 1:4:end);
            Data_layermapped(2, :) = Data_modulated(1, 2:4:end);
            Data_layermapped(3, :) = Data_modulated(1, 3:4:end);
            Data_layermapped(4, :) = Data_modulated(1, 4:4:end);
    end
end
%  Ԥ����
if Num_Ant_Tx == 1
    Data_precoded = Data_layermapped;
else
    Data_precoded = sfbc_encode(Data_layermapped);
end

insertdata(7*Num_Ant_Tx+1:8*Num_Ant_Tx,PB_loc12) = Data_precoded(:,1:48);
insertdata(8*Num_Ant_Tx+1:9*Num_Ant_Tx,PB_loc12) = Data_precoded(:,49:96);
insertdata(9*Num_Ant_Tx+1:10*Num_Ant_Tx,PB_loc34) = Data_precoded(:,97:168);
insertdata(10*Num_Ant_Tx+1:11*Num_Ant_Tx,PB_loc34) = Data_precoded(:,169:end);

% else   %% ��PBCH���ܷ��棬PBCH����λ�ò���0����
%     insertdata(7*Num_Ant_Tx+1:8*Num_Ant_Tx,PB_loc12) = zeros(Num_Ant_Tx,48);
%     insertdata(8*Num_Ant_Tx+1:9*Num_Ant_Tx,PB_loc12) = zeros(Num_Ant_Tx,48);
%     insertdata(9*Num_Ant_Tx+1:10*Num_Ant_Tx,PB_loc34) = zeros(Num_Ant_Tx,72);
%     insertdata(10*Num_Ant_Tx+1:11*Num_Ant_Tx,PB_loc34) = zeros(Num_Ant_Tx,72);
% end

insertdata((insertdata == 100)) = 0;

if AdCellFlag == 1      %added by libin 090317
    for k = 1: AdCellNum
        if mod(iteration,4) == 1
            if seed == 1%%  �����㲥��Ϣ����
                rand('state',100 * iteration + seed);
                DataRateMatch_AdCell = randint(1,length(DataRateMatch));
            else
                DataRateMatch_AdCell = randint(1,length(DataRateMatch));
            end
            DataRateMatch_copy_AdCell = kron([1 1 1 1],DataRateMatch_AdCell);
            %  ����
            PBCH_scrambled_temp_AdCell = Scrambling(DataRateMatch_copy_AdCell,AdCellID(k));
            DownlinkPara.PBCH_scrambled_temp_AdCell{k} = PBCH_scrambled_temp_AdCell;
            Len = length(PBCH_scrambled_temp_AdCell);
            Data_scrambled_AdCell = PBCH_scrambled_temp_AdCell(1:Len/4);
        else
            PBCH_scrambled_temp_AdCell = DownlinkPara.PBCH_scrambled_temp_AdCell{k};
            Len = length(PBCH_scrambled_temp_AdCell);
            if mod(iteration,4) == 2
                Data_scrambled_AdCell = PBCH_scrambled_temp_AdCell(Len/4+1:Len/2);
            elseif mod(iteration,4) == 3
                Data_scrambled_AdCell = PBCH_scrambled_temp_AdCell(Len/2+1:Len*3/4);
            else
                Data_scrambled_AdCell = PBCH_scrambled_temp_AdCell(Len*3/4+1:end);
            end
        end
        %  QPSK����
        Data_modulated_AdCell = Modulator(Data_scrambled_AdCell,1);
        %  ��ӳ��
        nSymb_AdCell = length(Data_modulated_AdCell);
        if Num_Ant_Tx == 1
            Data_layermapped_AdCell = Data_modulated_AdCell;
        else
            switch Num_Ant_Tx
                case 2 % 1:2 ӳ��ģʽ
                    Data_layermapped = zeros(2, nSymb_AdCell/2);
                    Data_layermapped_AdCell(1, :) = Data_modulated_AdCell(1, 1:2:end );
                    Data_layermapped_AdCell(2, :) = Data_modulated_AdCell(1, 2:2:end);
                case 4 % 1:4 ӳ��ģʽ
                    Data_layermapped = zeros(4, nSymb_AdCell/4);
                    Data_layermapped_AdCell(1, :) = Data_modulated_AdCell(1, 1:4:end);
                    Data_layermapped_AdCell(2, :) = Data_modulated_AdCell(1, 2:4:end);
                    Data_layermapped_AdCell(3, :) = Data_modulated_AdCell(1, 3:4:end);
                    Data_layermapped_AdCell(4, :) = Data_modulated_AdCell(1, 4:4:end);
            end
        end
        %  Ԥ����
        if Num_Ant_Tx == 1
            Data_precoded_AdCell = Data_layermapped_AdCell;
        else
            Data_precoded_AdCell = sfbc_encode(Data_layermapped_AdCell);
        end

        temp = DownlinkPara.Resource_Grid_AdCell{k};
        PB_loc34 = (Num_RB * N_Subcarrier_PerRB)/2 + (-35:36);
        if Num_Ant_Tx == 1
            temp(8,:) = temp(8,:) + temp(12,:);
            PB_loc12 = PB_loc34(temp(8,PB_loc34) == 0);
        else
            PB_loc12 = PB_loc34(temp(7*Num_Ant_Tx+1,PB_loc34) == 0);
        end

        insertdata_AdCell{k}(7*Num_Ant_Tx+1:8*Num_Ant_Tx,PB_loc12) = Data_precoded_AdCell(:,1:48);
        insertdata_AdCell{k}(8*Num_Ant_Tx+1:9*Num_Ant_Tx,PB_loc12) = Data_precoded_AdCell(:,49:96);
        insertdata_AdCell{k}(9*Num_Ant_Tx+1:10*Num_Ant_Tx,PB_loc34) = Data_precoded_AdCell(:,97:168);
        insertdata_AdCell{k}(10*Num_Ant_Tx+1:11*Num_Ant_Tx,PB_loc34) = Data_precoded_AdCell(:,169:end);

        insertdata_AdCell{k}((insertdata_AdCell{k} == 100)) = 0;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DataCrc_scrambled = crc_scramble(DataCrc,Num_Ant_Tx)

switch Num_Ant_Tx
    case 1
        crc_mask = zeros(1,16);
    case 2
        crc_mask = ones(1,16);
    case 4
        crc_mask = [0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1];
end
DataCrc_scrambled = mod(DataCrc + crc_mask,2);