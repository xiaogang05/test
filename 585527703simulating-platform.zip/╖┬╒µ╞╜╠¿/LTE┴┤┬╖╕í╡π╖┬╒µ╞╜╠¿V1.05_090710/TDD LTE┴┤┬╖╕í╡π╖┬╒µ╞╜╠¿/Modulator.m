function modulation_data = Modulator(input,ModulationMode,index)
% ������ʵ�� LTE �涨�ĵ��Ʒ�ʽ��
%
% ���ø�ʽ:output_complex = ModulationLTE(input,channel_gain)
% �������˵����
%     input���������������Ҫ���ƾ��󣬰��н��е��ơ�
%..........................................................................
% �������˵����
%     output_complex�������������ƺ�����������������ͬinput.
%..........................................................................
% ������  Ԭ��� 172998
global SimLinkPara
global PUCCHPara

modulation_data=[];
if ~isempty(input)
    if strcmp(SimLinkPara,'UPControlLink' )            %%% ���п����ŵ�
        switch PUCCHPara.Config   %%% ���п��Ƹ�ʽ����
            case '1'
                modulation_data=input.';
            case '1a'
                modulation_data=ACK_Modulator(input);
            case '1b'
                modulation_data=ACK_Modulator(input);
            case '2'
                modulation_data=Modulator_QPSK(input);
            case '2a'
                modulation_data=Modulator_QPSK(input);
            case '2b'
                modulation_data=Modulator_QPSK(input);
        end
        [modulation_data] =DataDRSGeneration(modulation_data,index);
    else
        switch ModulationMode   %%% ������Ӧ�ĵ����Ӻ���
            case 0 %'BPSK'
                modulation_data=Modulator_BPSK(input);
            case 1 %'QPSK'
                modulation_data=Modulator_QPSK(input);
            case 2 %'16QAM'
                modulation_data=Modulator_16QAM(input);
            case 3 %'64QAM'
                modulation_data=Modulator_64QAM(input);
            otherwise
                modulation_data=input;
        end
    end
end

function modulation_data = Modulator_BPSK(input)
BPSK=[  1 +  j;
    -1 + -j] /sqrt(2);
[row, column] = size(input);
if ((column==1)&&(row>1))
    error('������������');
end
modulation_data = zeros(row,column);
for rep1 = 1:row
    modulation_data(rep1,:) = BPSK(temp1 +1);
end


function modulation_data = Modulator_QPSK(input)
QPSK = [  1+1*j           % I Q
    1-1*j
    -1+1*j
    -1-1*j]/sqrt(2);
[row, column] = size(input);
if ((column==1)&&(row>1))
    input = input.';
    [row, column] = size(input);
end
modulation_data = zeros(row,column/2);
for rep1 = 1:row
    temp = reshape(input(rep1,:),2,column/2);
    temp1 = 2 * temp(1,:) + temp(2,:);
    modulation_data(rep1,:) = QPSK(temp1+1);
end


function modulation_data = Modulator_16QAM(input)
QAM_16 = [1 + 1*j
    1 + 3*j
    3 + 1*j
    3	+ 3*j
    1 - 1*j
    1 - 3*j
    3 - 1*j
    3 - 3*j
    -1	+ 1*j
    -1	+ 3*j
    -3 + 1*j
    -3 + 3*j
    -1 - 1*j
    -1 - 3*j
    -3 - 1*j
    -3 - 3*j ]/sqrt(10);
[row, column] = size(input);
if ((column==1)&&(row>1))
    error('������������');
end
modulation_data = zeros(row,column/4);
for rep1 = 1:row
    temp = reshape(input(rep1,:),4,column/4);
    temp1 = 8 * temp(1,:) + 4 * temp(2,:) + 2 * temp(3,:) + temp(4,:);
    modulation_data(rep1,:) = QAM_16(temp1+1);
end



function modulation_data = Modulator_64QAM(input)
QAM_64 = [3 + 3*j
    3 + 1*j
    1 + 3*j
    1 + 1*j
    3 + 5*j
    3 + 7*j
    1 + 5*j
    1 + 7*j
    5 + 3*j
    5 + 1*j
    7 + 3*j
    7 + 1*j
    5 + 5*j
    5 + 7*j
    7 + 5*j
    7 + 7*j
    3 + -3*j
    3 + -1*j
    1 + -3*j
    1 + -1*j
    3 + -5*j
    3 + -7*j
    1 + -5*j
    1 + -7*j
    5 + -3*j
    5 + -1*j
    7 + -3*j
    7 + -1*j
    5 + -5*j
    5 + -7*j
    7 + -5*j
    7 + -7*j
    -3+  3*j
    -3+  1*j
    -1 + 3*j
    -1 + 1*j
    -3 + 5*j
    -3 + 7*j
    -1 + 5*j
    -1 + 7*j
    -5 + 3*j
    -5 + 1*j
    -7 + 3*j
    -7 + 1*j
    -5 + 5*j
    -5 + 7*j
    -7 + 5*j
    -7 + 7*j
    -3 + -3*j
    -3 + -1*j
    -1 + -3*j
    -1 + -1*j
    -3 + -5*j
    -3 + -7*j
    -1 + -5*j
    -1 + -7*j
    -5 + -3*j
    -5 + -1*j
    -7 + -3*j
    -7 + -1*j
    -5 + -5*j
    -5 + -7*j
    -7 + -5*j
    -7 + -7*j]/sqrt(42);
[row, column] = size(input);
if ((column==1)&&(row>1))
    error('������������');
end
modulation_data = zeros(row,column/6);
for rep1 = 1:row
    temp = reshape(input(rep1,:),6,column/6);
    temp1 = 32 * temp(1,:) + 16 * temp(2,:) + 8 * temp(3,:) + 4 * temp(4,:) + 2 * temp(5,:) + temp(6,:);
    modulation_data(rep1,:) = QAM_64(temp1+1);
end
