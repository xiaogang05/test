function [BitStream Pilot AdCellPilot]=BinaryGenerator
%**********************************************************************
% �������ƣ� BinaryGenerator             
% ���������� ԭʼbitλ����             
% ���������
% ���������
%    BitStream      �� ���ɵ�ԭʼ�����ź�
% InterUserBitStream �����ɵ�ԭʼ�����û������ź�
%  Pilot        ���뵼Ƶ�йصĲ����Ľṹ��
%**********************************************************************
global SimLinkPara
global PublicPara
global PUCCHPara

NcellID = PublicPara.NcellID;
AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090309
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    AdCellID = PublicPara.AdCellID;
end

AdCellPilot = [];

switch SimLinkPara
    case 'UPDataLink'
        [BitStream] = BinaryGeneratorPUSCH;
        [Pilot n_oc_ns Alpha_ns BaseSeq n_pie_ns] = PilotGenerating(NcellID,0);
        if AdCellFlag == 1      %added by libin 090309
            for k = 1: AdCellNum
               [AdCellPilot_temp n_oc_ns_AdCell Alpha_ns_AdCell BaseSeq_AdCell n_pie_ns] =PilotGenerating(AdCellID(k),AdCellFlag);
               AdCellPilot{k} = AdCellPilot_temp;
            end
        end            
    case 'UPControlLink'
        [BitStream] = BinaryGeneratorPUCCH;
        [Pilot PUCCHPara.n_oc_ns PUCCHPara.Alpha_ns PUCCHPara.BaseSeq PUCCHPara.n_pie_ns] =PilotGenerating(NcellID,0);
        if AdCellFlag == 1    %added by libin 090309
            for k = 1: AdCellNum
               [AdCellPilot_temp n_oc_ns_AdCell Alpha_ns_AdCell BaseSeq_AdCell n_pie_ns_AdCell] =PilotGenerating(AdCellID(k),AdCellFlag);
               AdCellPilot{k} = AdCellPilot_temp;
               PUCCHPara.n_oc_ns_AdCell{k} = n_oc_ns_AdCell;
               PUCCHPara.Alpha_ns_AdCell{k} = Alpha_ns_AdCell;
               PUCCHPara.BaseSeq_AdCell{k} = BaseSeq_AdCell;
               PUCCHPara.n_pie_ns_AdCell{k} = n_pie_ns_AdCell;
            end
        end 
    case 'DownDataLink'
        [BitStream Pilot AdCellPilot]=BinaryGeneratorPD; %����ƽ̨��û�и����û������źŲ���
    case 'DownSyncLink'
        [BitStream Pilot AdCellPilot]=BinaryGeneratorPD;
    case 'UPRACHLink'
        BitStream =[];
        Pilot = [];
        AdCellPilot =[];
end
