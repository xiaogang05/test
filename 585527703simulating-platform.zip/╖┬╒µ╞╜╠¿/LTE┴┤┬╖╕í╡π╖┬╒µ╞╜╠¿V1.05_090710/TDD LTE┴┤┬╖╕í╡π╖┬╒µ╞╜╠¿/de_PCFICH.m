function info_PCFICH_rx = de_PCFICH(ofdm_control_rx,H_Est_ALL,tti,NSR)
%  ����˵�������CFI��Ϣ  zt 080801
% global c_PCFICH
% scrambling_sequence_PCFICH = DownlinkPara.scrambling_sequence_PCFICH;
 global PublicPara
 global DownlinkPara
 global MethodPara
 
 Cell_ID = PublicPara.NcellID;
 Num_RB = PublicPara.MaxRB;
 Num_Ant_Tx = PublicPara.Num_eNBAnt;
 Num_Ant_Rx = PublicPara.Num_UEAnt;
 
 control_idxSC = DownlinkPara.control_idxSC; 
 control_idxSC_Len = DownlinkPara.ConLen;

control_idxSC_1 = control_idxSC(1:control_idxSC_Len(1));
RE_group_PCFICH = reshape(control_idxSC_1,4,length(control_idxSC_1)/4);

k0 = RE_group_PCFICH(:,mod(6*mod(Cell_ID,2*Num_RB),Num_RB*12)/6+1).';
k1 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(Num_RB/2)*6),Num_RB*12)/6+1).';
k2 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(2*Num_RB/2)*6),Num_RB*12)/6+1).';
k3 = RE_group_PCFICH(:,mod((6*mod(Cell_ID,2*Num_RB)+floor(3*Num_RB/2)*6),Num_RB*12)/6+1).';
k = [k0 k1 k2 k3];

data_PCFICH = ofdm_control_rx(1:Num_Ant_Rx,k);

channel_PCFICH = [];
for i = 1:16
    channel_PCFICH(:,:,i) = squeeze(H_Est_ALL(:,1:Num_Ant_Tx,1,k(i)));
end

if Num_Ant_Tx == 1
    channel_PCFICH_1T = reshape(channel_PCFICH,Num_Ant_Rx,length(channel_PCFICH));
    output_de_Layer_mapper_PCFICH = DeMod_tx1(data_PCFICH,channel_PCFICH_1T,NSR,MethodPara.DeMIMO);
else
    output_de_Layer_mapper_PCFICH = sfbc_decode(channel_PCFICH,data_PCFICH);
    output_de_Layer_mapper_PCFICH = reshape(output_de_Layer_mapper_PCFICH,1,[]);
end

y1 = real(output_de_Layer_mapper_PCFICH);
y0 = imag(output_de_Layer_mapper_PCFICH);
output_soft_bits = [y1; y0];
de_modulation_PCFICH = reshape(output_soft_bits,1,2*length(y1));

Cint = tti * (2*Cell_ID+1) * 2^9 + Cell_ID;  % ����830����  zt 080715
c_PCFICH = Scrambling_gen(length(de_modulation_PCFICH),Cint);
Data_CFI_temp = bit_descramble(de_modulation_PCFICH,c_PCFICH);

Data_CFI(Data_CFI_temp>0) = 0;
Data_CFI(Data_CFI_temp<0) = 1;
CFI_1 = [0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1];
CFI_2 = [1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0];
CFI_3 = [1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1 0 1 1];
CFI_4 = zeros(1,32);
[temp1 temp2] = max([sum(Data_CFI.*CFI_1) sum(Data_CFI.*CFI_2) sum(Data_CFI.*CFI_3) sum(Data_CFI.*CFI_4)]);
info_PCFICH_rx = temp2;