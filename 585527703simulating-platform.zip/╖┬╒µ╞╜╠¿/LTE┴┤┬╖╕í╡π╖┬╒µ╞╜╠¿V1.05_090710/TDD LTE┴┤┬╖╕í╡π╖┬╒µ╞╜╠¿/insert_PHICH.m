function [insertdata control_idxSC Len] = insert_PHICH(insertdata,tti,control_idxSC,Len,iteration)
% ����������  ����HI��Ϣ�������ظ����룬���ƣ���Ƶ����ӳ�䣬Ԥ���룬���߶˿ںϲ���������Դӳ�����  zt 080604
global PublicPara
global DownlinkPara

Num_PHICH_OFDM = DownlinkPara.LengthPHICH;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_RB = PublicPara.MaxRB;              % zt 080722
Cell_ID = PublicPara.NcellID;
linkmode = DownlinkPara.Linkmode;
CP_Types = PublicPara.CPtype;
config_U_D_index = PublicPara.ConfigFrame;  %  zt 080715
special_tti = find(config_U_D_index== 'S');  %  zt  080610
seed = PublicPara.Seed;

Ng = 1/6;  % �ɸ߲����ã�����830����PHICH����  zt 080715
if CP_Types == 0   % normal CP
    HI_group_basic = ceil(Ng*(Num_RB/8));
else % extended CP
    HI_group_basic = 2*ceil(Ng*(Num_RB/8));
end

%%����ʱ϶����ȷ��PHICH�����Ĳ���%%%%%%%%%%%%%%%%
switch config_U_D_index  %  ����830����  zt080715
    case 'DSUUUDSUUU'
        switch tti-1
            case {0,5}
                mi = 2;
            case {1,6}
                mi = 1;
        end
    case 'DSUUDDSUUD'
        switch tti-1
            case {0,5}
                mi = 0;
            case {1,4,6,9}
                mi = 1;
        end
    case 'DSUDDDSUDD'
        switch tti-1
            case {0,1,4,5,6,9}
                mi = 0;
            case {3,8}
                mi = 1;
        end
    case 'DSUUUDDDDD'
        switch tti-1
            case {0,8,9}
                mi = 1;
            case {1,5,6,7}
                mi = 0;
        end
    case 'DSUUDDDDDD'
        switch tti-1
            case {0,1,4,5,6,7}
                mi = 0;
            case {8,9}
                mi = 1;
        end
    case 'DSUDDDDDDD'
        switch tti-1
            case {0,1,3,4,5,6,7,9}
                mi = 0;
            case 8
                mi = 1;
        end
    case 'DSUUUDSUUD'
        mi = 1;
end
if mi == 0
    HI_group =0;
    DownlinkPara.HIgroup = HI_group;
    DownlinkPara.control_idxSC_PHICH = control_idxSC;
    DownlinkPara.control_idxSC_PHICH_Len = Len;
    return;
else
    HI_group = mi*HI_group_basic;
    DownlinkPara.HIgroup = HI_group;
end

if find(tti == special_tti)~=0    %  zt  080610
    if Num_PHICH_OFDM ~= 1
        Num_PHICH_OFDM = 2;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  ������Դӳ��
n(1) = Len(1)/4;
n(3) = 3*Num_RB;
if Num_Ant_Tx == 4
    n(2) = 2*Num_RB;
else
    n(2) = n(3);
end
if Num_PHICH_OFDM == 1
    control_idxSC_1 = control_idxSC(1:Len(1));
    control_idxSC_other = control_idxSC(Len(1)+1:end);
    for i = 1:HI_group
        temp0 = mod(floor(Cell_ID*n(1)/n(1))+i-1,n(1));
        temp1 = mod(floor(Cell_ID*n(1)/n(1))+i-1+floor(n(1)/3),n(1));
        temp2 = mod(floor(Cell_ID*n(1)/n(1))+i-1+floor(2*n(1)/3),n(1));
        k0(i,:) = control_idxSC_1(temp0*4+1:(temp0+1)*4);
        k1(i,:) = control_idxSC_1(temp1*4+1:(temp1+1)*4);
        k2(i,:) = control_idxSC_1(temp2*4+1:(temp2+1)*4);        
    end    
elseif Num_PHICH_OFDM == 3
    control_idxSC_1 = control_idxSC(1:Len(1));
    control_idxSC_2 = control_idxSC(Len(1)+1:sum(Len(1:2)));
    control_idxSC_3 = control_idxSC(sum(Len(1:2))+1:sum(Len(1:3)));
    control_idxSC_other = control_idxSC(sum(Len(1:3))+1:end);
    for i = 1:HI_group
        temp0 = mod(floor(Cell_ID*n(1)/n(1))+i-1,n(1));
        temp1 = mod(floor(Cell_ID*n(2)/n(1))+i-1+floor(n(2)/3),n(2));
        temp2 = mod(floor(Cell_ID*n(3)/n(1))+i-1+floor(2*n(3)/3),n(3));
        k0(i,:) = control_idxSC_1(temp0*4+1:(temp0+1)*4);
        k1(i,:) = control_idxSC_2(temp1*4+1:(temp1+1)*4);
        k2(i,:) = control_idxSC_3(temp2*4+1:(temp2+1)*4);       
    end    
else
    control_idxSC_1 = control_idxSC(1:Len(1));
    control_idxSC_2 = control_idxSC(Len(1)+1:sum(Len(1:2)));
    control_idxSC_other = control_idxSC(sum(Len(1:2))+1:end);
    for i = 1:HI_group
        k = 0:2;
        ll = mod(floor((i-1)/2)+k+1,2);
        L(i,k+1) = ll;
        temp0 = mod(floor(Cell_ID*n(ll(1)+1)/n(2))+i-1,n(ll(1)+1));
        if ll(1) == 0
            control_idxSC_temp = control_idxSC_1;
        else
            control_idxSC_temp = control_idxSC_2;
        end
        k0(i,:) = control_idxSC_temp(temp0*4+1:(temp0+1)*4);
        temp1 = mod(floor(Cell_ID*n(ll(2)+1)/n(2))+i-1+floor(n(ll(2)+1)/3),n(ll(2)+1));
        if ll(2) == 0
            control_idxSC_temp = control_idxSC_1;
        else
            control_idxSC_temp = control_idxSC_2;
        end
        k1(i,:) = control_idxSC_temp(temp1*4+1:(temp1+1)*4);
        temp2 = mod(floor(Cell_ID*n(ll(3)+1)/n(2))+i-1+floor(2*n(ll(3)+1)/3),n(ll(3)+1));
        if ll(3) == 0
            control_idxSC_temp = control_idxSC_1;
        else
            control_idxSC_temp = control_idxSC_2;
        end
        k2(i,:) = control_idxSC_temp(temp2*4+1:(temp2+1)*4);        
    end 
end

if strcmp(linkmode,'PDCCH') || strcmp(linkmode,'PBCH')    %% ��ҵ���PBCH���ܷ��棬PBCH����λ�ò���0����
    if Num_PHICH_OFDM == 1
        for i = 1:HI_group
            insertdata(1:Num_Ant_Tx,k0(i,:)) = zeros(Num_Ant_Tx,4);
            insertdata(1:Num_Ant_Tx,k1(i,:)) = zeros(Num_Ant_Tx,4);
            insertdata(1:Num_Ant_Tx,k2(i,:)) = zeros(Num_Ant_Tx,4);
        end
    elseif Num_PHICH_OFDM == 3
        for i = 1:HI_group
            insertdata(1:Num_Ant_Tx,k0(i,:)) = zeros(Num_Ant_Tx,4);
            insertdata(Num_Ant_Tx+1:2*Num_Ant_Tx,k1(i,:)) = zeros(Num_Ant_Tx,4);
            insertdata(2*Num_Ant_Tx+1:3*Num_Ant_Tx,k2(i,:)) = zeros(Num_Ant_Tx,4);
        end       
    else
        for i = 1:HI_group
            k = 0:2;
            ll = mod(floor((i-1)/2)+k+1,2);
            insertdata(ll(1)*Num_Ant_Tx+1:(ll(1)+1)*Num_Ant_Tx,k0(i,:)) = zeros(Num_Ant_Tx,4);  
            insertdata(ll(2)*Num_Ant_Tx+1:(ll(2)+1)*Num_Ant_Tx,k1(i,:)) = zeros(Num_Ant_Tx,4);
            insertdata(ll(3)*Num_Ant_Tx+1:(ll(3)+1)*Num_Ant_Tx,k2(i,:)) = zeros(Num_Ant_Tx,4);
        end       
    end
    
else
    
    %  ����HI��Ϣ����
    UE_option = [5 2 1];  % the first one is the object UE
    HI_num_group = length(UE_option);
    if seed == 1%����HI��Ϣ
        rand('state',100 * iteration + tti + seed);
        Data_HI = randint(HI_group,HI_num_group);
    else
        Data_HI = randint(HI_group,HI_num_group);
    end
    
    DownlinkPara.info_PHICH = Data_HI;

    %  �ظ�����
    Data_HI_coded = kron(Data_HI,ones(1,3));

    %  ����
    Data_HI_modulated = [];
    for i = 1:HI_group
        Data_HI_modulated(i,:) = Modulator(Data_HI_coded(i,:),0);
    end

    %  ��Ƶ
    SF = [1 1 1 1;1 -1 1 -1;1 1 -1 -1;1 -1 -1 1;j j j j;j -j j -j;j j -j -j;j -j -j j];
    for i = 1:HI_num_group
        Data_HI_spreaded(:,(i-1)*12+1:i*12) = kron(Data_HI_modulated(:,(i-1)*3+1:i*3),SF(UE_option(i),:));
    end

    %  ����
    Cint = tti * (2*Cell_ID+1) * 2^9 + Cell_ID;  % ����830����  zt080715
    c = Scrambling_gen(31,Cint);
    c_PHICH = c(1:12);
    Data_HI_scrambled = [];
    for i = 1:HI_group
        Data_HI_scrambled(i,:) = Data_HI_spreaded(i,:).*(1 - 2*repmat(c_PHICH,1,HI_num_group));
    end

    %  ��ӳ��
    for i = 1:HI_group
        for k = 1:HI_num_group
            temp = Data_HI_scrambled(i,(k-1)*12+1:k*12);
            if Num_Ant_Tx == 1
                Data_layermapped(i,k,1,:) = temp;
            else
                switch Num_Ant_Tx
                    case 2 % 1:2 ӳ��ģʽ
                        Data_layermapped(i,k,1,:) = temp(1:2:end);
                        Data_layermapped(i,k,2,:) = temp(2:2:end);
                    case 4 % 1:4 ӳ��ģʽ
                        Data_layermapped(i,k,1,:) = temp(1:4:end);
                        Data_layermapped(i,k,2,:) = temp(2:4:end);
                        Data_layermapped(i,k,3,:) = temp(3:4:end);
                        Data_layermapped(i,k,4,:) = temp(4:4:end);
                end
            end
        end
    end

    %  Ԥ����
    for i = 1:HI_group
        for k = 1:HI_num_group
            if Num_Ant_Tx == 1
                Data_precoded(i,k,1,:) = Data_layermapped(i,k,:,:);
            elseif Num_Ant_Tx == 2
                temp = squeeze(Data_layermapped(i,k,:,:));
                Data_precoded(i,k,:,:) = sfbc_encode(temp);
            else
                sfbcencode = [];
                for iSymb = 1: 3
                    temp = squeeze(Data_layermapped(i,k,:,iSymb));
                    if mod((HI_group+iSymb-1),2) == 0
                        sfbc_temp(1, :) = temp.';
                        sfbc_temp(2, :) = zeros(1,4);
                        tmp1 = complex( -real(temp(2)), imag(temp(2)) );
                        tmp2 = complex( real(temp(1)), -imag(temp(1)) );
                        tmp3 = complex( -real(temp(4)), imag(temp(4)) );
                        tmp4 = complex( real(temp(3)), -imag(temp(3)) );
                        sfbc_temp(3, :) = [tmp1, tmp2, tmp3, tmp4];
                        sfbc_temp(4, :) = zeros(1,4);
                        sfbcencode = [sfbcencode, sqrt(1/2)*sfbc_temp];
                    else
                        sfbc_temp(1, :) = zeros(1,4);
                        sfbc_temp(2, :) = temp.';
                        tmp1 = complex( -real(temp(2)), imag(temp(2)) );
                        tmp2 = complex( real(temp(1)), -imag(temp(1)) );
                        tmp3 = complex( -real(temp(4)), imag(temp(4)) );
                        tmp4 = complex( real(temp(3)), -imag(temp(3)) );
                        sfbc_temp(3, :) = zeros(1,4);
                        sfbc_temp(4, :) = [tmp1, tmp2, tmp3, tmp4];
                        sfbcencode = [sfbcencode, sqrt(1/2)*sfbc_temp];
                    end
                end
                Data_precoded(i,k,:,:) = sfbcencode;
            end
        end
    end

    %  ���ڸ����߶˿��Ϸ��źϲ�
    Data_combined = [];
    for i = 1:HI_group
        for l = 1:12
            for k = 1:Num_Ant_Tx
                sum_temp = 0;
                for m = 1:HI_num_group
                    sum_temp = sum_temp + Data_precoded(i,m,k,l);
                end
                Data_combined(i,1,k,l) = sum_temp;
            end
        end
    end

    %  ������Դӳ��
    if Num_PHICH_OFDM == 1
        for i = 1:HI_group
            insertdata(1:Num_Ant_Tx,k0(i,:)) = Data_combined(i,1,:,1:4);
            insertdata(1:Num_Ant_Tx,k1(i,:)) = Data_combined(i,1,:,5:8);
            insertdata(1:Num_Ant_Tx,k2(i,:)) = Data_combined(i,1,:,9:12);
        end       
    elseif Num_PHICH_OFDM == 3
        for i = 1:HI_group
            insertdata(1:Num_Ant_Tx,k0(i,:)) = Data_combined(i,1,:,1:4);
            insertdata(Num_Ant_Tx+1:2*Num_Ant_Tx,k1(i,:)) = Data_combined(i,1,:,5:8);
            insertdata(2*Num_Ant_Tx+1:3*Num_Ant_Tx,k2(i,:)) = Data_combined(i,1,:,9:12);
        end
    else
        for i = 1:HI_group
            k = 0:2;
            ll = mod(floor((i-1)/2)+k+1,2);
            insertdata(ll(1)*Num_Ant_Tx+1:(ll(1)+1)*Num_Ant_Tx,k0(i,:)) = Data_combined(i,1,:,1:4);  
            insertdata(ll(2)*Num_Ant_Tx+1:(ll(2)+1)*Num_Ant_Tx,k1(i,:)) = Data_combined(i,1,:,5:8);
            insertdata(ll(3)*Num_Ant_Tx+1:(ll(3)+1)*Num_Ant_Tx,k2(i,:)) = Data_combined(i,1,:,9:12);
        end        
    end
end

%  ���Ʒ���ӳ�����ز���Ÿ���
if Num_PHICH_OFDM == 1  
    for i = 1:HI_group
        for m = 1:4
            control_idxSC_1((control_idxSC_1 == k0(i,m))) = [];
            control_idxSC_1((control_idxSC_1 == k1(i,m))) = [];
            control_idxSC_1((control_idxSC_1 == k2(i,m))) = [];
        end
    end
    control_idxSC = [control_idxSC_1 control_idxSC_other];
    Len(1) = length(control_idxSC_1);
elseif Num_PHICH_OFDM == 3   
    for i = 1:HI_group
        for m = 1:4
            control_idxSC_1((control_idxSC_1 == k0(i,m))) = [];
            control_idxSC_2((control_idxSC_2 == k1(i,m))) = [];
            control_idxSC_3((control_idxSC_3 == k2(i,m))) = [];
        end
    end
    control_idxSC = [control_idxSC_1 control_idxSC_2 control_idxSC_3 control_idxSC_other];
    Len(1:3) = [length(control_idxSC_1) length(control_idxSC_2) length(control_idxSC_3)];
else   
    for i = 1:HI_group
        for p = 1:3
            if p == 1
                k = k0;
            elseif p ==2
                k = k1;
            else
                k = k2;
            end
            if(L(i,p) == 0)
                for m = 1:4
                    control_idxSC_1((control_idxSC_1 == k(i,m))) = [];
                end
            else
                for m = 1:4
                    control_idxSC_2((control_idxSC_2 == k(i,m))) = [];
                end
            end
        end
    end
    control_idxSC =  [control_idxSC_1 control_idxSC_2 control_idxSC_other];
    Len(1:2) = [length(control_idxSC_1) length(control_idxSC_2)];
end

DownlinkPara.control_idxSC_PHICH = control_idxSC;
DownlinkPara.control_idxSC_PHICH_Len = Len;
