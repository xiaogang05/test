function [output_bits] = DeModulator(input_complex)
% ������ʵ�� LTE �涨�ĵ��Ʒ�ʽ���������
%
% ���ø�ʽ��[output_bits] = DeModulatorLTE(input_complex,magnitudes)                                                )
% �������˵����
%     magnitudes�����������ŵ����棬û���ŵ�����ʱȡ1���������Ϊ����
%     input_complex�������������븴�����󣬰��н��н����
%..........................................................................
% �������˵����
%     output_bits��������������������������Ϣ����������input_complex������.
%..........................................................................
global SimLinkPara;
global PublicPara;
global PUCCHPara
global DownlinkPara;


output_bits=[];

if strcmp(SimLinkPara,'UPDataLink')      %%% ����ҵ���ŵ�
    ModulationMode=PublicPara.Mod;
elseif  strcmp(SimLinkPara,'DownDataLink') %'DownLink'
    switch DownlinkPara.Linkmode      %%������·ģʽ
        case 'PDSCH'
            ModulationMode=PublicPara.Mod;
        case 'PHICH'
            ModulationMode=0;
        otherwise
            ModulationMode=1;
    end
elseif strcmp(SimLinkPara,'UPControlLink')
    switch PUCCHPara.Config
        case '1'  %1
            input_complex = DeSpread(input_complex); %add by wang hui %PUCCH����
            [row,column]=size(input_complex);
            if column>1
                error('PUCCH�������!');
            end
            output_bits=zeros(row,1);
            [temp1,temp2]=find(input_complex > 0);
            output_bits(temp2,1) =  1;
        case '1a' %1a
            input_complex = DeSpread(input_complex); %add by wang hui %PUCCH����
            %             if input_complex < 0
            %                 output_bits =  0;
            %             else
            %                 output_bits =  1;
            %             end
            [row,column]=size(input_complex);
            if column>1
                error('PUCCH�������!');
            end
            output_bits=ones(row,1);
            [temp1,temp2]=find(input_complex < 0);
            output_bits(temp2,1) =  0;
        case '1b' %1b
            input_complex = DeSpread(input_complex); %add by wang hui %PUCCH����
            [row,column]=size(input_complex);
            if column>1
                error('PUCCH�������!');
            end
            for rp=1:row
                output_bits(rp,1) = (sign(real(input_complex(rp,1))+imag(input_complex(rp,1)))+1)/2;
                output_bits(rp,2) = (sign(real(input_complex(rp,1))-imag(input_complex(rp,1)))+1)/2;
                if mod(sum(output_bits(rp,:)),2)==1
                    output_bits(rp,1) = (sign(real(input_complex(rp,1))-imag(input_complex(rp,1)))+1)/2;
                    output_bits(rp,2) = (sign(imag(input_complex(rp,1))-real(input_complex(rp,1)))+1)/2;
                end
            end
        otherwise  %%% ��ʽ2/2a/2b�Ľ�������Ӻ���
            input_complex = DeSpread(input_complex);   %add by wang hui %PUCCH����
            output_bits=DeModulator_PUCCH(input_complex);
    end
    return;  %%% ֱ�ӷ���
end

switch ModulationMode  %%% ������Ӧ�Ľ������
    case 0 %'BPSK'
        output_bits=DeModulator_BPSK(input_complex);
    case 1 %'QPSK'
        output_bits=DeModulator_QPSK(input_complex);
    case 2 %'16QAM'
        output_bits=DeModulator_16QAM(input_complex,1);
    case 3 %'64QAM'
        output_bits=DeModulator_64QAM(input_complex,1);
end





function [output_bits] = DeModulator_BPSK(input_complex)
[row ,colume]=size(input_complex);
if ((colume==1)&&(row>1))
    error('������������');
end
for rep1=1:row
    y1 = -real(input_complex(rep1,:));
    output_soft_bits = [y1];
    output_bits(rep1,:)=output_soft_bits;
end


function [output_bits] = DeModulator_QPSK(input_complex)
[row ,colume]=size(input_complex);
if ((colume==1)&&(row>1))
    error('������������');
end
for rep1=1:row
    y1 = -real(input_complex(rep1,:));
    y0 = -imag(input_complex(rep1,:));
    output_soft_bits = [y1; y0];
    output_soft_bits = reshape(output_soft_bits,1,2*length(y1));
    output_soft_bits = (quantiz(output_soft_bits,(-1+1/2^7)/sqrt(2):1/2^7/sqrt(2):(1-1/2^7)/sqrt(2),2^8-1:-1:0)'-128)/128;     % sy  090420
    output_bits(rep1,:)=output_soft_bits;
end


function [output_bits] = DeModulator_16QAM(input_complex,magnitudes)
[row ,colume]=size(input_complex);
if ((colume==1)&&(row>1))
    error('������������');
end
for rep1=1:row
    c = 1/sqrt(10);
    threshold2 = magnitudes * 2 * c;  %%%% ��������
    y3 = -real(input_complex(rep1,:));
    y1 = -(threshold2 - abs(y3));
    y2 = -(imag(input_complex(rep1,:)));
    y0 = -(threshold2 - abs(y2));
    output_soft_bits = [y3; y2; y1; y0];
    output_soft_bits = reshape(output_soft_bits,1,4*length(y1));
    output_soft_bits(1:4:end)=(quantiz(output_soft_bits(1:4:end),(-3+3/2^7)/sqrt(10):3/2^7/sqrt(10):(3-3/2^7)/sqrt(10),2^8-1:-1:0)'-128)/128;      % sy  090420
    output_soft_bits(2:4:end)=(quantiz(output_soft_bits(2:4:end),(-3+3/2^7)/sqrt(10):3/2^7/sqrt(10):(3-3/2^7)/sqrt(10),2^8-1:-1:0)'-128)/128;
    output_soft_bits(3:4:end)=(quantiz(output_soft_bits(3:4:end),(-1+3/2^7)/sqrt(10):3/2^7/sqrt(10):(1-3/2^7)/sqrt(10),84-1:-1:0)'-42)/128;
    output_soft_bits(4:4:end)=(quantiz(output_soft_bits(4:4:end),(-1+3/2^7)/sqrt(10):3/2^7/sqrt(10):(1-3/2^7)/sqrt(10),84-1:-1:0)'-42)/128;
    output_bits(rep1,:)=output_soft_bits;
end


function [output_bits] = DeModulator_64QAM(input_complex,magnitudes)
[row ,colume]=size(input_complex);
if ((colume==1)&&(row>1))
    error('������������');
end


for rep1=1:row
    c = 1/sqrt(42);
    threshold2 = magnitudes * 2 * c; %%%% ��������
    threshold4 = magnitudes * 4 * c; %%%% ��������
    y5 = -real(input_complex(rep1,:));
    y3 = -(threshold4 - abs(y5));
    y1 = -(threshold2 - abs(y3));
    y4 = -(imag(input_complex(rep1,:)));
    y2 = -(threshold4 - abs(y4));
    y0 = -(threshold2 - abs(y2));
    output_soft_bits = [y5; y4; y3; y2; y1; y0];
    output_soft_bits = reshape(output_soft_bits,1,6*length(y1));
    output_soft_bits(1:6:end)=(quantiz(output_soft_bits(1:6:end),(-7+7/2^7)/sqrt(42):7/2^7/sqrt(42):(7-7/2^7)/sqrt(42),2^8-1:-1:0)'-128)/128;      % sy 090420
    output_soft_bits(2:6:end)=(quantiz(output_soft_bits(2:6:end),(-7+7/2^7)/sqrt(42):7/2^7/sqrt(42):(7-7/2^7)/sqrt(42),2^8-1:-1:0)'-128)/128;
    output_soft_bits(3:6:end)=(quantiz(output_soft_bits(3:6:end),(-3+7/2^7)/sqrt(42):7/2^7/sqrt(42):(3-7/2^7)/sqrt(42),108-1:-1:0)'-54)/128;
    output_soft_bits(4:6:end)=(quantiz(output_soft_bits(4:6:end),(-3+7/2^7)/sqrt(42):7/2^7/sqrt(42):(3-7/2^7)/sqrt(42),108-1:-1:0)'-54)/128;
    output_soft_bits(5:6:end)=(quantiz(output_soft_bits(5:6:end),(-1+7/2^7)/sqrt(42):7/2^7/sqrt(42):(1-7/2^7)/sqrt(42),34-1:-1:0)'-17)/128;
    output_soft_bits(6:6:end)=(quantiz(output_soft_bits(6:6:end),(-1+7/2^7)/sqrt(42):7/2^7/sqrt(42):(1-7/2^7)/sqrt(42),34-1:-1:0)'-17)/128;
    output_bits(rep1,:)=output_soft_bits;
end


%***********************************************************************
function  out = DeModulator_PUCCH(input)
%���и�ʽ2 2a 2b ���������о�
%***********************************************************************
% �������ƣ� DeModulation2
% ���������� ���ڸ�ʽ2�������ؽ����о�
% ���������

% �޸�����        �汾��     �޸���	      �޸�����
% 2008.9.4         V0.1     wang hui        ����
% 2008.10.22                Ԭ���           �޸�
%***********************************************************************
%***********************************************************************
[row,column]=size(input);
output = [];
for rp=1:row
    b0 = real(input(rp,:));
    b1 = imag(input(rp,:));
    L0 = column;
    output=[];
    for i = 1 : L0
        if b0(i) > 0 && b1(i) > 0
            b0(i) = 0;b1(i) = 0;
        elseif b0(i) > 0 && b1(i) < 0
            b0(i) = 0;b1(i) = 1;
        elseif b0(i) < 0 && b1(i) > 0
            b0(i) = 1;b1(i) = 0;
        elseif b0(i) < 0 && b1(i) < 0
            b0(i) = 1;b1(i) = 1;
        end
        output = [output b0(i) b1(i)];
    end
    out(rp,:)=output;
end

%***********************************************************************
function Data_temp = DeSpread(input_complex)
%add by wang hui  PUCCH de ���ݽ��� 2008 11 
global PUCCHPara 
global PublicPara

n_pie_ns = PUCCHPara.n_pie_ns; %added by libin 090306
DataSymb = PublicPara.OFDMSymbolNum - PUCCHPara.DRSNum;
Data = reshape(input_complex,12,DataSymb);
if strcmp(PUCCHPara.Config(1),'1') 
    PUCCHDATA_Cazac = PUCCHPara.PUCCHDATA_Cazac;
    WalshDATA = PUCCHPara.WalshDATA;
    for k = 1 : DataSymb
        Data (:,k) = Data (:,k) .* conj(PUCCHDATA_Cazac(:,k));
    end
    if mod(n_pie_ns(1),2) == 0
        Data (:,1:4) = Data (:,1:4).* conj(repmat(WalshDATA(1,:),12,1));
    else
        Data (:,1:4) = exp(-j*pi/2)* (Data (:,1:4).* conj(repmat(WalshDATA(1,:),12,1)));
    end
    if mod(n_pie_ns(2),2) == 0
        Data (:,5:end) = Data (:,5:end).* conj(repmat(WalshDATA(2,:),12,1));
    else
        Data (:,5:end)= exp(-j*pi/2)* (Data (:,5:end).* conj(repmat(WalshDATA(2,:),12,1)));
    end
     Data_temp = sum(sum(Data,1),2);
else
    Data = reshape(input_complex,12,DataSymb);
    PUCCHDATA_Cazac = PUCCHPara.PUCCHDATA_Cazac;
    for k = 1 : DataSymb
        Data (:,k) = Data (:,k) .* conj(PUCCHDATA_Cazac(:,k));
    end
    Data_temp = sum(Data,1);
end
