function  Channel_init
%************************************************************************
%*  Copyright 2008 by LTE TDD.      All rights reserved.
%*  This software is PROPRIETARY and CONFIDENTIAL
%************************************************************************
% ��Ȩ���� (C)2008, ����ͨѶ
%
% �ļ����ƣ�Channel_init
% �ļ���ʶ��
% ����ժҪ���ú���ʵ�ֲ�ͬ�ŵ��ĳ�ʼ��
% ����˵������
% ��ǰ�汾��V0.1
% ��    �ߣ������㷨��LTE��Ŀ��
% ������ڣ�2008/11/24
%
% �޸�����        �汾��     �޸���	      �޸�����
%-------------------------------------------------------------------------
% 2008/11/24 	  V0.1	     ���	          ����
%
%**************************************************************************
global System_clock
global Channel
global PublicPara
global SimLinkPara

N_multi = Channel.PathNum;
Ka = PublicPara.Num_eNBAnt*PublicPara.Num_UEAnt;
TTIIndex = System_clock(2);
FrameIndex = System_clock(1);
%%%%%���������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if PublicPara.Seed == 1
    State_channel = 100 * FrameIndex + TTIIndex;
    rand('state',State_channel) ;
end
%%%%% END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(SimLinkPara(1),'U')    % ��·�������з������У�'U'�������У�'D'��
    Channel.Direction = 'U';
else
    Channel.Direction = 'D';
end

if strcmp(Channel.SCME, 'N')             % ���÷�SCMEģ��
    if (mod(System_clock(1),40)==1)&&(System_clock(2)==1)
        condition_rayleigh = zeros(N_multi,25+24,Ka);				%!!!
        for k=1:Ka
            condition_rayleigh(:,:,k) = 2*pi*rand(N_multi,25+24);		%initial phase (rad) !!!
            if Channel.RandomAngle == 1
                angle(:,k) = randint(N_multi,1,[-60,60]);
            else
                angle(:,k) = [-14.8900   -6.3780   12.4540  -19.1620   -6.1060  -29.9780  -15.8340 -1.69 12.454];
            end
        end
        Channel.condition_rayleigh = condition_rayleigh;
        Channel.angle = angle;  %  ULA
        Channel.path_phase = 2*pi*rand(N_multi,1);          %added by libin 090318
        %     else
        %         u = rand(N_multi,1);
        %         deviation = zeros(N_multi,1);
        %         for i = 1:1:N_multi
        %             if u(i,1) >= 0.5
        %                 fai = (-1) * sqrt(2)*log(2*(1-u(i,1)));
        %             else
        %                 fai = sqrt(2)*log(2*u(i,1));
        %             end
        %             deviation(i,1) = round(sigma*fai);       %laplacian generator added by luozhinian 2005-08-16
        %         end
        %         angle = deviation + Channel.angle;%path direction (deg)
        %         for i=1:N_multi
        %             if (angle(i)>=60) ||  (angle(i)<-60)
        %                 angle(i)=randint(1,1,[-60,60]);
        %             end
        %         end
        %         Channel.angle = angle;

        if PublicPara.AdCellFlag == 1       %added by libin 090318
            for k = 1:PublicPara.AdCellNum
                path_adj_phase(k) = 2*pi*rand(1,1); %path phase shift
                angle_adj(k) = (k-1)*60 + randint(1,1,[0 60]);
            end
            Channel.angle_adj = angle_adj;
            Channel.path_adj_phase = path_adj_phase;
        end
    end
else
    SFstd = Channel.SFstd;                      % ��·���趨��Ӱ˥�䣬·���Ϊ1
    Pathloss = Channel.Pathloss;
    %-------------------�Ӿ��Ƕȣ�AOD��AOA---------------------------------
    MsAzimuth = Channel.MsAzimuth;              % MS ֱ�Ӿ��뷨�߼н� ThetaMs ����Դ��������
    BsAzimuth = Channel.BsAzimuth;              % BS ֱ�Ӿ��뷨�߼н� ThetaBs ����Դ��������
    BsAOD = repmat(Channel.BsAOD.',1,Channel.SubNum) + repmat(Channel.BsSubOffset,Channel.PathNum,1); %   6 * 20 �ľ���
    MsAOA = repmat(Channel.MsAOA.',1,Channel.SubNum)+ repmat(Channel.MsSubOffset,Channel.PathNum,1);  %   6 * 20 �ľ���
    %-------------------------�����о�ʱ��----------------------------------
    Delay=repmat(Channel.PathDelay,length(Channel.MidDelay),1);
    Delay=reshape(Delay,1,length(Channel.MidDelay)*Channel.PathNum);
    Delay=Delay+repmat(Channel.MidDelay,1,Channel.PathNum);
    %-------------------------�����о�����-----------------------------------
    PathPower = Channel.PathPower/sum(Channel.PathPower);     % ���ʹ�һ��
    Power=repmat(PathPower,length(Channel.MidPower),1);
    Power=reshape(Power,1,length(Channel.MidPower)*Channel.PathNum);
    Power=Power.*repmat(Channel.MidPower,1,Channel.PathNum);
    SubPhase = 2*pi*rand(Channel.PathNum,Channel.SubNum);
    MsDot = 360*(rand(1,1)-0.5);                        % MS�ƶ�����theta_v
    %===========================�Ƕ���ʱ������=========================================
    BsAOD = prin_value(BsAOD);
    BsAzimuth = prin_value(BsAzimuth);
    MsAOA = prin_value(MsAOA);
    MsAzimuth = prin_value(MsAzimuth);
    %========================����ֱ�Ӿ�����=======================================
    % ������˹����
    if Channel.LOSEnable == 1
        switch Channel.scenario
            case 'urban_macro'
                LOS_prob=(15/30)*(500-MsBsDistance)./500;
                prob=rand(1,1);
                LOS_prob=LOS_prob.*(prob<=LOS_prob);
                K_Ricean=10.^((15.4-5*log10(MsBsDistance))/10);
                K_Ricean=K_Ricean.*(LOS_prob~=0)*Channel.LOSEnable;  % in linear scale
            case 'suburban_macro'
                LOS_prob=(40/50) * (5000-MsBsDistance)./5000;
                prob=rand(1,1);
                LOS_prob=LOS_prob.*(prob<=LOS_prob);
                K_Ricean=10.^((15.4-5*log10(MsBsDistance))/10);
                K_Ricean=K_Ricean.*(LOS_prob~=0)*Channel.LOSEnable;  % in linear scale
            case 'urban_micro'
                LOS_prob=max([0; (300-MsBsDistance)./300]);
                prob=rand(1,1);
                LOS_prob=LOS_prob.*(prob<=LOS_prob);
                K_Ricean=10.^((13-0.03*MsBsDistance)/10); % [1, Sec. 5.5.3]
                K_Ricean=K_Ricean.*(LOS_prob~=0)*Channel.LOSEnable;  % in linear scale
        end %end of switch

        %----------------���Ƕȣ���λ��6*20��Ϊ6*21�ľ��󣬵�1��ΪLOS����-----------
        BsAOD=[repmat(BsAzimuth,Channel.PathNum,1),BsAOD];
        MsAOA=[repmat(MsAzimuth,Channel.PathNum,1),MsAOA];
        SubPhase =[repmat(rand*2*pi-pi,Channel.PathNum,1),SubPhase*pi/180];     % �Ӿ���λ

    else
        K_Ricean = 0;
    end

    %=============================�����ж�=====================================
    if Channel.Pol ~= 'N'
        xpd=0;    % ���㼫������
        SubPhase = zeros(Channel.PathNum,Channel.SubNum);  %�Ӿ���λ 6*20
    end

    Channel.InitPara_SCME = struct( 'Delay',Delay,...
        'Power',Power,...
        'BsAOD',BsAOD,...
        'MsAOA',MsAOA,...
        'SubPhase',SubPhase,...
        'K_Ricean',K_Ricean,...       % in linear scale
        'Pathloss',Pathloss,...       % in linear scale
        'SFstd',SFstd,...
        'MsDot',MsDot,...
        'BsAzimuth',BsAzimuth,...
        'MsAzimuth',MsAzimuth);
end
%===========================�Ƕ���������====================================
function y=prin_value(x)
y=mod(x,360);
y=y-360*floor(y/180);
