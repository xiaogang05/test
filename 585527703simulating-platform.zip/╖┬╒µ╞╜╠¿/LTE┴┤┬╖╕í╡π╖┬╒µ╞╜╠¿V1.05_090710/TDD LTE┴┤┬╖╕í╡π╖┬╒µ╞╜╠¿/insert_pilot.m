function insert_pilot(Pilot_Sequence,Pilot_Sequence_AdCell)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �������ƣ�isert_pilot
% (c)2007,����ͨѶ�ɷ����޹�˾. All Rights Reserved
% ��������: �� ��(ID: 142372)
%==============================================================================
% ����˵��:   ��Ƶ��RE��ӳ�䡣
%         
% �������: 
% CP_Types         �� CP���͡�% CP_Types = 0 ��ʾNormal CP
%                                        = 1 ��ʾExtended CP
% BW               �� ϵͳ������
% Num_Ant_Tx       �� ������������
% 
% �������:   
% Resource_Grid      �� ӳ�����
%        
% ���ú�����insert_pilot_normal.m�� 
%==============================================================================
% �汾��ʷ: 
% 2007.12.31          ���Ҵ���
% 2008.11.26          modified by libin
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara           % ����������ʼ��  modified by libin 080418
global DownlinkPara

Num_Ant_Tx = PublicPara.Num_eNBAnt;    % modified by libin 080418
CP_Types = PublicPara.CPtype;        % modified by libin 080418
OFDMSymbolNum = PublicPara.OFDMSymbolNum;
Numb_SubCarrier = PublicPara.Num_Occupied_sc - 1;
NcellID = PublicPara.NcellID;

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090312
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    AdCellID = PublicPara.AdCellID;
end

Resource_Grid = zeros(Num_Ant_Tx*OFDMSymbolNum,Numb_SubCarrier);
if AdCellFlag == 1               %added by libin 090312
    Resource_Grid_AdCell = [];
    for k = 1: AdCellNum
        Resource_Grid_AdCell{k} = zeros(Num_Ant_Tx*OFDMSymbolNum,Numb_SubCarrier);
    end
else
    Resource_Grid_AdCell = [];
end

switch CP_Types
    case 0
        if Num_Ant_Tx == 1
            insertpilot_1 = insert_pilot_normal(Pilot_Sequence(1,:),1,NcellID);
            insertpilot_5 = insert_pilot_normal(Pilot_Sequence(2,:),5,NcellID);
            insertpilot_8 = insert_pilot_normal(Pilot_Sequence(3,:),8,NcellID);
            insertpilot_12 = insert_pilot_normal(Pilot_Sequence(4,:),12,NcellID);
            Resource_Grid(1,1:length(insertpilot_1)) = insertpilot_1;    %  zt  090427
            Resource_Grid(5,1:length(insertpilot_5)) = insertpilot_5;
            Resource_Grid(8,1:length(insertpilot_8)) = insertpilot_8;
            Resource_Grid(12,1:length(insertpilot_12)) = insertpilot_12;
            if AdCellFlag == 1               %added by libin 090312
                for k = 1: AdCellNum
                    insertpilot_1 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(1,:),1,AdCellID(k));
                    insertpilot_5 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(2,:),5,AdCellID(k));
                    insertpilot_8 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(3,:),8,AdCellID(k));
                    insertpilot_12 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(4,:),12,AdCellID(k));
                    Resource_Grid_AdCell{k}(1,1:length(insertpilot_1)) = insertpilot_1;    %  zt  090427
                    Resource_Grid_AdCell{k}(5,1:length(insertpilot_5)) = insertpilot_5;
                    Resource_Grid_AdCell{k}(8,1:length(insertpilot_8)) = insertpilot_8;
                    Resource_Grid_AdCell{k}(12,1:length(insertpilot_12)) = insertpilot_12;
                end
            end
        elseif Num_Ant_Tx == 2
            insertpilot_1 = insert_pilot_normal(Pilot_Sequence(1,:),1,NcellID);
            insertpilot_5 = insert_pilot_normal(Pilot_Sequence(2,:),5,NcellID);
            insertpilot_8 = insert_pilot_normal(Pilot_Sequence(3,:),8,NcellID);
            insertpilot_12 = insert_pilot_normal(Pilot_Sequence(4,:),12,NcellID);
            Resource_Grid([1 2 9 10 15 16 23 24],1:length(insertpilot_1)) = [insertpilot_1;insertpilot_5;insertpilot_8;insertpilot_12];
            if AdCellFlag == 1               %added by libin 090312
                for k = 1: AdCellNum
                    insertpilot_1 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(1,:),1,AdCellID(k));
                    insertpilot_5 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(2,:),5,AdCellID(k));
                    insertpilot_8 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(3,:),8,AdCellID(k));
                    insertpilot_12 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(4,:),12,AdCellID(k));
                    Resource_Grid_AdCell{k}([1 2 9 10 15 16 23 24],1:length(insertpilot_1)) = [insertpilot_1;insertpilot_5;insertpilot_8;insertpilot_12];
                end
            end
        else   %         elseif Num_Ant_Tx == 4
            insertpilot_1 = insert_pilot_normal(Pilot_Sequence(1,:),1,NcellID);
            insertpilot_2 = insert_pilot_normal(Pilot_Sequence(2,:),2,NcellID);
            insertpilot_5 = insert_pilot_normal(Pilot_Sequence(3,:),5,NcellID);
            insertpilot_8 = insert_pilot_normal(Pilot_Sequence(4,:),8,NcellID);
            insertpilot_9 = insert_pilot_normal(Pilot_Sequence(5,:),9,NcellID);
            insertpilot_12 = insert_pilot_normal(Pilot_Sequence(6,:),12,NcellID);
            if Num_Ant_Tx == 4
                Resource_Grid([1:8 17:20 29:36 45:48],1:length(insertpilot_1)) = [insertpilot_1;insertpilot_2;insertpilot_5;insertpilot_8;insertpilot_9;insertpilot_12];
                if AdCellFlag == 1               %added by libin 090312
                    for k = 1: AdCellNum
                        insertpilot_1 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(1,:),1,AdCellID(k));
                        insertpilot_2 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(2,:),2,AdCellID(k));
                        insertpilot_5 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(3,:),5,AdCellID(k));
                        insertpilot_8 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(4,:),8,AdCellID(k));
                        insertpilot_9 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(5,:),9,AdCellID(k));
                        insertpilot_12 = insert_pilot_normal(Pilot_Sequence_AdCell{k}(6,:),12,AdCellID(k));
                        Resource_Grid_AdCell{k}([1:8 17:20 29:36 45:48],1:length(insertpilot_1)) = [insertpilot_1;insertpilot_2;insertpilot_5;insertpilot_8;insertpilot_9;insertpilot_12];
                    end
                end
            elseif Num_Ant_Tx == 8
                Grid_temp = [insertpilot_1;insertpilot_2;insertpilot_5;insertpilot_8;insertpilot_9;insertpilot_12];    %  zt  090427
                Resource_Grid([1:4 9:12 33:36 57:60 65:68 89:92],1:length(insertpilot_1)) = Grid_temp;
                Grid_temp(Grid_temp~=0) = 100;
                Resource_Grid([5:8 13:16 37:40 61:64 69:72 93:96],1:length(insertpilot_1)) = Grid_temp;
            end
        end
        
    case 1

end

DownlinkPara.Resource_Grid = Resource_Grid;
DownlinkPara.Resource_Grid_AdCell = Resource_Grid_AdCell;


%==============================================================================
function insertpilot = insert_pilot_normal(pilotsymbol,symbol,NcellID)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����˵��:   ��Ƶ��RE��ӳ�䡣
% Ŀǰ�汾: 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PublicPara           % ����������ʼ��  modified by libin 080418

vshift = mod(NcellID,6);   
Num_Ant_Tx = PublicPara.Num_eNBAnt;    % modified by libin 080418
MaxRB = PublicPara.MaxRB;
Numb_SubCarrier = PublicPara.Num_Occupied_sc - 1;

pilot_loc = (1:2*MaxRB) + 110 - MaxRB;
basic_loc = 1:6:Numb_SubCarrier;          %  zt 080718
if Num_Ant_Tx == 1
    switch symbol
        case {1,8}
            insertpilot(1,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
        case {5,12}
            insertpilot(1,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
    end
elseif Num_Ant_Tx == 2
    switch symbol
        case {1,8}            
            insertpilot(1,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(2,mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot(1,mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot(2,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
        case {5,12}
            insertpilot(1,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(2,mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot(1,mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot(2,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
    end
else   %         elseif Num_Ant_Tx == 4
    switch symbol
        case {1,8}
            insertpilot(1,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(2:4,mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot([1 3 4],mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot(2,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
        case 2
            insertpilot([1 2 4],mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot(3,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(1:3,mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot(4,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
        case {5,12}
            insertpilot(1,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(2:4,mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot([1 3 4],mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot(2,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
        case 9
            insertpilot([1 2 4],mod(3 + vshift,6) + basic_loc) = 100;
            insertpilot(3,mod(3 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
            insertpilot(1:3,mod(0 + vshift,6) + basic_loc) = 100;
            insertpilot(4,mod(0 + vshift,6) + basic_loc) = pilotsymbol(pilot_loc);
    end
end