function [insertdata insertdata_AdCell] = insert_ss(insertdata,insertdata_AdCell,tti)
%  ��������ͬ���źŵ�������Դӳ�����  zt 080604
%  modified by libin 081126
global PublicPara

Num_Ant_Tx = PublicPara.Num_eNBAnt;
N_Subcarrier_PerRB = PublicPara.NumSubCarrierPRB;
Num_RB = PublicPara.MaxRB;              % zt 080722
ss_loc = (Num_RB * N_Subcarrier_PerRB)/2 + (-30:31);

% if strcmp(SimLinkPara,'DownSyncLink')    
Cell_ID = PublicPara.NcellID;                    %  zt  080528  С��ID  0-503
Group_ID = floor(Cell_ID/3);                       %  zt  080528  С��ID��  0-167
Sector_ID = Cell_ID - 3*Group_ID;                  %  zt  080528  ����ID  0-2
[pss sss_first sss_second] = gen_ss(Group_ID,Sector_ID);   %  zt 080528

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090317
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    AdCellID = PublicPara.AdCellID;
end

if tti == 2||tti == 7
    insertdata(2*Num_Ant_Tx+1:3*Num_Ant_Tx,ss_loc) = repmat(pss,Num_Ant_Tx,1);
elseif tti == 1
    insertdata(13*Num_Ant_Tx+1:14*Num_Ant_Tx,ss_loc) = repmat(sss_first,Num_Ant_Tx,1);
elseif tti == 6
    insertdata(13*Num_Ant_Tx+1:14*Num_Ant_Tx,ss_loc) = repmat(sss_second,Num_Ant_Tx,1);
end

if AdCellFlag == 1      %added by libin 090317
    for k = 1: AdCellNum
        Group_ID = floor(AdCellID(k)/3);                       %  zt  080528  С��ID��  0-167
        Sector_ID = AdCellID(k) - 3*Group_ID;                  %  zt  080528  ����ID  0-2
        [pss_AdCell sss_first_AdCell sss_second_AdCell] = gen_ss(Group_ID,Sector_ID);   %  zt 080528
        
        if tti == 2||tti == 7
            insertdata_AdCell{k}(2*Num_Ant_Tx+1:3*Num_Ant_Tx,ss_loc) = repmat(pss_AdCell,Num_Ant_Tx,1);
        elseif tti == 1
            insertdata_AdCell{k}(13*Num_Ant_Tx+1:14*Num_Ant_Tx,ss_loc) = repmat(sss_first_AdCell,Num_Ant_Tx,1);
        elseif tti == 6
            insertdata_AdCell{k}(13*Num_Ant_Tx+1:14*Num_Ant_Tx,ss_loc) = repmat(sss_second_AdCell,Num_Ant_Tx,1);
        end
    end
else
    insertdata_AdCell =[];
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [pss sss_first sss_second] = gen_ss(Group_Id,Sector_ID)
%  ����˵������������ͬ���ź�
% ��ͬ��
switch Sector_ID
    case 0
        u = 25;
    case 1
        u = 29;
    case 2
        u = 34;
end
pss = [];
for n = 1:63
    pss(n) = exp((-j) * u * pi * n * (n-1)/63);
end
pss(32) = [];

% ��ͬ��
x = [0 0 0 0 1];
y = [0 0 0 0 1];
w = [0 0 0 0 1];
for i = 1:26
    x(i+5) = mod(x(i+2)+x(i),2);
    y(i+5) = mod(y(i+3)+y(i),2);
    w(i+5) = mod(w(i+4)+w(i+2)+w(i+1)+w(i),2);
end
s = 1 - 2*x;
c = 1 - 2*y;
z = 1 - 2*w;
%%%%%%%%���ϲ���SSS���ɵĻ�������%%%%%%%%%%

%%%��������ID,���c0��c1����
n = 0:30;
c0(n+1) = c(mod(n+Sector_ID,31)+1);
c1(n+1) = c(mod(n+Sector_ID+3,31)+1);

q1 = floor((Group_Id)/30);
q = floor((Group_Id+q1*(q1+1)/2)/30);
m_tmp = Group_Id+q*(q+1)/2;
m0 = mod(m_tmp,31);
m1 = mod(m0+floor(m_tmp/31)+1,31);

%%%%%���s0��s1����
s0(n+1) = s(mod(n+m0,31)+1);
s1(n+1) = s(mod(n+m1,31)+1);

%%%%%%���z0��z1����
z10(n+1) = z(mod(n+mod(m0,8),31)+1);
z11(n+1) = z(mod(n+mod(m1,8),31)+1);
for k=1:31
    %%%%�������յ�SSS����,�ȿ���ΪFDDģʽ
    sss_first(2*k-1) = s0(k) * c0(k);
    sss_first(2*k) = s1(k)*c1(k) * z10(k);
    sss_second(2*k-1) = s1(k) * c0(k);
    sss_second(2*k) = s0(k)*c1(k) * z11(k);
end