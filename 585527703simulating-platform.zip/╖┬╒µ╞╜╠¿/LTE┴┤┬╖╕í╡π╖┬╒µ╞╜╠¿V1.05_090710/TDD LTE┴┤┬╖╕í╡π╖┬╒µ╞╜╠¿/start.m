function varargout = start(varargin)
%START M-file for start.fig
%      START, by itself, creates a new START or raises the existing
%      singleton*.
%
%      H = START returns the handle to a new START or the handle to
%      the existing singleton*.
%
%      START('Property','Value',...) creates a new START using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to start_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      START('CALLBACK') and START('CALLBACK',hObject,...) call the
%      local function named CALLBACK in START.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%************************************************************************
%*  Copyright 2008 by LTE TDD.      All rights reserved.
%*  This software is PROPRIETARY and CONFIDENTIAL
%************************************************************************
% ��Ȩ���� (C)2008, ����ͨѶ
%
% �ļ����ƣ�start
% �ļ���ʶ��
% ����ժҪ�����ļ���LTE������·����ƽ̨��GUI�������ú���
% ����˵������
% ��ǰ�汾��V0.1
% ��    �ߣ������㷨��LTE��Ŀ��
% ������ڣ�2008/11/20
%
% �޸�����        �汾��     �޸���	      �޸�����
%-------------------------------------------------------------------------
% 2008/11/20 	  V0.1	     ���	          ����
%
%*************************************************************************

% Edit the above text to modify the response to help start

% Last Modified by GUIDE v2.5 19-Mar-2009 11:41:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_OpeningFcn, ...
                   'gui_OutputFcn',  @start_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before start is made visible.
function start_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for start
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

set(handles.HARQ_Close, 'Enable','on');
        set(handles.HARQ_Open, 'Enable','on');     
        set(handles.Multi_User_Close, 'Enable','on');
        set(handles.Multi_User_Open, 'Enable','on');
        set(handles.SRS_Close, 'Enable','on');
        set(handles.SRS_Open, 'Enable','on'); 
        set(handles.AdCell_Close, 'Enable','on');
        set(handles.AdCell_Open, 'Enable','on'); 
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off'); 
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.RACH_Config, 'Enable','off');
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','on'); 
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off'); 
        set(handles.Flag_DownChannel, 'Enable','off');
        set(handles.Num_Layer, 'Enable','off');     
        set(handles.PAPR_flag, 'Enable','off');
        set(handles.PAPR_Method, 'Enable','off');  
        set(handles.Num_stream, 'Enable','off');
        set(handles.ControlChannelLength, 'Enable','off');  
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');  
        set(handles.Sample_offset, 'Enable','off');
        set(handles.BF_flag, 'Enable','off'); 
        set(handles.ResultPrint, 'Enable','off'); 
% UIWAIT makes start wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = start_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function Num_Max_Retry_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_Max_Retry (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function HARQ_delay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HARQ_delay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function Inter_UE_Num_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Inter_UE_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function inter_UE_SNR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inter_UE_SNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function RACH_Config_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RACH_Config (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function PUCCHFormat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PUCCHFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function HighSpeedCell_flag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HighSpeedCell_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Ncs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ncs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function HopFlag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HopFlag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ResultPrint.
function ResultPrint_Callback(hObject, eventdata, handles)
% hObject    handle to ResultPrint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%**************************************************************************
%��ͼ�������ʾ �׶� �����Ҫ��ͼ�Ļ�
load ResultRec;
Results_Plot(ResultRec)
%**************************************************************************


% --- Executes on selection change in Sim_link.
function Sim_link_Callback(hObject, eventdata, handles)
% hObject    handle to Sim_link (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Sim_link contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Sim_link
contents = get(handles.Sim_link, 'String');
flag = contents{get(handles.Sim_link, 'Value')};
switch flag
    case '����ҵ���ŵ�������·'
        set(handles.HARQ_Close, 'Enable','on');
        set(handles.HARQ_Close, 'Value',1);
        set(handles.HARQ_Open, 'Enable','on');
        set(handles.HARQ_Open, 'Value',0);
        set(handles.Multi_User_Close, 'Enable','on');
        set(handles.Multi_User_Close, 'Value',1);
        set(handles.Multi_User_Open, 'Enable','on');
        set(handles.Multi_User_Open, 'Value',0);
        set(handles.SRS_Close, 'Enable','on');
        set(handles.SRS_Close, 'Value',1);
        set(handles.SRS_Open, 'Enable','on'); 
        set(handles.SRS_Open, 'Value',0);
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.RACH_Config, 'Enable','off');
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','on'); 
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off'); 
        set(handles.Flag_DownChannel, 'Enable','off');
        set(handles.Num_Layer, 'Enable','off');     
        set(handles.PAPR_flag, 'Enable','off');
        set(handles.PAPR_Method, 'Enable','off');  
        set(handles.Num_stream, 'Enable','off');
        set(handles.ControlChannelLength, 'Enable','off');  
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');  
        set(handles.Sample_offset, 'Enable','off'); 
        set(handles.SRS_Period, 'Enable','off');
        set(handles.BF_flag, 'Enable','off');
        set(handles.AdCell_Close, 'Enable','on');
        set(handles.AdCell_Open, 'Enable','on'); 
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off'); 
    case '���п����ŵ�������·'
        set(handles.RACH_Config, 'Enable','off');
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','off'); 
        set(handles.PUCCHFormat, 'Enable','on');
        set(handles.HighSpeedCell_flag, 'Enable','on'); 
        set(handles.HARQ_Close, 'Enable','off');
        set(handles.HARQ_Open, 'Enable','off');     
        set(handles.Multi_User_Close, 'Enable','on');
        set(handles.Multi_User_Close, 'Value',1);
        set(handles.Multi_User_Open, 'Enable','on');
        set(handles.Multi_User_Open, 'Value',0);
        set(handles.SRS_Close, 'Enable','on');
        set(handles.SRS_Open, 'Enable','on');        
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.Flag_DownChannel, 'Enable','off');
        set(handles.Num_Layer, 'Enable','off');     
        set(handles.PAPR_flag, 'Enable','off');
        set(handles.PAPR_Method, 'Enable','off');  
        set(handles.Num_stream, 'Enable','off');
        set(handles.ControlChannelLength, 'Enable','off');  
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');  
        set(handles.Sample_offset, 'Enable','off');
        set(handles.SRS_Period, 'Enable','off');
        set(handles.BF_flag, 'Enable','off');
        set(handles.AdCell_Close, 'Enable','on');
        set(handles.AdCell_Open, 'Enable','on');
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off');
    case '���н����ŵ�������·'
        set(handles.RACH_Config, 'Enable','on');
        set(handles.Ncs, 'Enable','on');
        set(handles.HopFlag, 'Enable','on'); 
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','on'); 
         set(handles.HARQ_Close, 'Enable','off');
        set(handles.HARQ_Open, 'Enable','off');     
        set(handles.Multi_User_Close, 'Enable','on');
        set(handles.Multi_User_Open, 'Enable','on');
        set(handles.SRS_Close, 'Enable','off');
        set(handles.SRS_Open, 'Enable','off');        
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.Flag_DownChannel, 'Enable','off');
        set(handles.Num_Layer, 'Enable','off');     
        set(handles.PAPR_flag, 'Enable','off');
        set(handles.PAPR_Method, 'Enable','off');  
        set(handles.Num_stream, 'Enable','off');
        set(handles.ControlChannelLength, 'Enable','off');  
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');  
        set(handles.Sample_offset, 'Enable','off'); 
        set(handles.SRS_Period, 'Enable','off'); 
        set(handles.BF_flag, 'Enable','off'); 
        set(handles.AdCell_Close, 'Enable','off');
        set(handles.AdCell_Open, 'Enable','off'); 
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off'); 
    case '����ҵ������ŵ�������·'
        set(handles.Flag_DownChannel, 'Enable','on');
        set(handles.Flag_DownChannel, 'Value',1);
        set(handles.Num_Layer, 'Enable','on');     
%         set(handles.PAPR_flag, 'Enable','on');
%         set(handles.PAPR_Method, 'Enable','on');  
        set(handles.Num_stream, 'Enable','on');
        set(handles.ControlChannelLength, 'Enable','on');  
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');      
        set(handles.HARQ_Close, 'Enable','on');
        set(handles.HARQ_Open, 'Enable','on');     
        set(handles.Multi_User_Close, 'Enable','off');
        set(handles.Multi_User_Open, 'Enable','off');
        set(handles.SRS_Close, 'Enable','off');
        set(handles.SRS_Open, 'Enable','off');        
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.RACH_Config, 'Enable','off');  
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','off'); 
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off'); 
        set(handles.SRS_Period, 'Enable','off'); 
        set(handles.Sample_offset, 'Enable','off'); 
        set(handles.BF_flag, 'Enable','on'); 
        set(handles.AdCell_Close, 'Enable','on');
        set(handles.AdCell_Open, 'Enable','on'); 
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off'); 
    case '����ͬ���ŵ�������·'
        set(handles.Sample_offset, 'Enable','on'); 
        set(handles.HARQ_Close, 'Enable','off');
        set(handles.HARQ_Open, 'Enable','off');     
        set(handles.Multi_User_Close, 'Enable','off');
        set(handles.Multi_User_Open, 'Enable','off');
        set(handles.SRS_Close, 'Enable','off');
        set(handles.SRS_Open, 'Enable','off');        
        set(handles.Num_Max_Retry, 'Enable','off');  
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');  
        set(handles.inter_UE_SNR, 'Enable','off'); 
        set(handles.RACH_Config, 'Enable','off');  
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','off'); 
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off'); 
        set(handles.SRS_Period, 'Enable','off'); 
        set(handles.Flag_DownChannel, 'Enable','off');
        set(handles.PHICHLength, 'Enable','off'); 
        set(handles.PDCCH_Num, 'Enable','off');  
        set(handles.Num_Layer, 'Enable','off');     
        set(handles.Num_stream, 'Enable','off');
        set(handles.ControlChannelLength, 'Enable','off'); 
        set(handles.BF_flag, 'Enable','off'); 
        set(handles.AdCell_Close, 'Enable','on');
        set(handles.AdCell_Open, 'Enable','on'); 
        set(handles.AdCell_Num, 'Enable','off');
        set(handles.AdCell_Power, 'Enable','off'); 
end;

% --- Executes during object creation, after setting all properties.
function Sim_link_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sim_link (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Num_Layer_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_Layer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Num_stream_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_stream (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function PDCCH_Num_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PDCCH_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function PAPR_flag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PAPR_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function ControlChannelLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ControlChannelLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function PAPR_Method_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PAPR_Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function PHICHLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PHICHLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Sample_offset_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sample_offset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Channel_Estimation_Types_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Channel_Estimation_Types (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Receiver_Types_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Receiver_Types (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Interpolation_Method_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Interpolation_Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function BF_flag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BF_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Numframe_Max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Numframe_Max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Num_eNB_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_eNB_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Num_UE_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_UE_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function BW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Channel_Type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Channel_Type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function CP_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CP_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Offset_Fre_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Offset_Fre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function SNR_Max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SNR_Max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function SNR_Min_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SNR_Min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function SNR_Step_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SNR_Step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function UE_speed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to UE_speed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Mod_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mod_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Num_RB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Num_RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Dis_eNB_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dis_eNB_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Dis_UE_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dis_UE_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Polar_eNB_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Polar_eNB_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Ploar_UE_Ant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ploar_UE_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Config_frame_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Config_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Config_DGU_frame_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Config_DGU_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Delta_Subcarrier_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Delta_Subcarrier (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function TB_Size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TB_Size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Offset_Time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Offset_Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Numframe_Min_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Numframe_Min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in StartSim.
function StartSim_Callback(hObject, eventdata, handles)
% hObject    handle to StartSim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc;
clear global;
global SimLinkPara
% ��ȡ������·������Ϣ
contents = get(handles.Sim_link,'String');
channel = contents{get(handles.Sim_link, 'Value')};
switch channel
    case '����ҵ���ŵ�������·'
        SimLinkPara = 'UPDataLink';        
    case '���п����ŵ�������·'
        SimLinkPara = 'UPControlLink';
    case '���н����ŵ�������·'
        SimLinkPara = 'UPRACHLink';
    case '����ҵ������ŵ�������·'
        SimLinkPara = 'DownDataLink';
    case '����ͬ���ŵ�������·'
        SimLinkPara = 'DownSyncLink';        
end

% ��ȡ֡��Ŀ��Ϣ
contents = get(handles.Numframe_Max,'String');
FrameMax = str2double(contents);
contents = get(handles.Numframe_Min,'String');
FrameMin = str2double(contents);
if FrameMax < FrameMin
    msgbox('����ķ���֡������ȷ��');
    error('����ķ���֡������ȷ��');
end
% ��ȡSNR��Ϣ
contents = get(handles.SNR_Max,'String');
SNRMax = str2double(contents);
contents = get(handles.SNR_Min,'String');
SNRMin = str2double(contents);
contents = get(handles.SNR_Step,'String');
SNRStep = str2double(contents);
if SNRMax < SNRMin
    msgbox('�����SNRֵ����ȷ��');
    error('�����SNRֵ����ȷ��');
end
% ��ȡUE�˶��ٶ���Ϣ
contents = get(handles.UE_speed,'String');
UEspeed = str2double(contents);
% ��ȡTBSize��Ϣ
contents = get(handles.TB_Size,'String');
TBSize = str2double(contents);
% ��ȡRB��Ŀ��Ϣ
contents = get(handles.Num_RB,'String');
NumRB = str2double(contents);
% ��ȡʱƵƫ��Ŀ��Ϣ
contents = get(handles.Offset_Time,'String');
OffsetTime = str2double(contents);
contents = get(handles.Offset_Fre,'String');
OffsetFre = str2double(contents);
% ��ȡ��վ������Ŀ��Ϣ
contents = get(handles.Num_eNB_Ant,'String');
channel = contents{get(handles.Num_eNB_Ant, 'Value')};
switch channel
    case '1��'
        NumeNBAnt = 1;
    case '2��'
        NumeNBAnt = 2;
    case '4��'
        NumeNBAnt = 4;
    case '8��'
        NumeNBAnt = 8;      
end
% ��ȡUE������Ŀ��Ϣ
contents = get(handles.Num_UE_Ant,'String');
channel = contents{get(handles.Num_UE_Ant, 'Value')};
switch channel
    case '1��'
        NumUEAnt = 1;
    case '2��'
        NumUEAnt = 2;
    case '4��'
        NumUEAnt = 4;    
end
% ��ȡ��վ���߼����Ϣ
contents = get(handles.Dis_eNB_Ant,'String');
channel = contents{get(handles.Dis_eNB_Ant, 'Value')};
switch channel
    case '0.5��'
        DiseNBAnt = 0.5;
    case '4��'
        DiseNBAnt = 4;
    case '10��'
        DiseNBAnt = 10;   
end
% ��ȡUE������Ŀ��Ϣ
contents = get(handles.Dis_UE_Ant,'String');
channel = contents{get(handles.Dis_UE_Ant, 'Value')};
switch channel
   case '0.5��'
        DisUEAnt = 0.5;
    case '4��'
        DisUEAnt = 4;
    case '10��'
        DisUEAnt = 10;     
end
% ��ȡ��վ���߼�����Ϣ
contents = get(handles.Polar_eNB_Ant,'String');
channel = contents{get(handles.Polar_eNB_Ant, 'Value')};
switch channel
    case '90��'
        P_eNBFlag = 0;
    case '����45��'
        P_eNBFlag = 1;
end
% ��ȡUE���߼�����Ϣ
contents = get(handles.Ploar_UE_Ant,'String');
channel = contents{get(handles.Ploar_UE_Ant, 'Value')};
switch channel
    case '90��'
        P_UEFlag = 0;
    case '����45��'
        P_UEFlag = 1;    
end
% ��ȡ�ŵ���Ϣ
contents = get(handles.Channel_Type,'String');
channel = contents{get(handles.Channel_Type, 'Value')};
switch channel
    case 'AWGN'
        ChannelType = 0;
    case 'PB'
        ChannelType = 1;
    case 'VA'
        ChannelType = 2;
    case 'TU'
        ChannelType = 3;
    case 'EPA'
        ChannelType = 4;
    case 'ETU'
        ChannelType = 5;
    case 'EVA'
        ChannelType = 6;
    case 'SCME_S_Marco'
        ChannelType = 7;
    case 'SCME_U_Marco'
        ChannelType = 8;
    case 'SCME_U_Mirco'
        ChannelType = 9;
end
% ��ȡ����֡�����з�����Ϣ 
contents = get(handles.Config_frame, 'String');
channel = contents{get(handles.Config_frame, 'Value')};
switch channel
    case '0'
        ConfigFrame = ['D' 'S' 'U' 'U' 'U' 'D' 'S' 'U' 'U' 'U'];
    case '1'
        ConfigFrame = ['D' 'S' 'U' 'U' 'D' 'D' 'S' 'U' 'U' 'D'];
    case '2'
        ConfigFrame = ['D' 'S' 'U' 'D' 'D' 'D' 'S' 'U' 'D' 'D'];
    case '3'
        ConfigFrame = ['D' 'S' 'U' 'U' 'U' 'D' 'S' 'D' 'D' 'D'];   %  zt  090427
    case '4'
        ConfigFrame = ['D' 'S' 'U' 'U' 'D' 'D' 'S' 'D' 'D' 'D'];   %  zt  090427
    case '5'
        ConfigFrame = ['D' 'S' 'U' 'D' 'D' 'D' 'S' 'D' 'D' 'D'];   %  zt  090427
    case '6'
        ConfigFrame = ['D' 'S' 'U' 'U' 'U' 'D' 'S' 'U' 'U' 'D'];
end
% ��ȡ������֡������Ϣ 
contents = get(handles.Config_DGU_frame, 'String');
channel = contents{get(handles.Config_DGU_frame, 'Value')};
switch channel
    case '0'
        DGUConfig = [3 10 1];
    case '1'
        DGUConfig = [9 4 1];
    case '2'
        DGUConfig = [10 3 1];
    case '3'
        DGUConfig = [11 2 1];
    case '4'
        DGUConfig = [12 1 1];
    case '5'
        DGUConfig = [3 9 2];
    case '6'
        DGUConfig = [9 3 2];
    case '7'
        DGUConfig = [10 2 2];
    case '8'
        DGUConfig = [11 1 2];
end
% ��ȡҵ���ŵ����Ʒ�ʽ��Ϣ
contents = get(handles.Mod_type, 'String');
channel = contents{get(handles.Mod_type, 'Value')};
switch channel
    case 'QPSK'
        ModType = 1;
    case '16QAM'
        ModType = 2;
    case '64QAM'
        ModType = 3;
end
% ��ȡ�ŵ�������Ϣ
contents = get(handles.BW, 'String');
channel = contents{get(handles.BW, 'Value')};
switch channel
     case '1.4M'
        BW = 1.4e6;
        FFT_N = 128;
    case '3M'
        BW = 3e6;
        FFT_N = 256;
    case '5M'
        BW = 5e6;
        FFT_N = 512;
    case '10M'
        BW = 10e6;
        FFT_N = 1024;
    case '20M'
        BW = 20e6;
        FFT_N = 2048;
end
% ��ȡCP��Ϣ
contents = get(handles.CP_type,'String');
channel = contents{get(handles.CP_type, 'Value')};
switch channel
    case '��CP'
        CPType = 0;
    case '��CP'
        CPType= 1;
end
% ��ȡ���ز������Ϣ
contents = get(handles.Delta_Subcarrier,'String');
channel = contents{get(handles.Delta_Subcarrier, 'Value')};
switch channel
    case '15KHz'
        SubDelta = 15e3;
    case '7.5KHz'
        SubDelta= 7.5e3;
    case '1.25KHz'
        SubDelta= 1.25e3;
end
% ��ȡHARQ������Ϣ
HARQ_Close = get(handles.HARQ_Close, 'Value');
HARQ_Open = get(handles.HARQ_Open, 'Value');
% ��ȡ����ش���Ŀ��Ϣ
contents = get(handles.Num_Max_Retry,'String');
NumHARQ = str2double(contents);
% ��ȡ����ش���Ŀ��Ϣ
contents = get(handles.HARQ_delay,'String');
HARQDelay  = str2double(contents);

% ��ȡ��С��������Ϣ   %added by libin 090319
AdCell_Close = get(handles.AdCell_Close, 'Value');
AdCell_Open = get(handles.AdCell_Open, 'Value');
% ��ȡ��С����Ŀ��Ϣ
contents = get(handles.AdCell_Num,'String');
channel = contents{get(handles.AdCell_Num, 'Value')};
NumAdCell = str2double(channel);
% ��ȡ��С��������Ϣ
contents = get(handles.AdCell_Power,'String');
PowerAdCell  = str2double(contents);
%%����õ���������
simpara_public(SNRMin,SNRStep,SNRMax,FrameMax,FrameMin,UEspeed,TBSize,NumRB,OffsetTime,OffsetFre,NumeNBAnt,NumUEAnt,DiseNBAnt,DisUEAnt,P_eNBFlag,P_UEFlag,...
                          ChannelType,DGUConfig,ConfigFrame,ModType,BW,FFT_N,CPType,SubDelta,HARQ_Close,HARQ_Open,NumHARQ,HARQDelay,...
                          AdCell_Close,AdCell_Open,NumAdCell,PowerAdCell)

% ��ȡ�ŵ�����������Ϣ
contents = get(handles.Channel_Estimation_Types, 'String');
channel = contents{get(handles.Channel_Estimation_Types, 'Value')};
switch channel
     case 'LS'
        ChEstType  = 'LS';
    case 'LMMSE'
        ChEstType  = 'LMMSE';
    case 'IDEAL'
        ChEstType  = 'IDEAL';
    case 'ʱ�����'
        ChEstType  = 'TimeCorr';
    case 'Hann��'
        ChEstType  = 'HannWindow';
    case 'DCT'
        ChEstType  = 'DCT';
    case 'С���任'
        ChEstType  = 'Wavelet';
    case '��ά�˲�'
        ChEstType  = '2d-filter';
end
% ��ȡ��MIMO�㷨��Ϣ
contents = get(handles.Receiver_Types, 'String');
channel = contents{get(handles.Receiver_Types, 'Value')};
switch channel
     case 'MF'
        ReceiveTypes  = 'MF';
     case 'LMMSE-SIC'
        ReceiveTypes  = 'MMSE-SIC';
     case 'MRC'
        ReceiveTypes  = 'MRC';
    case 'MMSE'
        ReceiveTypes  = 'MMSE';
    case 'ZF'
        ReceiveTypes  = 'ZF';
end
% ��ȡ�ŵ����Ʋ�ֵ�㷨��Ϣ
contents = get(handles.Interpolation_Method, 'String');
channel = contents{get(handles.Interpolation_Method, 'Value')};
switch channel
     case '���Բ�ֵ'
        InterMethod  = 'Linear';
     case '�����Բ�ֵ'
        InterMethod  = 'nonLinear';
    case '�ǲ�ֵ'
        InterMethod  = 'iteration';
end
% ��ȡ����MIMO�㷨��Ϣ
contents = get(handles.BF_flag, 'String');
channel = contents{get(handles.BF_flag, 'Value')};
if strcmp(SimLinkPara,'DownDataLink')
    switch channel                          % sy 090420
        case 'Beamforming'
            BFFlag  = 1;
        case 'Precoding'
            BFFlag  = 0;
    end
else
    BFFlag  = 0;
end
%%����õ��㷨���ò���
simpara_method(ChEstType,ReceiveTypes,InterMethod,BFFlag);

if strcmp(SimLinkPara(1:2),'UP') || (BFFlag == 1)%%�����ŵ�
    % ��ȡSRS������Ϣ
    SRS_Close = get(handles.SRS_Close, 'Value');
    SRS_Open = get(handles.SRS_Open, 'Value');
    % ��ȡ���û�������Ϣ
    Multi_User_Close = get(handles.Multi_User_Close, 'Value');
    Multi_User_Open = get(handles.Multi_User_Open, 'Value');
    % ��ȡ��Ƶ������Ϣ
    contents = get(handles.HopFlag, 'String');
    channel = contents{get(handles.HopFlag, 'Value')};
    switch channel
        case '����Ƶ'
            HopFlag  = 0;
        case '��֡����Ƶ'
            HopFlag  = 1;
        case '��֡����Ƶ'
            HopFlag  = 2;        
    end
    % ��ȡ�����û���Ŀ��Ϣ
    contents = get(handles.Inter_UE_Num,'String');
    Inter_UE_Num = str2double(contents);
    %��ȡ�����û�����ƫ��ֵ
    contents = get(handles.inter_UE_SNR, 'String');
    channel = contents{get(handles.inter_UE_SNR, 'Value')};
    switch channel
        case '0dB'
            SNRInterUser  = 0;
        case '1dB'
            SNRInterUser  = 1;
        case '2dB'
            SNRInterUser  = 2;
        case '3dB'
            SNRInterUser  = 3;
        case '-1dB'
            SNRInterUser  = -1;
        case '-2dB'
            SNRInterUser  = -2;
        case '-3dB'
            SNRInterUser  = -3;
    end   
    simpara_UPLink(SRS_Close,SRS_Open,Multi_User_Close,Multi_User_Open,HopFlag,SNRInterUser,Inter_UE_Num);
end
    
if strcmp(SimLinkPara,'UPDataLink') || (BFFlag == 1 && strcmp(SimLinkPara(1:4),'Down')) % PUSCH�ŵ�
    %%%SRS��������%%%
    contents = get(handles.SRS_Period, 'String');
    channel = contents{get(handles.SRS_Period, 'Value')};
    switch channel
        case '2ms'
            SRSPeriod  = 2;
        case '5ms'
            SRSPeriod  = 5;
        case '10ms'
            SRSPeriod  = 10;
        case '20ms'
            SRSPeriod  = 20;
        case '40ms'
            SRSPeriod  = 40;
        case '80ms'
            SRSPeriod  = 80;
        case '160ms'
            SRSPeriod  = 160;
    end
    simpara_PUSCH(SRSPeriod);
    
elseif strcmp(SimLinkPara,'UPControlLink')   % PUCCH�ŵ�
    %��ȡPUCCH�����ʽ����ѡ��
    contents = get(handles.PUCCHFormat, 'String');
    channel = contents{get(handles.PUCCHFormat, 'Value')};
    switch channel
        case '1'
            Config = '1';
        case '1a'
            Config = '1a';
        case '1b'
            Config = '1b';
        case '2'
            Config = '2';
        case '2a'
            Config = '2a';
        case '2b'
            Config = '2b';
    end
   simpara_PUCCH(Config);
    
elseif strcmp(SimLinkPara,'UPRACHLink')   % PRACH�ŵ�
    %��ȡ�ߵ���С����Ϣ
    contents = get(handles.HighSpeedCell_flag, 'String');
    channel = contents{get(handles.HighSpeedCell_flag, 'Value')};
    switch channel
        case '����С��'
            HighSpeedFlag = 1;
        case '����С��'
            HighSpeedFlag = 0;
    end
    contents = get(handles.RACH_Config, 'String');
    RACH_Config = str2double(contents);
    if RACH_Config > 57 || RACH_Config < 0
        error('RACH���ò�������');
    end
    contents = get(handles.Ncs, 'String');
    Ncs = str2double(contents);
    
    simpara_PRACH(HighSpeedFlag,RACH_Config,Ncs);
end
    
if strcmp(SimLinkPara(1:4),'Down')   % �����ŵ�
    %��ȡ����ҵ���ŵ�����
    contents = get(handles.Flag_DownChannel, 'String');
    channel = contents{get(handles.Flag_DownChannel, 'Value')};
    switch channel
        case 'PDSCH'
            Linkmode = 'PDSCH';
        case 'PBCH'
            Linkmode = 'PBCH';
        case 'PHICH'
            Linkmode = 'PHICH';
        case 'PDCCH'
            Linkmode = 'PDCCH';
        case 'PCFICH'
            Linkmode = 'PCFICH';
    end    
    % ��ȡPAPR��Ϣ
    contents = get(handles.PAPR_flag,'String');
    channel = contents{get(handles.PAPR_flag, 'Value')};
    switch channel
        case '����PAPR'
            PAPR = 0;
        case '����PAPR'
            PAPR = 1;
    end
    % ��papr������ʽ��Ϣ
    contents = get(handles.PAPR_Method, 'String');
    channel = contents{get(handles.PAPR_Method, 'Value')};
    switch channel
        case 'Clipping'
            PAPRMethodFlag  =0;
        case 'SLM'
            PAPRMethodFlag  = 1;
        case 'PTS'
            PAPRMethodFlag  = 2;
    end
    % ��ȡ�����ŵ�������Ϣ
    contents = get(handles.ControlChannelLength, 'String');
    channel = contents{get(handles.ControlChannelLength, 'Value')};
    switch channel
        case '1 Symbol'
            Control_Len  = 1;
        case '2 Symbols'
            Control_Len  = 2;
        case '3 Symbols'
            Control_Len  = 3;
    end
    % ��ȡPHICH�ŵ�������Ϣ
    contents = get(handles.PHICHLength, 'String');
    channel = contents{get(handles.PHICHLength, 'Value')};
    switch channel
        case '1 Symbol'
            PHICH_Len  = 1;
        case '2 Symbols'
            PHICH_Len  = 2;
        case '3 Symbols'
            PHICH_Len  = 3;
    end
    if PHICH_Len>Control_Len
        msgbox('PHICH�ŵ����Ȳ��ܴ��ڿ����ŵ����ȣ�');
        error('PHICH�ŵ����Ȳ��ܴ��ڿ����ŵ����ȣ�');
    end
    % ��ȡ����Ϣ��Ϣ
    contents = get(handles.Num_stream, 'String');
    channel = contents{get(handles.Num_stream, 'Value')};
    switch channel
        case '1'
            Num_Stream  = 1;
        case '2'
            Num_Stream  = 2;
    end
    %���PDCCH��Ŀ��Ϣ
    contents = get(handles.PDCCH_Num, 'String');
    PDCCH_Num = str2double(contents);
    % �����ѡ����Ϣ
    contents = get(handles.Num_Layer, 'String');
    channel = contents{get(handles.Num_Layer, 'Value')};
    switch channel
        case '1'
            Layer  = 1;
        case '2'
            Layer  = 2;
        case '3'
            Layer  = 3;
        case '4'
            Layer  = 4;
    end
     %��ò���ƫ����Ϣ
    contents = get(handles.Sample_offset, 'String');
    Sample_offset = str2double(contents);
    
    if Layer>1 && BFFlag == 1
        error('The number of code-word streams or Layer can not be greater than one in mode of Beamforming!');
    end
    
    simpara_downlink(Linkmode,PAPR,PAPRMethodFlag,Control_Len,PHICH_Len,Num_Stream,PDCCH_Num,Layer,Sample_offset);
end

Start_Time = clock;
fprintf('�������п�ʼʱ��:%d��%d��%d��%dʱ%d��%d��\n',Start_Time(1),Start_Time(2),Start_Time(3),Start_Time(4),Start_Time(5),round(Start_Time(6)));
disp('WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW');
disp (strcat('�����ŵ�ҵ������:   ',SimLinkPara));
disp('MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM');

% if (input('can we begin? (y=Yes	; n=No)','s')=='n');return;end
set(handles.ResultPrint, 'Enable','off');

main;

End_Time = clock;
fprintf('�������н���ʱ��:%d��%d��%d��%dʱ%d��%d��\n',End_Time(1),End_Time(2),End_Time(3),End_Time(4),End_Time(5),round(End_Time(6)));
set(handles.ResultPrint, 'Enable','on'); 

msgbox('              ���η������','��ʾ','modal');
set(handles.StartSim, 'String', '��ʼ����');

clear all��

% --- Executes during object creation, after setting all properties.
function SRS_duration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to srs_period (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function SRS_Period_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SRS_Period (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function SRS_Close_Callback(hObject,eventdata,handles)
SRS_Close = get(handles.SRS_Close, 'Value');
SRS_Open = get(handles.SRS_Open, 'Value');
if SRS_Close == 1 && SRS_Open == 0
    myHandle=findobj(gcbf,'Tag','SRS_Period');
    set(myHandle,'Enable','off');
elseif SRS_Close == 0 && SRS_Open == 1
    myHandle=findobj(gcbf,'Tag','SRS_Period');
    set(myHandle,'Enable','on');
else
    msgbox('��ѡ��SRS����״̬���رջ�򿪣�');
end

function Multi_User_Close_Callback(hObject,eventdata,handles)
Multi_User_Open = get(handles.Multi_User_Open, 'Value');
Multi_User_Close = get(handles.Multi_User_Close, 'Value');
if Multi_User_Close == 1 && Multi_User_Open == 0
    myHandle=findobj(gcbf,'Tag','Inter_UE_Num');
    set(myHandle,'Enable','off');
    myHandle=findobj(gcbf,'Tag','inter_UE_SNR');
    set(myHandle,'Enable','off');
elseif Multi_User_Close == 0 && Multi_User_Open == 1
    myHandle=findobj(gcbf,'Tag','Inter_UE_Num');
    set(myHandle,'Enable','on');
    myHandle=findobj(gcbf,'Tag','inter_UE_SNR');
    set(myHandle,'Enable','on');
else
    msgbox('��ѡ����û�����״̬���رջ�򿪣�');
end

function HARQ_Close_Callback(hObject,eventdata,handles)
HARQ_Open = get(handles.HARQ_Open, 'Value');
HARQ_Close = get(handles.HARQ_Close, 'Value');
if HARQ_Close == 1 && HARQ_Open == 0
    myHandle=findobj(gcbf,'Tag','HARQ_delay');
    set(myHandle,'Enable','off');
    myHandle=findobj(gcbf,'Tag','Num_Max_Retry');
    set(myHandle,'Enable','off');
elseif HARQ_Close == 0 && HARQ_Open == 1
    myHandle=findobj(gcbf,'Tag','HARQ_delay');
    set(myHandle,'Enable','on');
    myHandle=findobj(gcbf,'Tag','Num_Max_Retry');
    set(myHandle,'Enable','on');
else
    msgbox('��ѡ��HARQ����״̬���رջ�򿪣�');
end

function AdCell_Close_Callback(hObject, eventdata, handles) 
% hObject    handle to AdCell_Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AdCell_Open = get(handles.AdCell_Open, 'Value');
AdCell_Close = get(handles.AdCell_Close, 'Value');
if AdCell_Close == 1 && AdCell_Open == 0
    myHandle=findobj(gcbf,'Tag','AdCell_Num');
    set(myHandle,'Enable','off');
    myHandle=findobj(gcbf,'Tag','AdCell_Power');
    set(myHandle,'Enable','off');
elseif AdCell_Close == 0 && AdCell_Open == 1
    myHandle=findobj(gcbf,'Tag','AdCell_Num');
    set(myHandle,'Enable','on');
    myHandle=findobj(gcbf,'Tag','AdCell_Power');
    set(myHandle,'Enable','on');
else
    msgbox('��ѡ����С������״̬���رջ�򿪣�');
end

% --- Executes on selection change in Flag_DownChannel.
    function Flag_DownChannel_Callback(hObject, eventdata, handles)
        % hObject    handle to Flag_DownChannel (see GCBO)
        % eventdata  reserved - to be defined in a future version of MATLAB
        % handles    structure with handles and user data (see GUIDATA)

        % Hints: contents = get(hObject,'String') returns Flag_DownChannel contents as cell array
        %        contents{get(hObject,'Value')} returns selected item from Flag_DownChannel
        contents = get(handles.Flag_DownChannel, 'String');
        channel = contents{get(handles.Flag_DownChannel, 'Value')};
        switch channel
            case 'PDSCH'
                set(handles.PDCCH_Num,'Enable','off');
                set(handles.PHICHLength,'Enable','off');
                set(handles.Num_Layer,'Enable','on');
                set(handles.Num_stream,'Enable','on');
                set(handles.ControlChannelLength,'Enable','on');
                set(handles.BF_flag, 'Enable','on');
                set(handles.AdCell_Close, 'Enable','on');
                set(handles.AdCell_Open, 'Enable','on');
                set(handles.AdCell_Num, 'Enable','off');
                set(handles.AdCell_Power, 'Enable','off');
            case 'PBCH'
                set(handles.PDCCH_Num,'Enable','off');
                set(handles.PHICHLength,'Enable','off');
                set(handles.Num_Layer,'Enable','off');
                set(handles.Num_stream,'Enable','off');
                set(handles.ControlChannelLength,'Enable','off');
                set(handles.BF_flag, 'Enable','off');
                set(handles.AdCell_Close, 'Enable','on');
                set(handles.AdCell_Open, 'Enable','on');
                set(handles.AdCell_Num, 'Enable','off');
                set(handles.AdCell_Power, 'Enable','off');
            case 'PHICH'
                set(handles.PDCCH_Num,'Enable','off');
                set(handles.PHICHLength,'Enable','on');
                set(handles.Num_Layer,'Enable','off');
                set(handles.Num_stream,'Enable','off');
                set(handles.ControlChannelLength,'Enable','on');
                set(handles.BF_flag, 'Enable','off');
                set(handles.AdCell_Close, 'Enable','off');
                set(handles.AdCell_Open, 'Enable','off');
                set(handles.AdCell_Num, 'Enable','off');
                set(handles.AdCell_Power, 'Enable','off');
            case 'PDCCH'
                set(handles.PDCCH_Num,'Enable','on');
                set(handles.PHICHLength,'Enable','on');
                set(handles.Num_Layer,'Enable','off');
                set(handles.Num_stream,'Enable','off');
                set(handles.ControlChannelLength,'Enable','on');
                set(handles.BF_flag, 'Enable','off');
                set(handles.AdCell_Close, 'Enable','off');
                set(handles.AdCell_Open, 'Enable','off');
                set(handles.AdCell_Num, 'Enable','off');
                set(handles.AdCell_Power, 'Enable','off');
            case 'PCFICH'
                set(handles.PDCCH_Num,'Enable','off');
                set(handles.PHICHLength,'Enable','off');
                set(handles.Num_Layer,'Enable','off');
                set(handles.Num_stream,'Enable','off');
                set(handles.ControlChannelLength,'Enable','on');
                set(handles.BF_flag, 'Enable','off');
                set(handles.AdCell_Close, 'Enable','off');
                set(handles.AdCell_Open, 'Enable','off');
                set(handles.AdCell_Num, 'Enable','off');
                set(handles.AdCell_Power, 'Enable','off');
        end

        % --- Executes during object creation, after setting all properties.
        function Flag_DownChannel_CreateFcn(hObject, eventdata, handles)
            % hObject    handle to Flag_DownChannel (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    empty - handles not created until after all CreateFcns called

            % Hint: popupmenu controls usually have a white background on Windows.
            %       See ISPC and COMPUTER.
            if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
                set(hObject,'BackgroundColor','white');
            end



% --- Executes during object creation, after setting all properties.
function AdCell_Num_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AdCell_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function AdCell_Power_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AdCell_Power (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Channel_Type.
function Channel_Type_Callback(hObject, eventdata, handles)
% hObject    handle to Channel_Type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Channel_Type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Channel_Type


% --- Executes on selection change in Mod_type.
function Mod_type_Callback(hObject, eventdata, handles)
% hObject    handle to Mod_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Mod_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Mod_type


% --- Executes on selection change in BW.
function BW_Callback(hObject, eventdata, handles)
% hObject    handle to BW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns BW contents as cell array
%        contents{get(hObject,'Value')} returns selected item from BW


% --- Executes on selection change in Config_frame.
function Config_frame_Callback(hObject, eventdata, handles)
% hObject    handle to Config_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Config_frame contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Config_frame


% --- Executes on selection change in CP_type.
function CP_type_Callback(hObject, eventdata, handles)
% hObject    handle to CP_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns CP_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from CP_type


% --- Executes on selection change in Config_DGU_frame.
function Config_DGU_frame_Callback(hObject, eventdata, handles)
% hObject    handle to Config_DGU_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Config_DGU_frame contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Config_DGU_frame



function UE_speed_Callback(hObject, eventdata, handles)
% hObject    handle to UE_speed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of UE_speed as text
%        str2double(get(hObject,'String')) returns contents of UE_speed as a double


% --- Executes on selection change in Delta_Subcarrier.
function Delta_Subcarrier_Callback(hObject, eventdata, handles)
% hObject    handle to Delta_Subcarrier (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Delta_Subcarrier contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Delta_Subcarrier



function TB_Size_Callback(hObject, eventdata, handles)
% hObject    handle to TB_Size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TB_Size as text
%        str2double(get(hObject,'String')) returns contents of TB_Size as a double



function Num_RB_Callback(hObject, eventdata, handles)
% hObject    handle to Num_RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Num_RB as text
%        str2double(get(hObject,'String')) returns contents of Num_RB as a double



function SNR_Min_Callback(hObject, eventdata, handles)
% hObject    handle to SNR_Min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SNR_Min as text
%        str2double(get(hObject,'String')) returns contents of SNR_Min as a double



function SNR_Max_Callback(hObject, eventdata, handles)
% hObject    handle to SNR_Max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SNR_Max as text
%        str2double(get(hObject,'String')) returns contents of SNR_Max as a double



function SNR_Step_Callback(hObject, eventdata, handles)
% hObject    handle to SNR_Step (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SNR_Step as text
%        str2double(get(hObject,'String')) returns contents of SNR_Step as a double



function Offset_Time_Callback(hObject, eventdata, handles)
% hObject    handle to Offset_Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Offset_Time as text
%        str2double(get(hObject,'String')) returns contents of Offset_Time as a double



function Offset_Fre_Callback(hObject, eventdata, handles)
% hObject    handle to Offset_Fre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Offset_Fre as text
%        str2double(get(hObject,'String')) returns contents of Offset_Fre as a double


% --- Executes on selection change in AdCell_Num.
function AdCell_Num_Callback(hObject, eventdata, handles)
% hObject    handle to AdCell_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns AdCell_Num contents as cell array
%        contents{get(hObject,'Value')} returns selected item from AdCell_Num



function AdCell_Power_Callback(hObject, eventdata, handles)
% hObject    handle to AdCell_Power (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AdCell_Power as text
%        str2double(get(hObject,'String')) returns contents of AdCell_Power as a double


% --- Executes on selection change in Channel_Estimation_Types.
function Channel_Estimation_Types_Callback(hObject, eventdata, handles)
% hObject    handle to Channel_Estimation_Types (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Channel_Estimation_Types contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Channel_Estimation_Types


% --- Executes on selection change in Receiver_Types.
function Receiver_Types_Callback(hObject, eventdata, handles)
% hObject    handle to Receiver_Types (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Receiver_Types contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Receiver_Types


% --- Executes on selection change in Interpolation_Method.
function Interpolation_Method_Callback(hObject, eventdata, handles)
% hObject    handle to Interpolation_Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Interpolation_Method contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Interpolation_Method


% --- Executes on selection change in BF_flag.
function BF_flag_Callback(hObject, eventdata, handles)
% hObject    handle to BF_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns BF_flag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from BF_flag
contents = get(handles.BF_flag, 'String');
flag = contents{get(handles.BF_flag, 'Value')};
switch flag
    case 'Beamforming'
        %% BF������£�������������ҵ���ŵ���·��Ϣ added by libin 090506
        set(handles.Multi_User_Close, 'Enable','on');
        set(handles.Multi_User_Close, 'Value',1);
        set(handles.Multi_User_Open, 'Enable','on');
        set(handles.Multi_User_Open, 'Value',0);
        set(handles.SRS_Close, 'Enable','on');
        set(handles.SRS_Close, 'Value',1);
        set(handles.SRS_Open, 'Enable','on');
        set(handles.SRS_Open, 'Value',0);
        set(handles.Num_Max_Retry, 'Enable','off');
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');
        set(handles.inter_UE_SNR, 'Enable','off');
        set(handles.RACH_Config, 'Enable','off');
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','on');
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off');
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'Precoding'
        set(handles.Multi_User_Close, 'Enable','off');
        set(handles.Multi_User_Open, 'Enable','off');
        set(handles.SRS_Close, 'Enable','off');
        set(handles.SRS_Open, 'Enable','off');
        set(handles.Num_Max_Retry, 'Enable','off');
        set(handles.HARQ_delay, 'Enable','off');
        set(handles.Inter_UE_Num, 'Enable','off');
        set(handles.inter_UE_SNR, 'Enable','off');
        set(handles.RACH_Config, 'Enable','off');
        set(handles.Ncs, 'Enable','off');
        set(handles.HopFlag, 'Enable','off');
        set(handles.PUCCHFormat, 'Enable','off');
        set(handles.HighSpeedCell_flag, 'Enable','off');
end

% --- Executes on selection change in PAPR_flag.
function PAPR_flag_Callback(hObject, eventdata, handles)
% hObject    handle to PAPR_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns PAPR_flag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PAPR_flag


% --- Executes on selection change in Num_Layer.
function Num_Layer_Callback(hObject, eventdata, handles)
% hObject    handle to Num_Layer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Num_Layer contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Num_Layer


% --- Executes on selection change in PAPR_Method.
function PAPR_Method_Callback(hObject, eventdata, handles)
% hObject    handle to PAPR_Method (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns PAPR_Method contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PAPR_Method


% --- Executes on selection change in Num_stream.
function Num_stream_Callback(hObject, eventdata, handles)
% hObject    handle to Num_stream (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Num_stream contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Num_stream


% --- Executes on selection change in ControlChannelLength.
function ControlChannelLength_Callback(hObject, eventdata, handles)
% hObject    handle to ControlChannelLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns ControlChannelLength contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ControlChannelLength



function PDCCH_Num_Callback(hObject, eventdata, handles)
% hObject    handle to PDCCH_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PDCCH_Num as text
%        str2double(get(hObject,'String')) returns contents of PDCCH_Num as a double


% --- Executes on selection change in PHICHLength.
function PHICHLength_Callback(hObject, eventdata, handles)
% hObject    handle to PHICHLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns PHICHLength contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PHICHLength



function Sample_offset_Callback(hObject, eventdata, handles)
% hObject    handle to Sample_offset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sample_offset as text
%        str2double(get(hObject,'String')) returns contents of Sample_offset as a double



function HARQ_delay_Callback(hObject, eventdata, handles)
% hObject    handle to HARQ_delay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HARQ_delay as text
%        str2double(get(hObject,'String')) returns contents of HARQ_delay as a double



function Inter_UE_Num_Callback(hObject, eventdata, handles)
% hObject    handle to Inter_UE_Num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Inter_UE_Num as text
%        str2double(get(hObject,'String')) returns contents of Inter_UE_Num as a double


% --- Executes on selection change in inter_UE_SNR.
function inter_UE_SNR_Callback(hObject, eventdata, handles)
% hObject    handle to inter_UE_SNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns inter_UE_SNR contents as cell array
%        contents{get(hObject,'Value')} returns selected item from inter_UE_SNR



function RACH_Config_Callback(hObject, eventdata, handles)
% hObject    handle to RACH_Config (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RACH_Config as text
%        str2double(get(hObject,'String')) returns contents of RACH_Config as a double



function Ncs_Callback(hObject, eventdata, handles)
% hObject    handle to Ncs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ncs as text
%        str2double(get(hObject,'String')) returns contents of Ncs as a double


% --- Executes on selection change in HopFlag.
function HopFlag_Callback(hObject, eventdata, handles)
% hObject    handle to HopFlag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns HopFlag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from HopFlag


% --- Executes on selection change in PUCCHFormat.
function PUCCHFormat_Callback(hObject, eventdata, handles)
% hObject    handle to PUCCHFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns PUCCHFormat contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PUCCHFormat


% --- Executes on selection change in HighSpeedCell_flag.
function HighSpeedCell_flag_Callback(hObject, eventdata, handles)
% hObject    handle to HighSpeedCell_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns HighSpeedCell_flag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from HighSpeedCell_flag


% --- Executes on selection change in SRS_Period.
function SRS_Period_Callback(hObject, eventdata, handles)
% hObject    handle to SRS_Period (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns SRS_Period contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SRS_Period


% --- Executes on selection change in Num_eNB_Ant.
function Num_eNB_Ant_Callback(hObject, eventdata, handles)
% hObject    handle to Num_eNB_Ant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Num_eNB_Ant contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Num_eNB_Ant



function Num_Max_Retry_Callback(hObject, eventdata, handles)
% hObject    handle to Num_Max_Retry (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Num_Max_Retry as text
%        str2double(get(hObject,'String')) returns contents of Num_Max_Retry as a double


