function [OFDMDataOnAntennaInFre OFDMDataOnAntennaInFre_AdCell] = Precoding_UL(CWDataInFre,CWDataInFre_AdCell)
%  ����������������·Ԥ����ģ��
%  �������������ģ�����������CWDataInFre
%  ���������Ԥ����ģ�����������OFDMDataOnAntennaInFre
global UplinkPara
global PUSCHPara
global PUCCHPara
global PublicPara
global SimLinkPara

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090309
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
end
OFDMDataOnAntennaInFre_AdCell =[];

switch SimLinkPara
    case 'UPControlLink'
        TargetDataCarIndex = CarrierIndexGeneratorPUCCH;
        PUCCHPara .TargetDataCarIndex = TargetDataCarIndex;
        DataOFDMSymNum  = PublicPara.OFDMSymbolNum - PUCCHPara.DRSNum;
        CarrierNum = PublicPara.NumSubCarrierPRB;
        OFDMDataOnAntennaInFre = reshape(CWDataInFre,CarrierNum,DataOFDMSymNum,UplinkPara.NumUser);
        
        if AdCellFlag == 1      %added by libin 090309
            for k = 1: AdCellNum
                OFDMDataOnAntennaInFre_AdCell{k} = reshape(CWDataInFre_AdCell{k},CarrierNum,DataOFDMSymNum,1);
            end
        end
    case 'UPDataLink'
        TargetDataCarIndex = PUSCHPara.TargetDataCarIndex;
        CarrierNum = length(TargetDataCarIndex);   % �û��ز���
        DataOFDMSymNum = PublicPara.OFDMSymbolNum-2;
        % �����任 DFT
        CWDataInFre = CWDataInFre.';
        CWDataInFre = reshape(CWDataInFre,CarrierNum,DataOFDMSymNum,UplinkPara.NumUser);
        UserNumSubcarrier = size(CWDataInFre,1); %20080109 YUANLQ
        OFDMDataOnAntennaInFre = sqrt(1/UserNumSubcarrier) * fft(CWDataInFre); %20080109 YUANLQ
        
        if AdCellFlag == 1      %added by libin 090309
            for cell_index = 1:PublicPara.AdCellNum  
                AdCell_temp = CWDataInFre_AdCell{cell_index}.';
                AdCell_temp = reshape(AdCell_temp,CarrierNum,DataOFDMSymNum,1);
                UserNumSubcarrier = size(AdCell_temp,1); %20080109 YUANLQ
                OFDMDataOnAntennaInFre_AdCell{cell_index} = sqrt(1/UserNumSubcarrier) * fft(AdCell_temp); %20080109 YUANLQ
            end
        end
end




%***********************************************************************
function [TargetPUCCHCarIndex] = CarrierIndexGeneratorPUCCH
%***********************************************************************
% �������ƣ� CarrierIndexGenerator         
% ���������� 
% ��������� 
% ���������
% �޸�����        �汾��     �޸���	      �޸�����
%-----------------------------------------------

%***********************************************************************
%***********************************************************************
global PublicPara
global PUCCHPara

NULRB =  PublicPara.MaxRB; %�����ܹ����õ�RB��
PUCCHFormat = PUCCHPara.Config;
NRB2 = PUCCHPara. NRB2 ;  
NCS1  = PUCCHPara. NCS1 ;  
nPUCCH1 = PUCCHPara. nPUCCH1 ; %
nPUCCH2 = PUCCHPara. nPUCCH2 ; %
PUCCHshift = PUCCHPara. PUCCHshift ; 
c = PUCCHPara.c;
NRBSC =  PublicPara.NumSubCarrierPRB;
%PUCCHӳ������ز���RB������.����Э��36.211.820 5.4.3 
if strcmp(PUCCHFormat(1),'1') % for format 1,1a,1b.
    %to calculate m value.
    if nPUCCH1 < c*NCS1/PUCCHshift
        m = NRB2;
    else
        m = floor((nPUCCH1-c*NCS1/PUCCHshift)/(c*NRBSC/PUCCHshift)) + NRB2 + 1;
    end
    %to calculate subcarrier index.
    if mod(m-1,2) == 0 
        TargetPUCCHCarIndex(:,1) = floor(m/2);
        TargetPUCCHCarIndex(:,2) =  NULRB - 1 - floor(m/2);
    else
        TargetPUCCHCarIndex(:,2) = floor(m/2);
        TargetPUCCHCarIndex(:,1) =  NULRB - 1 - floor(m/2);
    end
else % for format 2,2a,2b.
    m = floor(nPUCCH2/NRBSC);
    if mod(m-1,2) == 0 
        TargetPUCCHCarIndex(:,1) = floor(m/2);
        TargetPUCCHCarIndex(:,2) =  NULRB - 1 - floor(m/2);
    else
        TargetPUCCHCarIndex(:,2) = floor(m/2);
        TargetPUCCHCarIndex(:,1) =  NULRB - 1 - floor(m/2);
    end
end
