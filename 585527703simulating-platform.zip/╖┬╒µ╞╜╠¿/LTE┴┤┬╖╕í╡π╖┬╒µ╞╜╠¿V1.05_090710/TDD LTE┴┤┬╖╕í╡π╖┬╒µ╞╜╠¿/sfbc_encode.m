function sfbcencode = sfbc_encode(modulation_data)
%**************************************************************************
% �������ƣ�  sfbc_encode.m
% ����������  sfbc����
% ����������  modulation_dataΪ�����������
% ���������  sfbcencodeΪ����������

% modified by libin 080521
%**************************************************************************
global PublicPara           % ����������ʼ��  modified by libin 080417

Num_Ant_Tx = PublicPara.Num_eNBAnt;

Len = size(modulation_data,2);
sfbcencode = [];
% ������sfbc����
if Num_Ant_Tx == 2 
   
    sfbcencode = zeros(2,2*Len);
   for iSymb = 1: Len
       
       sfbc_temp(1,:) = modulation_data(:, iSymb);
       
%        tmp1 = complex( -real(modulation_data(2, iSymb)), imag(modulation_data(2, iSymb)) );
%        tmp2 = complex( real(modulation_data(1, iSymb)), -imag(modulation_data(1, iSymb)) );

       sfbc_temp(2,:) = [-conj(modulation_data(2, iSymb)), conj(modulation_data(1, iSymb))];
       
       sfbcencode(:,2*iSymb-1:2*iSymb) = sqrt(1/2)*sfbc_temp;
   end
elseif Num_Ant_Tx == 4 
   sfbcencode = zeros(4,4*Len);
    for iSymb = 1: Len
       
       sfbc_temp(1, :) = [modulation_data(1 : 2, iSymb).', 0, 0];
       sfbc_temp(2, :) = [0, 0, modulation_data(3 : 4, iSymb).'];

       tmp1 = complex( -real(modulation_data(2, iSymb)), imag(modulation_data(2, iSymb)) );
       tmp2 = complex( real(modulation_data(1, iSymb)), -imag(modulation_data(1, iSymb)) );
       tmp3 = complex( -real(modulation_data(4, iSymb)), imag(modulation_data(4, iSymb)) );
       tmp4 = complex( real(modulation_data(3, iSymb)), -imag(modulation_data(3, iSymb)) );
       sfbc_temp(3, :) = [tmp1, tmp2, 0, 0];
       sfbc_temp(4, :) = [0, 0, tmp3, tmp4];

       sfbcencode(:,4*(iSymb-1)+1:4*iSymb) = sqrt(1/2)*sfbc_temp;
   end
end