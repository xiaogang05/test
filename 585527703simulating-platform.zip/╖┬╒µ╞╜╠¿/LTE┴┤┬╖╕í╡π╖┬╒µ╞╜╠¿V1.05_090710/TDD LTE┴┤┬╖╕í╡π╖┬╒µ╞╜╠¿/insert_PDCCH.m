function insertdata = insert_PDCCH(insertdata,tti,control_idxSC,Len,iteration)
% ����������  ����DCI��Ϣ������CRC���û����ţ��ŵ����룬����ƥ�䣬С����PDCCH�ϲ������ţ����ƣ�������Դӳ�����  zt 080604
global PublicPara
global DownlinkPara

Ant_select_flag = 0;     % zt 080721
Num_RB_UL = 25;          % zt 080722
flag = 0;      % zt 080721

nRNTI = PublicPara.RNTI;
Num_Control_OFDM = DownlinkPara.LengthCon;
Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_RB = PublicPara.MaxRB;              % zt 080722
Cell_ID = PublicPara.NcellID;
config_U_D_index = PublicPara.ConfigFrame;  %  zt 080715
special_tti = find(config_U_D_index== 'S');  %  zt  080610
modeOperation = DownlinkPara.modeOperation;
linkmode = DownlinkPara.Linkmode;
seed = PublicPara.Seed;

if Num_RB <= 10
    if sum(tti == special_tti)
        Num_Control_OFDM = 2;
    else
        Num_Control_OFDM = Num_Control_OFDM+1;
    end
else
    if sum(tti == special_tti) && (Num_Control_OFDM > 1)
        Num_Control_OFDM = 2;
    end        
end

if strcmp(linkmode,'PDSCH') || strcmp(linkmode,'PBCH')   %% ��ҵ���PBCH���ܷ��棬PDCCH����λ�ò���0����    
    control_idxSC_1 = control_idxSC(1:Len(1));
    control_idxSC_2 = control_idxSC(Len(1)+1:Len(1)+Len(2));
    control_idxSC_3 = control_idxSC(Len(1)+Len(2)+1:end);
    insertdata(1:Num_Ant_Tx,control_idxSC_1) = zeros(Num_Ant_Tx,Len(1));
    insertdata(Num_Ant_Tx+1:2*Num_Ant_Tx,control_idxSC_2) = zeros(Num_Ant_Tx,Len(2));
    insertdata(2*Num_Ant_Tx+1:3*Num_Ant_Tx,control_idxSC_3) = zeros(Num_Ant_Tx,Len(3));   
else
    %  ����DCI��Ϣ����
%     P_option = [1 2 3 4];    % zt 080721
%     P_temp = P_option(Num_RB <= [10 26 64 110]);
%     P = P_temp(1);
% 
%     if modeOperation == 0    % zt 080721
%         DCI_format = 1;
%         DCI_len = ceil(Num_RB/P)+17;
%         %     DCI_format = [0 1];
%         %     DCI_len = [ceil(log2(Num_RB_UL*(Num_RB_UL+1)/2))+16 ceil(Num_RB/P)+17];
%     elseif modeOperation == 2
% %         DCI_format = 0;
% %         DCI_len = ceil(log2(Num_RB_UL*(Num_RB_UL+1)/2))+16;
% %         DCI_format = [0 11];
% %         DCI_len = [ceil(log2(Num_RB_UL*(Num_RB_UL+1)/2))+16 ceil(log2(Num_RB*(Num_RB+1)/2))+18];
%         DCI_format = 1;
%         DCI_len = ceil(Num_RB/P)+17;
%     else
%         DCI_format = 2;
%         if Num_Ant_Tx == 2
%             DCI_len = ceil(Num_RB/P)+18+3+1;
%         else
%             DCI_len = ceil(Num_RB/P)+18+6+1;
%         end
%     end
    
    DCI_len = 35;  % for test
    DCI_format = 1;  % for test
    Num_PDCCH = length(DCI_format);
    CrcLength_PDCCH = 16;
    x = de2bi(nRNTI,16);                 % �û�ID����ָʲô��ÿ��PDCCH��ͬ��
    Rate = 0;                            %  ��������  1/3
    
    Data_combined = zeros(1,sum(Len(1:Num_Control_OFDM))*2); %����PDCCH��0
    % Data_combined = randint(1,sum(Len(1:Num_Control_OFDM))*2); %����PDCCH�������
    N_CCE_tti = floor(length(Data_combined)/72);
    
%     Y_tti = [nRNTI zeros(1,tti)];
%     A = 39827;
%     D = 65537;
%     for i = 1:tti
%         Y_tti(i+1) = mod(A * Y_tti(i),D);
%     end
%     L = [1 2 4 8];
%     ML = [6 6 2 2];
%     Z_tti = [];
%     for i = 1:4
%         Z_tti(i) = L(i) * mod(Y_tti(tti+1),floor(N_CCE_tti/L(i)));
%     end
    Z_tti = [0 0 0 0];  % for test

    Length_DCI_coded = zeros(1,Num_PDCCH);
    for i = 1:Num_PDCCH
        if  seed==1
            rand('state',10*(iteration-1)+tti+DCI_format(i));
            info_PDCCH = randint(1,DCI_len(i));
        else
            info_PDCCH = randint(1,DCI_len(i));
        end
        %  CRC
        DataCrc = CrcEncoder(info_PDCCH,CrcLength_PDCCH,0);
        %  �û�����
        DataCrc(length(DataCrc)-16+1:end) = mod(DataCrc(length(DataCrc)-16+1:end)+x,2);
        %  ����ѡ��    % zt 080721
        if Ant_select_flag == 1
            if UE_Ant == 0
                mask = zeros(1,16);
            else
                mask = [zeros(1,15) 1];
            end
            DataCrc(length(DataCrc)-16+1:end) = mod(DataCrc(length(DataCrc)-16+1:end)+mask,2);
        end
        %  �ŵ�����
        Data_coded = cc_encode(DataCrc,Rate);
        Length_DCI_coded(i) = length(Data_coded);
        %  PDCCH formatѡ��    % zt 080721
%         E_option = [72 144 288 576];
%         E_temp = E_option((E_option >= length(Data_coded)));
%         E = E_temp(1);
        E = 144;  % for test
        %  ����ƥ��
        DataRateMatch = CB_RateMatching(Data_coded,E,[],[],0);
        %  С����PDCCH�ϲ�
        CCE_num = E/72;
        loc = Z_tti(log2(CCE_num)+1)*72+1:Z_tti(log2(CCE_num)+1)*72+CCE_num*72;
        if sum(Data_combined(loc)) == 0
            Data_combined(Z_tti(log2(CCE_num)+1)*72+1:Z_tti(log2(CCE_num)+1)*72+CCE_num*72) = DataRateMatch;
        else
            flag = 1;
            while sum(Data_combined(loc)) ~= 0
                loc = loc(end)+1:loc(end)+CCE_num*72;
                flag = flag+1;
                if flag>ML(log2(CCE_num)+1)
                    break;
                end
            end
            if flag ~=1 && flag<=ML(log2(CCE_num)+1)
                Data_combined(Z_tti(log2(CCE_num)+1)*72+1:Z_tti(log2(CCE_num)+1)*72+CCE_num*72) = DataRateMatch;
            else
                disp('error,there is no room for PDCCH');
            end
        end
    end
    DownlinkPara.Length_DCI_coded = Length_DCI_coded;
    DownlinkPara.info_PDCCH = info_PDCCH;
    %  С������
%     Cint = floor(tti/2)*2^9 + Cell_ID;
    Cint = (tti-1)*2^9 + Cell_ID;
    Data_scrambled = Scrambling(Data_combined,Cint);

    %  ����
    Data_modulated = Modulator(Data_scrambled,1);

    %  ��ӳ��
    nSymb = length(Data_modulated);
    if Num_Ant_Tx == 1
        Data_layermapped = Data_modulated;
    else
        switch Num_Ant_Tx
            case 2 % 1:2 ӳ��ģʽ
                Data_layermapped = zeros(2, nSymb/2);

                Data_layermapped(1, :) = Data_modulated(1, 1:2:end );
                Data_layermapped(2, :) = Data_modulated(1, 2:2:end);
            case 4 % 1:4 ӳ��ģʽ
                Data_layermapped = zeros(4, nSymb/4);

                Data_layermapped(1, :) = Data_modulated(1, 1:4:end);
                Data_layermapped(2, :) = Data_modulated(1, 2:4:end);
                Data_layermapped(3, :) = Data_modulated(1, 3:4:end);
                Data_layermapped(4, :) = Data_modulated(1, 4:4:end);
        end
    end
    %  Ԥ����
    if Num_Ant_Tx == 1
        Data_precoded = Data_layermapped;
    else
        Data_precoded = sfbc_encode(Data_layermapped);
    end

    %  ������Դӳ��
    M_quad = floor(length(Data_modulated)/4);
    if M_quad>32
        C = 32;
        R = ceil(M_quad/C);
        N_D_REQ = R*C-M_quad;
        REQ_metrix = [ones(1,N_D_REQ)*inf 1:M_quad];
        Interleave_ind = Interleaving(M_quad,0);
        REQ_interleaved = REQ_metrix(Interleave_ind+1);
        REQ_interleaved((REQ_interleaved == inf)) = [];
    else
        Permute_Col=[1,17,9,25,5,21,13,29,3,19,11,27,7,23,15,31,0,16,8,24,4,20,12,28,2,18,10,26,6,22,14,30];
        Permute_Col((Permute_Col>M_quad-1)) = [];
        REQ_metrix = 1:M_quad;
        REQ_interleaved = REQ_metrix(Permute_Col+1);
    end
    for i = 0:M_quad-1
        REQ_shifted(i+1) = REQ_interleaved(mod(i+Cell_ID,M_quad)+1);
    end
    control_idxSC_1 = control_idxSC(1:Len(1));
    k_RE_group_1 = control_idxSC_1(1:4:end);
    control_idxSC_2 = control_idxSC(Len(1)+1:sum(Len(1:2)));
    k_RE_group_2 = control_idxSC_2(1:4:end);
    control_idxSC_3 = control_idxSC(sum(Len(1:2))+1:sum(Len(1:3)));
    k_RE_group_3 = control_idxSC_3(1:4:end);
    control_idxSC_4 = control_idxSC(sum(Len(1:3))+1:end);
    k_RE_group_4 = control_idxSC_4(1:4:end);
    if Num_Control_OFDM == 1
        k_low = k_RE_group_1(1);
        k_high = k_RE_group_1(end);
    elseif Num_Control_OFDM == 2
        k_low = min(k_RE_group_1(1),k_RE_group_2(1));
        k_high = max(k_RE_group_1(end),k_RE_group_2(end));
    elseif Num_Control_OFDM == 3
        k_low = min([k_RE_group_1(1) k_RE_group_2(1) k_RE_group_3(1)]);
        k_high = max([k_RE_group_1(end),k_RE_group_2(end),k_RE_group_3(end)]);
    else
        k_low = min([k_RE_group_1(1) k_RE_group_2(1) k_RE_group_3(1) k_RE_group_4(1)]);
        k_high = max([k_RE_group_1(end),k_RE_group_2(end),k_RE_group_3(end),k_RE_group_3(end)]);
    end

    m = 1;
    for k = k_low:k_high
        for l = 1:Num_Control_OFDM
            REQ = Data_precoded(:,(REQ_shifted(m)-1)*4+1:REQ_shifted(m)*4);
            if l == 1
                if ~isempty(k_RE_group_1) && k_RE_group_1(1) == k
                    start_loc = find(control_idxSC_1 == k);
                    insertdata(1:Num_Ant_Tx,control_idxSC_1(start_loc:start_loc+3)) = REQ;
                    m = m+1;
                    k_RE_group_1(1) = [];
                end
            elseif l == 2
                if ~isempty(k_RE_group_2) && k_RE_group_2(1) == k
                    start_loc = find(control_idxSC_2 == k);
                    insertdata(Num_Ant_Tx+1:2*Num_Ant_Tx,control_idxSC_2(start_loc:start_loc+3)) = REQ;
                    m = m+1;
                    k_RE_group_2(1) = [];
                end
            elseif l == 3
                if ~isempty(k_RE_group_3) && k_RE_group_3(1) == k
                    start_loc = find(control_idxSC_3 == k);
                    insertdata(2*Num_Ant_Tx+1:3*Num_Ant_Tx,control_idxSC_3(start_loc:start_loc+3)) = REQ;
                    m = m+1;
                    k_RE_group_3(1) = [];
                end
            else
                if ~isempty(k_RE_group_4) && k_RE_group_4(1) == k
                    start_loc = find(control_idxSC_4 == k);
                    insertdata(3*Num_Ant_Tx+1:4*Num_Ant_Tx,control_idxSC_4(start_loc:start_loc+3)) = REQ;
                    m = m+1;
                    k_RE_group_4(1) = [];
                end
            end
        end
    end

    if Num_Control_OFDM == 1
        if m ~= M_quad+1 || ~isempty(k_RE_group_1)
            error('The PDCCH data and PDCCH resource is not match');
        end
    elseif Num_Control_OFDM == 2
        if m ~= M_quad+1 || ~isempty(k_RE_group_1) || ~isempty(k_RE_group_2)
            error('The PDCCH data and PDCCH resource is not match');
        end
    else
        if m ~= M_quad+1 || ~isempty(k_RE_group_1) || ~isempty(k_RE_group_2) || ~isempty(k_RE_group_3)
            error('The PDCCH data and PDCCH resource is not match');
        end
    end
end