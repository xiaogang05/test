function Results_Plot(ResultRec)

%**********************************************
%������������
global PublicPara
global SimLinkPara
global DownlinkPara
global PUCCHPara
global Channel
global PRACHPara

CPtype = PublicPara.CPtype;
%**********************************************]
SNR = PublicPara.SNR;
% disp(['SNR = ',num2str(SNR)]);
if strcmp(SimLinkPara,'UPDataLink') %PUSCH
    figure;
    semilogy(SNR,ResultRec.BER,'-b*');
    title(['PUSCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ','TBSize= ',int2str(PublicPara.TBSize),' RBNum=',int2str(PublicPara.NumRB)...
        ' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
    grid on;xlabel('SNR');ylabel('PUSCH BER');
    figure;
    semilogy(SNR,ResultRec.BLER,'-ro');
    title(['PUSCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ','TBSize= ',int2str(PublicPara.TBSize),' RBNum=',int2str(PublicPara.NumRB)...
        ' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
    grid on;xlabel('SNR');ylabel('PUSCH BLER');
    figure;
    semilogy(SNR,ResultRec.Throughput,'-g>');
    title(['PUSCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ','TBSize= ',int2str(PublicPara.TBSize),' RBNum=',int2str(PublicPara.NumRB)...
        ' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
    grid on;xlabel('SNR');ylabel('PUSCH Throughput');
    
elseif strcmp(SimLinkPara,'UPControlLink')  %PUCCH

    Config = PUCCHPara.Config ;
    if strcmp(Config,'2')
        if CPtype == 0
            figure;
            semilogy(SNR,ResultRec.PUCCHCQIBLER,'b-*');
            title(['PUCCH Config:',Config,' ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',' BW=',...
                int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
            grid on;xlabel('SNR');ylabel('BLER');
            legend('PUCCHCQIBLER');
        else
            figure;
            semilogy(SNR,ResultRec.PUCCHCQIBLER,'b-*');hold on;
            semilogy(SNR,ResultRec.PUCCHACKBLER ,'r-o');
            title(['PUCCH Config:',Config,' ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',' BW=',...
                int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
            grid on;xlabel('SNR');ylabel('BLER');
            legend('PUCCHCQIBLER','PUCCHACKBLER');
        end
    elseif strcmp(Config(1),'1')
        figure;
        semilogy(SNR,ResultRec.PUCCHACKBLER ,'r-o');
        title(['PUCCH Config:',Config,' ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',' BW=',...
                int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
        grid on;xlabel('SNR');ylabel('BLER');
        legend('PUCCHACKBLER');
    else
        figure;
        semilogy(SNR,ResultRec.PUCCHCQIBLER,'b-*');hold on;
        semilogy(SNR,ResultRec.PUCCHACKBLER ,'r-o');
        title(['PUCCH Config:',Config,' ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',' BW=',...
                int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
        grid on;xlabel('SNR');ylabel('BLER');
        legend('PUCCHCQIBLER','PUCCHACKBLER');
    end
elseif strcmp(SimLinkPara,'UPRACHLink') %PRACH
    figure ;
    semilogy(SNR, ResultRec.FalseDetectPro ,'b-*');hold on;
    semilogy(SNR,  ResultRec.MissDetectPro ,'r-o');
    title(['PRACH Config:',int2str(PRACHPara.RACHFormat),' ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',' BW=',...
                int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
    grid on;xlabel('SNR');ylabel('BLER');
    legend('FalseDetectPro','MissDetectPro');
    disp('FalseDetectPro:');
    disp(ResultRec.FalseDetectPro);
    disp('MissDetectPro:');
    disp(ResultRec.MissDetectPro);
elseif strcmp(SimLinkPara,'DownDataLink') %���п���ҵ���ŵ�
    %         if Channel_Types == 0||Channel_Types == 2
    %******************************************************************
    %��ͼ
    switch DownlinkPara.Linkmode
        case 'PBCH'
            figure;
            semilogy(SNR,ResultRec.Control_BLER,'r-*');
            title(['PBCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ',' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
            grid on;xlabel('SNR');ylabel('BLER');            
        case 'PCFICH'
            figure;
            semilogy(SNR,ResultRec.Control_BLER,'b-o');
             title(['PCFICH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ',' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
             grid on;xlabel('SNR');ylabel('BLER');
        case 'PHICH'
            figure;
            semilogy(SNR,ResultRec.Control_BLER,'k-<');
            if DownlinkPara.info_PHICH(1) == 1
                title(['PHICH( NACK -> ACK ) ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ',' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
                grid on;xlabel('SNR');ylabel('BLER');
            else
                title(['PHICH( ACK -> NACK ) ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ',' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
                grid on;xlabel('SNR');ylabel('BLER');
            end
        case 'PDCCH'
            figure;
            semilogy(SNR,ResultRec.Control_BLER,'m->');
             title(['PDCCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt)','R ',' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
             grid on;xlabel('SNR');ylabel('BLER');
        case 'PDSCH'
            switch DownlinkPara.modeOperation
                case 0
                    dis_temp = '���˿�';
                case 1
                     dis_temp = 'Precoding';
                case 2
                    dis_temp = 'SFBC';
            end
                
            figure;
            semilogy(SNR,ResultRec.BLER,'b-*');
            title(['PDSCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',dis_temp,' TBSize= ',int2str(PublicPara.TBSize),' RBNum=',int2str(PublicPara.NumRB)...
                ' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
            grid on;xlabel('SNR');ylabel('BLER');
            figure;
            semilogy(SNR,ResultRec.BER,'r-o');
            title(['PDSCH ',int2str(PublicPara.Num_UEAnt),'T',int2str(PublicPara.Num_eNBAnt),'R ',dis_temp,' TBSize= ',int2str(PublicPara.TBSize),' RBNum=',int2str(PublicPara.NumRB)...
                ' BW=',int2str(PublicPara.BW/1e6),'M',' ChannelType: ',Channel.scenario]);
            grid on;xlabel('SNR');ylabel('BER');
    end
elseif strcmp(SimLinkPara, 'DownSysLink')%ͬ���ŵ�
end




