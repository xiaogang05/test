function [BitStream Pilot Pilot_Adcell] = BinaryGeneratorPD
%**********************************************************************
% �������ƣ� BinaryGeneratorPD
% ���������� ����ԭʼbit����
% ���������
% ���������
%     BitStream      �� ���ɵ�ԭʼ�����ź�
%     Pilot          �� �뵼Ƶ�йص��ź�
%**********************************************************************
global PublicPara
global DownlinkPara
global System_clock

Linkmode = DownlinkPara.Linkmode;%�ŵ�ģ��
TBSize = PublicPara.TBSize;
subframe = System_clock(1);
tti = System_clock(2);
CP_Types = PublicPara.CPtype;
Num_Ant_Tx = PublicPara.Num_eNBAnt;%��������
Cell_ID = PublicPara.NcellID;  %ʶ���С��ID
seed = PublicPara.Seed;

AdCellFlag = PublicPara.AdCellFlag;     %added by libin 090309
if AdCellFlag == 1
    AdCellNum = PublicPara.AdCellNum;
    AdCellID = PublicPara.AdCellID;
    Pilot_all_AdCell = zeros(AdCellNum,6,220);
end
Pilot_Adcell = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��Ƶbitλ����
switch CP_Types
    case 0  % ����830���������ʼֵ������N_cp      zt 080716
        N_cp = 1;
        symbol_slot = [0 1 4 0 1 4];
        ns_frame = [(2*tti-2) * ones(1,3) (2*tti-1) * ones(1,3)];
        Pilot_Sequence_all = zeros(length(symbol_slot),220);        
        for i_symbol = 1:6
            Cint = 2^10 * (7*(ns_frame(i_symbol)+1) + symbol_slot(i_symbol) + 1) * (2*Cell_ID + 1) + 2*Cell_ID + N_cp;
            c = Scrambling_gen(4*110,Cint);
            Pilot_Sequence_all(i_symbol,:) = (1/sqrt(2)) * ((1 - 2 * c(1:2:end)) + j * (1 - 2 * c(2:2:end)));    %  zt  090427
            if AdCellFlag == 1               %added by libin 090309
                for k = 1: AdCellNum
                    Cint = 2^10 * (7*(ns_frame(i_symbol)+1) + symbol_slot(i_symbol) + 1) * (2*AdCellID(k) + 1) + 2*AdCellID(k) + N_cp;
                    c = Scrambling_gen(4*110,Cint);
                    Pilot_all_AdCell(k,i_symbol,:) = (1/sqrt(2)) * ((1 - 2 * c(1:2:end)) + j * (1 - 2 * c(2:2:end)));    %  zt  090427
                end
            end
        end
        switch Num_Ant_Tx
            case {1,2}
                pilotsymbol_1 = Pilot_Sequence_all(1,:);
                pilotsymbol_5 = Pilot_Sequence_all(3,:);
                pilotsymbol_8 = Pilot_Sequence_all(4,:);
                pilotsymbol_12 = Pilot_Sequence_all(6,:);
                Pilot_Sequence = [pilotsymbol_1;pilotsymbol_5;pilotsymbol_8;pilotsymbol_12];
                if AdCellFlag == 1               %added by libin 090309
                    for k = 1: AdCellNum
                        pilotsymbol_1 = Pilot_all_AdCell(k,1,:);
                        pilotsymbol_5 = Pilot_all_AdCell(k,3,:);
                        pilotsymbol_8 = Pilot_all_AdCell(k,4,:);
                        pilotsymbol_12 = Pilot_all_AdCell(k,6,:);
                        Pilot_Adcell{k} = [pilotsymbol_1;pilotsymbol_5;pilotsymbol_8;pilotsymbol_12];
                    end
                end
            case {4,8}                                                        % sy  090416
                pilotsymbol_1 = Pilot_Sequence_all(1,:);
                pilotsymbol_2 = Pilot_Sequence_all(2,:);
                pilotsymbol_5 = Pilot_Sequence_all(3,:);
                pilotsymbol_8 = Pilot_Sequence_all(4,:);
                pilotsymbol_9 = Pilot_Sequence_all(5,:);
                pilotsymbol_12 = Pilot_Sequence_all(6,:);
                Pilot_Sequence = [pilotsymbol_1;pilotsymbol_2;pilotsymbol_5;pilotsymbol_8;pilotsymbol_9;pilotsymbol_12];
                if AdCellFlag == 1               %added by libin 090309
                    for k = 1: AdCellNum
                        pilotsymbol_1 = Pilot_all_AdCell(k,1,:);
                        pilotsymbol_2 = Pilot_all_AdCell(k,2,:);
                        pilotsymbol_5 = Pilot_all_AdCell(k,3,:);
                        pilotsymbol_8 = Pilot_all_AdCell(k,4,:);
                        pilotsymbol_9 = Pilot_all_AdCell(k,5,:);
                        pilotsymbol_12 = Pilot_all_AdCell(k,6,:);
                        Pilot_Adcell{k} = [pilotsymbol_1;pilotsymbol_2;pilotsymbol_5;pilotsymbol_8;pilotsymbol_9;pilotsymbol_12];
                    end
                end
            otherwise
                disp('wrong Num_Ant_Tx')
        end
    case 1

    otherwise
        disp('wrong CP_Types')
end
Pilot = Pilot_Sequence;
BitStream =[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(Linkmode,'PDSCH')
    NumStream = DownlinkPara.NumStream;
    if PublicPara.HARQFlag == 0
        if seed == 1
            rand('state',10 * subframe + tti + seed);
            BitStream = randint(NumStream,TBSize);
        else
            BitStream = randint(NumStream,TBSize);
        end
    else
        TBTag = mod(PublicPara.SubFrameCount-1,PublicPara.HARQDelay) + 1;        
        BitStream = zeros(NumStream,TBSize);
        for k = 1:NumStream
            if DownlinkPara.HARQ_Flag(TBTag,k) == 0
                BitStream(k,:) = DownlinkPara.SourceBuf{k}{TBTag};
            else
                if seed == 1
                    rand('state',10 * subframe + tti + seed);
                    BitStream(k,:) = randint(1,TBSize);
                else
                    BitStream(k,:) = randint(1,TBSize);
                end
            end
        end
    end
end
