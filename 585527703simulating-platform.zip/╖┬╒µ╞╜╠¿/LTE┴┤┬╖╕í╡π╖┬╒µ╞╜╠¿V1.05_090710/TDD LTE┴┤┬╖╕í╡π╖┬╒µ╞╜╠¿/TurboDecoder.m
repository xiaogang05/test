function [decodedata] = TurboDecoder(datain,K,Lc,Method) 
  DeRateMatching_len=3*K+12;  % ������ƥ��󳤶�
  DeRMdataout = DeRateMatching(datain,DeRateMatching_len);
  % Turbo���� 
  EncoderRateBase=3;
  decodedata=Decode_TurboLogMAP(DeRMdataout,Method,EncoderRateBase,Lc);