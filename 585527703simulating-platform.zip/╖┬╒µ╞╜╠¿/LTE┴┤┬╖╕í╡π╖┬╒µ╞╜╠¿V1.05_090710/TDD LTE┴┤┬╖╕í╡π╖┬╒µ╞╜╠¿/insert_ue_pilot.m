function  insert_ue_pilot(tti)
% ************************************************************************
% ��������: insert_ue_pilot
% ��������: ����UE�ο��ź�
% �������:
%     tti          : ��֡��
% �������:
%
% �޸�����            �汾��            �޸���             �޸�����
% ------------------------------------------------------------------------
% 2008/11/24          V1.0              ��ӱ                ����
% 2008/12/19                            sy                  ����
% ************************************************************************
global PublicPara
global Resource_Grid_ue
global Pilot_Sequence_ue
global Resource_Grid_ue_dl

Num_RB = PublicPara.NumRB;
CP_Types = PublicPara.CPtype;
Cell_ID = PublicPara.NcellID;
vshift_ue = mod(Cell_ID,3);
SubCarrier_dl = PublicPara.Num_Occupied_sc - 1;
Numb_SubCarrier = Num_RB * PublicPara.NumSubCarrierPRB;
nRNTI = PublicPara.RNTI;
Num_Ant_Tx = PublicPara.Num_eNBAnt;

% ����UE�ο��ź�
switch CP_Types
    case 0
        Cint = tti * (2*Cell_ID + 1) * 2^16 + nRNTI;    %  zt  090427
        c = Scrambling_gen(24*Num_RB,Cint);
        Pilot_Sequence_all = (1/sqrt(2)) * ((1 - 2 * c(1:2:end)) + j * (1 - 2 * c(2:2:end)));           %α�������

        Pilot_Sequence_ue = reshape(Pilot_Sequence_all,3*Num_RB,4).';

        Numb_Of_OFDM_PewRB = 14;
        Resource_Grid_ue = zeros(Numb_Of_OFDM_PewRB*Num_Ant_Tx,Numb_SubCarrier);
        Resource_Grid_ue_dl = zeros(Numb_Of_OFDM_PewRB*Num_Ant_Tx,SubCarrier_dl);
        basic_loc = reshape(((12*(0:Num_RB-1))'*ones(1,3))',1,[]);                             %�������ز�

        mm = 0:3*Num_RB-1;
        Resource_Grid_ue((4-1)*Num_Ant_Tx+1:4*Num_Ant_Tx,mod(4*mm + vshift_ue,12)+basic_loc + 1) =  repmat(Pilot_Sequence_ue(1,:),Num_Ant_Tx,1);
        Resource_Grid_ue((7-1)*Num_Ant_Tx+1:7*Num_Ant_Tx,mod(4*mm+mod(2+vshift_ue,4) , 12)+basic_loc + 1) = repmat(Pilot_Sequence_ue(2,:),Num_Ant_Tx,1);
        Resource_Grid_ue((10-1)*Num_Ant_Tx+1:10*Num_Ant_Tx,mod(4*mm + vshift_ue,12)+basic_loc + 1) =  repmat(Pilot_Sequence_ue(3,:),Num_Ant_Tx,1);
        Resource_Grid_ue((13-1)*Num_Ant_Tx+1:13*Num_Ant_Tx,mod(4*mm+mod(2+vshift_ue,4) , 12)+basic_loc + 1) = repmat(Pilot_Sequence_ue(4,:),Num_Ant_Tx,1);
        
        %  ӳ�䵽��ʼλ��      %  zt  090427
        Resource_Grid_ue_dl(:,1:size(Resource_Grid_ue,2)) = Resource_Grid_ue;
    case 1

    otherwise

end