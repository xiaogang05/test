function info_PBCH_rx = de_PBCH(ofdm_control_rx,H_Est_ALL,iteration,NSR)
%************************************************************************
%*  Copyright 2008 by LTE TDD.      All rights reserved.
%*  This software is PROPRIETARY and CONFIDENTIAL
%************************************************************************
% ��Ȩ���� (C)2008, ����ͨѶ
%
% �ļ����ƣ�de_PBCH
% �ļ���ʶ��
% ����ժҪ�����ļ���LTE������·����ƽ̨�ļ��㲥��Ϣ����
% ����˵������
% ��ǰ�汾��V0.1
% ��    �ߣ������㷨��LTE��Ŀ��
% ������ڣ�2008/11/20
%
% �޸�����        �汾��     �޸���	      �޸�����
%-------------------------------------------------------------------------
% 2008/07/22 	  V0.1	     ����	          ����
%
%*************************************************************************

global PublicPara
global DownlinkPara
global MethodPara

Num_Ant_Tx = PublicPara.Num_eNBAnt;
Num_Ant_Rx = PublicPara.Num_UEAnt;
Num_RB = PublicPara.MaxRB;
N_Subcarrier_PerRB = PublicPara.NumSubCarrierPRB;

Resource_Grid = DownlinkPara.Resource_Grid;

PB_loc34 = (Num_RB * N_Subcarrier_PerRB)/2 + (-35:36);

if Num_Ant_Tx == 1
    Resource_Grid(8,:) = Resource_Grid(8,:) + Resource_Grid(12,:);
    PB_loc12 = PB_loc34(Resource_Grid(8,PB_loc34) == 0);
else
    PB_loc12 = PB_loc34(Resource_Grid(7*Num_Ant_Tx+1,PB_loc34) == 0);
end
data_PBCH(:,1:48) = ofdm_control_rx(7*Num_Ant_Rx+1:8*Num_Ant_Rx,PB_loc12);
data_PBCH(:,49:96) = ofdm_control_rx(8*Num_Ant_Rx+1:9*Num_Ant_Rx,PB_loc12);
data_PBCH(:,97:168) = ofdm_control_rx(9*Num_Ant_Rx+1:10*Num_Ant_Rx,PB_loc34);
data_PBCH(:,169:240) = ofdm_control_rx(10*Num_Ant_Rx+1:11*Num_Ant_Rx,PB_loc34);

channel_PBCH = [];
for i = 1:48
    channel_PBCH(:,:,i) = squeeze(H_Est_ALL(:,:,8,PB_loc12(i)));
    channel_PBCH(:,:,48+i) = squeeze(H_Est_ALL(:,:,9,PB_loc12(i)));
end
for i = 1:72
    channel_PBCH(:,:,96+i) = squeeze(H_Est_ALL(:,:,10,PB_loc34(i)));
    channel_PBCH(:,:,168+i) = squeeze(H_Est_ALL(:,:,11,PB_loc34(i)));
end

if Num_Ant_Tx == 1
    channel_PBCH_1T = reshape(channel_PBCH,Num_Ant_Rx,length(channel_PBCH));
    output_de_Layer_mapper_PBCH = DeMod_tx1(data_PBCH,channel_PBCH_1T,NSR,MethodPara.DeMIMO);
else
    output_de_Layer_mapper_PBCH = sfbc_decode(channel_PBCH,data_PBCH);
    output_de_Layer_mapper_PBCH = reshape(output_de_Layer_mapper_PBCH,1,[]);
end
de_modulation_PBCH = -DeModulator(output_de_Layer_mapper_PBCH);

de_modulation_PBCH_4 = DownlinkPara.de_modulation_PBCH_4;
de_modulation_PBCH_4(mod(iteration,4)+~(mod(iteration,4))*4,:) = de_modulation_PBCH;

if size(de_modulation_PBCH_4,1) == 4
    temp = reshape(de_modulation_PBCH_4.',1,[]);
    % ����
    Cint = PublicPara.NcellID;     
    scrambling_sequence = Scrambling_gen(length(temp),Cint);
    DeBitScramble = bit_descramble(temp,scrambling_sequence);
    
    temp1 = sum(reshape(DeBitScramble,[],4),2).';
    % ������ƥ��
    DeRateMatchData = CB_DeRateMatching(temp1,DownlinkPara.Length_BCH_coded,0,0,0,0);
    % ��������
    DecodeData = cc_decode(DeRateMatchData,0);
    % CRC����
    DecodeData(length(DecodeData)-16+1:end) = crc_scramble(DecodeData(length(DecodeData)-16+1:end),Num_Ant_Tx);
    % ��CRC
    [info_PBCH_rx,CheckCRC] = CrcDecoder(DecodeData,16,0);
    de_modulation_PBCH_4 = [];
else
    info_PBCH_rx = [];
end

DownlinkPara.de_modulation_PBCH_4 = de_modulation_PBCH_4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DataCrc_scrambled = crc_scramble(DataCrc,Num_Ant_Tx)

switch Num_Ant_Tx
    case 1
        crc_mask = zeros(1,16);
    case 2
        crc_mask = ones(1,16);
    case 4
        crc_mask = [0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1];
end
DataCrc_scrambled = mod(DataCrc + crc_mask,2);