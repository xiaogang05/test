﻿#include "dialog_shaix.h"
#include "ui_dialog_shaix.h"

Dialog_shaix::Dialog_shaix(QWidget *parent) :
QWidget(parent),
ui(new Ui::Dialog_shaix)
{
ui->setupUi(this);
pt_up = new QPushButton(this);
pt_up->setIcon(QIcon(":/images/add.png"));
pt_up->setIconSize(QSize(20,20));
pt_up->setText("升序");
this->pt_up->setFlat(true);
pt_up->setFocusPolicy(Qt::NoFocus);//设置不聚焦
pt_up->setLayoutDirection(Qt::RightToLeft);

pt_down = new QPushButton(this);
pt_down->setIcon(QIcon(":/images/add.png"));
pt_down->setIconSize(QSize(20,20));
pt_down->setText("降序");
this->pt_down->setFlat(true);
pt_down->setFocusPolicy(Qt::NoFocus);//设置不聚焦
pt_down->setLayoutDirection(Qt::RightToLeft);


pt_shaixuan = new QPushButton(this);
pt_shaixuan->setIcon(QIcon(":/images/add.png"));
pt_shaixuan->setIconSize(QSize(20,20));
pt_shaixuan->setText("筛选");
this->pt_shaixuan->setFlat(true);
pt_shaixuan->setFocusPolicy(Qt::NoFocus);//设置不聚焦
pt_shaixuan->setLayoutDirection(Qt::RightToLeft);

//搜索框
m_pSearchLineEdit = new QLineEdit(this);
pSearchButton = new QPushButton(this);

pSearchButton->setCursor(Qt::PointingHandCursor);
pSearchButton->setFixedSize(20, 20);
pSearchButton->setToolTip(QStringLiteral("搜索"));
pSearchButton->setStyleSheet("QPushButton{border-image:url(:/image/main_data.png); background:transparent;} \
                                   QPushButton:hover{border-image:url(:/image/main_data.png)} \
                                     QPushButton:pressed{border-image:url(:/image/main_data.png)}");

//防止文本框输入内容位于按钮之下
QMargins margins = m_pSearchLineEdit->textMargins();
m_pSearchLineEdit->setTextMargins(margins.left(), margins.top(), pSearchButton->width(), margins.bottom());
m_pSearchLineEdit->setPlaceholderText(QStringLiteral("请输入搜索内容"));

QHBoxLayout *pSearchLayout = new QHBoxLayout();
pSearchLayout->addStretch();
pSearchLayout->addWidget(pSearchButton);
pSearchLayout->setSpacing(0);
pSearchLayout->setContentsMargins(0, 0, 0, 0);
m_pSearchLineEdit->setLayout(pSearchLayout);

connect(pSearchButton, SIGNAL(clicked(bool)), this, SLOT(search()));


treeview = new QTreeView(this);

hboxlayout = new QHBoxLayout(this);

pt_ok = new QPushButton("确定",this);
pt_ok->resize(20,20);
pt_close = new QPushButton("取消",this);
pt_close->resize(20,20);
hboxlayout->addSpacing(10);
hboxlayout->addWidget(pt_ok);
hboxlayout->addWidget(pt_close);

ui->verticalLayout->addWidget(pt_up);//vboxlayout->addWidget(lable);
ui->verticalLayout->addWidget(pt_down);//vboxlayout->addWidget(lable);
ui->verticalLayout->addWidget(pt_shaixuan);//vboxlayout->addWidget(lable);
ui->verticalLayout->addWidget(m_pSearchLineEdit);//vboxlayout->addWidget(lable);
ui->verticalLayout->addWidget(treeview);//vboxlayout->addWidget(lable);
ui->verticalLayout->addLayout(hboxlayout);//vboxlayout->addWidget(lable);
ui->verticalLayout->setStretch(0,1);
ui->verticalLayout->setStretch(0,1);
ui->verticalLayout->setStretch(0,1);
ui->verticalLayout->setStretch(0,1);
ui->verticalLayout->setStretch(0,8);
ui->verticalLayout->setStretch(0,1);
connect(pt_up,SIGNAL(clicked()),this,SLOT(pt_up_clicked()));
connect(pt_down,SIGNAL(clicked()),this,SLOT(pt_down_clicked()));
connect(pt_shaixuan,SIGNAL(clicked()),this,SLOT(pt_shaixuan_clicked()));
connect(pt_ok,SIGNAL(clicked()),this,SLOT(pt_ok_clicked()));
connect(pt_close,SIGNAL(clicked()),this,SLOT(pt_close_clicked()));


inittreeview();
//treeview->verticalHeader()->setVisible(false); /
treeview->setHeaderHidden(true);  //隐藏表头
treeview->expandAll();//默认展开所有
}

Dialog_shaix::~Dialog_shaix()
{
    delete ui;
}

void Dialog_shaix::inittreeview()  //初始话treeview
{
    QStandardItemModel* model = new QStandardItemModel(treeview);
    // model->setHorizontalHeaderLabels(QStringList()<<QStringLiteral("dgs")<<QStringLiteral("info"));
   // model->setHorizontalHeaderLabels(QStringList()<<QStringLiteral(" "));
    QStandardItem* first = new QStandardItem("全选");//添加光缆1的
    model->appendRow(first);
    first->setCheckable(true);
    first->setTristate(true);
    //model->setData(model->index(i,1),glid,Qt::DisplayRole);


    if(english_name != nullptr)
    {
       // qDebug()<<english_name<<m_map.keys();
    //      m_map.keys().size()
    for (int i=0;i<m_map.keys().size();i++) {
        QStandardItem* section = new QStandardItem(m_map.keys().at(i));
            section->setCheckable(true);
            //section->setTristate(true);
            first->appendRow(section);
            //QStandardItem* secondDes = new QStandardItem(QString("第%1钟").arg(i));

            //first->setChild(section->index().row(),1,secondDes);
            first->setChild(section->index().row(),0,section);


        }

    }

    connect(model,SIGNAL(itemChanged(QStandardItem*)),this,SLOT(treeItemChanged(QStandardItem*)));
    treeview->setModel(model);
    first->setCheckState( Qt::Checked);//默认为全选
    treeview->expandAll();//默认展开所有
}

void Dialog_shaix::treeItemChanged(QStandardItem *item) //有变化时进行触发
{
    if ( item == nullptr )
        return ;
    if ( item->isCheckable ())
    {
        //如果条目是存在复选框的，那么就进行下面的操作
        Qt::CheckState state = item->checkState (); //获取当前的选择状态
        if ( item->isTristate ())
        {
            //如果条目是三态的，说明可以对子目录进行全选和全不选的设置
            if ( state != Qt::PartiallyChecked )
            {
                //当前是选中状态，需要对其子项目进行全选
                treeItem_checkAllChild ( item , state == Qt::Checked ? true : false );
            }
        }
        else
        {
            //说明是两态的，两态会对父级的三态有影响
            //判断兄弟节点的情况
            treeItem_CheckChildChanged (item);
        }
       //
    }

}
//当前是选中状态，需要对其子项目进行全选
void Dialog_shaix::treeItem_checkAllChild(QStandardItem * item, bool check)
{

    if(item == nullptr)
        return;
    int rowCount = item->rowCount();
    for(int i=0;i<rowCount;++i)
    {
        QStandardItem* childItems = item->child(i);
        treeItem_checkAllChild_recursion(childItems,check);
    }
    if(item->isCheckable())
        item->setCheckState(check ? Qt::Checked : Qt::Unchecked);




}
void Dialog_shaix::treeItem_checkAllChild_recursion(QStandardItem * item,bool check)
{

    if(item == nullptr)
        return;
    int rowCount = item->rowCount();
    for(int i=0;i<rowCount;++i)
    {
        QStandardItem* childItems = item->child(i);
        treeItem_checkAllChild_recursion(childItems,check);
    }
    if(item->isCheckable())
        item->setCheckState(check ? Qt::Checked : Qt::Unchecked);
}

void Dialog_shaix::pt_up_clicked()
{
  QMessageBox::warning(this,tr("提示"),tr("功能开发中。。。。"),QMessageBox::Ok);

}

void Dialog_shaix::pt_down_clicked()
{
  QMessageBox::warning(this,tr("提示"),tr("功能开发中。。。。"),QMessageBox::Ok);
}

void Dialog_shaix::pt_shaixuan_clicked()
{
  QMessageBox::warning(this,tr("提示"),tr("功能开发中。。。。"),QMessageBox::Ok);
}

void Dialog_shaix::pt_ok_clicked()
{

    emit sendtree_change();//发送变化
    this->close();
}

void Dialog_shaix::pt_close_clicked()
{
    this->close();
}

void Dialog_shaix::search()  //搜索按钮按下
{
     QMessageBox::warning(this,tr("提示"),tr("搜索功能开发中。。。。"),QMessageBox::Ok);
}
void Dialog_shaix::get_name(QString head_name)//得到单机按钮所在列的列明
{

    QSqlQuery query;
    QString selectSql=QString("select * from name where name2='%1';").arg(head_name);
    query.exec(selectSql);
    english_name.clear();
    while(query.next())//一行一行遍历
    {
        english_name =  query.value(0).toString();//查找是否需要显示
      //  qDebug()<<english_name;

    }
    if(english_name != nullptr)
    {

        //得到当前采集到的英文name，可以去采集了
         //inittreeview();//重新初始化

        selectSql = QString("select %1 from weixiu;").arg(english_name);
        query.exec(selectSql);
        int it=0;
        m_map.clear();//清空
        while(query.next())//一行一行遍历
        {
            QString	strItem =  query.value(0).toString();//查找是否需要显示
            if(strItem.isEmpty())
            {
                //将空白添加进去
                strItem = "空白";
            }
            if (!m_map.contains(strItem))  //查找是否存入了m_map中
            {   //还没有，即添加

                m_map.insert(strItem, it);
                it++;

            }
        }
        //m_map.keys().size()
       /* */
        inittreeview();//重新初始化
      //  qDebug()<<m_map.keys().size()<<m_map.keys();
    }

}














void Dialog_shaix::treeItem_CheckChildChanged(QStandardItem * item)
{

    if(nullptr == item)
        return;
    Qt::CheckState siblingState = checkSibling(item);
    QStandardItem * parentItem = item->parent();
    if(nullptr == parentItem)
        return;
    if(Qt::PartiallyChecked == siblingState)
    {
        if(parentItem->isCheckable() && parentItem->isTristate())
            parentItem->setCheckState(Qt::PartiallyChecked);
    }
    else if(Qt::Checked == siblingState)
    {
        if(parentItem->isCheckable())
            parentItem->setCheckState(Qt::Checked);
    }
    else
    {
        if(parentItem->isCheckable())
            parentItem->setCheckState(Qt::Unchecked);
    }
    treeItem_CheckChildChanged(parentItem);


}

Qt::CheckState Dialog_shaix::checkSibling(QStandardItem * item)
{


    //先通过父节点获取兄弟节点
    QStandardItem * parent = item->parent();
    if(nullptr == parent)
        return item->checkState();
    int brotherCount = parent->rowCount();
    int checkedCount(0),unCheckedCount(0);
    Qt::CheckState state;
    for(int i=0;i<brotherCount;++i)
    {
        QStandardItem* siblingItem = parent->child(i);
        state = siblingItem->checkState();
        if(Qt::PartiallyChecked == state)
            return Qt::PartiallyChecked;
        else if(Qt::Unchecked == state)
            ++unCheckedCount;
        else
            ++checkedCount;
        if(checkedCount>0 && unCheckedCount>0)
            return Qt::PartiallyChecked;
    }
    if(unCheckedCount>0)
        return Qt::Unchecked;
    return Qt::Checked;

}
