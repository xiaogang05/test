﻿#ifndef DIALOG_SHAIX_H
#define DIALOG_SHAIX_H

#include <QWidget>
#include <QPushButton>
#include <QTreeView>
#include <QStandardItem>
#include <QHBoxLayout>
#include <QSqlQuery>
#include <QtDebug>
#include <QMessageBox>
#include <QLineEdit>

namespace Ui {
class Dialog_shaix;
}

class Dialog_shaix : public QWidget
{
Q_OBJECT

public:
explicit Dialog_shaix(QWidget *parent = nullptr);
~Dialog_shaix();

QPushButton *pt_up;   //排序上
QPushButton *pt_down;  //排序下
QPushButton *pt_shaixuan;  //排序下

QLineEdit  *m_pSearchLineEdit;//搜索框
QPushButton *pSearchButton ;  //搜索框

QPushButton *pt_ok;  //排序下
QPushButton *pt_close;  //排序下
QTreeView   *treeview;
QHBoxLayout *hboxlayout;
QString english_name = nullptr;  //记录当前表头名字
QMap<QString,int> m_map;
void inittreeview();//初始话treeview
void get_name(QString head_name);//得到单机按钮所在列的列明
private:
Ui::Dialog_shaix *ui;

private slots:
    void   treeItemChanged(QStandardItem* item);//有变化时，触发
    void   treeItem_checkAllChild(QStandardItem * item, bool check);
    void   treeItem_CheckChildChanged(QStandardItem * item);
    Qt::CheckState checkSibling(QStandardItem * item);
    void   treeItem_checkAllChild_recursion(QStandardItem * item,bool check);

   void  pt_up_clicked();
   void pt_down_clicked();
   void pt_shaixuan_clicked();
   void pt_ok_clicked();
   void pt_close_clicked();
   void search();//搜索按钮

signals:
       void sendtree_change();  //发送更新显示的信号
};

#endif // DIALOG_SHAIX_H
