import sys

from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QTableWidgetItem, QListWidgetItem, QCheckBox,
                             QAbstractItemView, QHeaderView, QMenu, QAction)
from PyQt5.QtCore import QPoint
import mainwindow


class Ui_MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(QMainWindow, self).__init__(parent)
        self.ui = mainwindow.Ui_MainWindow()
        self.ui.setupUi(self)
        self.table_init()

    def table_init(self):
        self.ui.groupBox_shaixuan.hide()
        self.ui.tableWidget.setRowCount(6)
        self.ui.tableWidget.setColumnCount(3)
        lab = ["时间", "频率", "备注"]
        self.ui.tableWidget.setHorizontalHeaderLabels(lab)
        self.rowC = self.ui.tableWidget.rowCount()
        table_col_1 = ["2022/11/28", "2022/11/08", "2001/07/13", "2003/10/16", "2019/09/01", "2019/09/01"]
        table_col_2 = ["1024", "2048", "9600", "115200", "4096", "1024"]
        table_col_3 = ["abc", "xZ", "AD", "Bb", "ppd", "ppd"]
        for i in range(0, self.rowC):
            item1 = QTableWidgetItem(table_col_1[i])
            # item1.setData(table_col_1[i])
            self.ui.tableWidget.setItem(i, 0, item1)
            item2 = QTableWidgetItem(table_col_2[i])
            # item2.setData(table_col_2[i])
            self.ui.tableWidget.setItem(i, 1, item2)
            item3 = QTableWidgetItem(table_col_3[i])
            # item3.setData(table_col_3[i])
            self.ui.tableWidget.setItem(i, 2, item3)

        self.ui.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ui.tableWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.ui.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        # self.ui.tableWidget.horizontalHeader().setSelectionMode(QHeaderView.Stretch)
        self.ui.tableWidget.clicked.connect(self.ui.groupBox_shaixuan.hide)
        self.ui.tableWidget.horizontalHeader().clicked.connect(self.ui.groupBox_shaixuan.hide)
        self.ui.tableWidget.horizontalHeader().setContextMenuPolicy(3)
        self.ui.tableWidget.horizontalHeader().customContextMenuRequested.connect(self.right_menu)

    def right_menu(self, pos):
        print(pos.x())
        index = self.ui.tableWidget.columnAt(pos.x())
        self.ui.groupBox_shaixuan.hide()
        for i in range(0, self.rowC):
            flag = 1
        menu = QMenu()
        pnew = QAction("筛选")
        menu.addAction(pnew)

        menu1 = menu.addMenu("排序")
        pnew_up = QAction("升序")
        pnew_down = QAction("降序")
        menu1.addAction(pnew_up)
        menu1.addAction(pnew_down)
        menu.move(pos)
        menu.show()
        menu.exec_(self.ui.tableWidget.mapToGlobal(pos))
        pnew.triggered.connect(self.submenu)

    def submenu(self):
        self.listWidget_init()
        self.ui.pushButton_ok.clicked.connect()

    def pushbutton_ok_cliced(self):
        self.ui.lineEdit.clear()
        for i in range(0, self.rowC):
            self.ui.tableWidget.setRowHidden(i, True)


    def lineEdit_init(self):
        self.ui.lineEdit.textEdited.connet(self.line_init_child())

    def common_if(self, it):
        child = QListWidgetItem(self.ui.listWidget)
        child_Box = QCheckBox()
        child_Box.setText(it)
        self.ui.listWidget.addItem(child)
        self.ui.listWidget.setItemWidget(child, child_Box)
        # if isCheck_box.

    def line_init_child(self):
        self.ui.listWidget.clear()
        all = QListWidgetItem()
        all_Box = QCheckBox()
        all_Box.setText("全部")
        self.ui.listWidget.addItem(all)
        self.ui.listWidget.setItemWidget(all, all_Box)
        flag = 1

    def listWidget_init(self, x, y):
        self.ui.listWidget.clear()
        self.ui.tableWidget.show()
        self.ui.groupBox_shaixuan.move(x,y)
        self.ui.groupBox_shaixuan.show()

if __name__ == '__main__':
    myapp = QApplication(sys.argv)

    myDlg = Ui_MainWindow()

    myDlg.show()

    sys.exit(myapp.exec_())
